<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Internal_cugsModel extends Model
{
    use HasFactory;
    public $table      = "egc_Internal_cugs";
    public $primaryKey = 'sno';


   protected $fillable = [
        'branch_id',
        'user_name',
        'cug_mobile_no',
        'created_by',
        'updated_by',
        'status',
    ];
}