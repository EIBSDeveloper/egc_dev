<?php

namespace App\Http\Controllers\settings\entity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\SocialMediaModel;



class SocialMedia extends Controller
{
  

public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $level = SocialMediaModel::where('status', '!=', 2);
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('social_media_name', 'LIKE', "%{$search_filter}%");
                      
              });
          }
        $level=$level->orderBy('sno', 'desc')
         ->paginate($perpage);

          

        if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'social_media_name' => $item->social_media_name,
                    'social_media_desc' => $item->social_media_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }
      
        return view('content.settings.entity.social_media.social_media', [
          'level' => $level,
          'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function list()
    {
        $knowledge_level = SocialMediaModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $knowledge_level,
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'social_media_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $social_media_name = $request->social_media_name;
            $social_media_desc = $request->social_media_desc;

            $user_id = $request->user()->user_id ?? 1;
            $chk = SocialMediaModel::where('social_media_name', ucwords($social_media_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!',
                ]);
            } else {
                $add_category = new SocialMediaModel();
                $add_category->social_media_name = $social_media_name;
                $add_category->social_media_desc = $social_media_desc;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Credential added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Credential!',
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'knowledge Created successfully!');
        }
    }

    public function Edit($id)
    {
        $credential = SocialMediaModel::where('sno', $id)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $credential,
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'social_media_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $social_media_name = $request->social_media_name;
            $bg_color = $request->bg_color;
            $social_media_desc = $request->social_media_desc;

            $upd_CourseCategoryModel = SocialMediaModel::where('sno', $id)->first();

            $chk = SocialMediaModel::where('social_media_name', $social_media_name)->where('status', '!=', 2)->where('sno', '!=', $id)->first();

            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Name has been  already assigned!',
                        'data' => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->social_media_name = $social_media_name;
            $upd_CourseCategoryModel->social_media_desc = $social_media_desc;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = SocialMediaModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel = SocialMediaModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
