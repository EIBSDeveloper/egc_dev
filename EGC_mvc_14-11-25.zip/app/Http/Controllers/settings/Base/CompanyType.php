<?php

namespace App\Http\Controllers\settings\Base;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CompanyTypeModel;
use Illuminate\Support\Facades\Validator;

class CompanyType extends Controller {
    protected static $branch_id = 1;

    public function index() {

        return view( 'content.settings.Base.company_type.company_type_list');
    }

    public function List() {
        $Department = CompanyTypeModel::where( 'status', '!=', 2 )->where( 'branch_id', self::$branch_id )->orderBy( 'sno', 'desc' )->get();

        return response( [
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $Department
        ], 200 );
    }

    public function Add( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'department_name' => 'required|max:255'
        ] );
        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $department_name = $request->department_name;
            $department_desc = $request->department_desc;
            $user_id = 1;
            $chk = DepartmentModel::where( 'department_name', ucwords( $department_name ) )->where( 'branch_id', self::$branch_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {

                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Department is exist!'
                ] );
                return redirect()->back();
            } else {
                $category_check = DepartmentModel::where( 'status', '!=', 2 )->orderBy( 'sno', 'desc' )->first();

                if ( !$category_check ) {

                    $year = substr( date( 'y' ), -2 );
                    $department_id = 'DP-0001/' . $year;
                } else {

                    $data = $category_check->department_id;
                    $slice = explode( '/', $data );
                    $result = preg_replace( '/[^0-9]/', '', $slice[ 0 ] );

                    $next_number = ( int ) $result + 1;
                    $request = sprintf( 'DP-%04d', $next_number );

                    $year = substr( date( 'y' ), -2 );
                    $department_id = $request . '/' . $year;
                }

                $add_department = new DepartmentModel();
                $add_department->department_id = $department_id;
                $add_department->department_name = Ucfirst( $department_name );
                $add_department->department_desc = $department_desc;
                $add_department->branch_id = self::$branch_id;
                $add_department->created_by = $user_id;
                $add_department->updated_by = $user_id;

                $add_department->save();

                if ( $add_department ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'department added Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the department!'
                    ] );
                }
            }
            return redirect()->back();
        }
    }

    public function Edit( $id ) {
        $editdepartment = DepartmentModel::where( 'sno', $id )->first();

        return view( 'content.settings.Base.department.department_list', [
            'editdepartment' => $editdepartment,
            'id' => $id,
        ] );
    }

    public function Update( Request $request ) {

        $validator = Validator::make( $request->all(), [
            'department_name' => 'required|max:255',

        ] );

        if ( $validator->fails() ) {
            return response( [
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get( '*' ),
                'data' => null,
            ], 200 );
        } else {

            $department_name = $request->department_name;
            $department_desc = $request->department_desc;
            $department_id = $request->department_id;

            $upd_DepartmentModel = DepartmentModel::where( 'sno', $department_id )->first();

            $chk = DepartmentModel::where( 'department_name', ucwords( $department_name ) )->where( 'branch_id', self::$branch_id )->where( 'sno', '!=', $department_id )->where( 'status', '!=', 2 )->first();

            if ( $chk ) {
                session()->flash( 'toastr', [
                    'type' => 'error',
                    'message' => 'Already Department is exist!'
                ] );
                return redirect()->back();
            } else {

                $upd_DepartmentModel->department_name = Ucfirst( $department_name );
                $upd_DepartmentModel->department_desc = $department_desc;
                $upd_DepartmentModel->branch_id = self::$branch_id;
                $upd_DepartmentModel->update();

                if ( $upd_DepartmentModel ) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash( 'toastr', [
                        'type' => 'success',
                        'message' => 'Department Update Successfully!'
                    ] );
                } else {
                    session()->flash( 'toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Department!'
                    ] );
                }
            }
        }
        return redirect()->back();
    }

    public function Delete( $id ) {
        $upd_DepartmentModel = DepartmentModel::where( 'sno', $id )->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }

    public function Status( $id, Request $request ) {

        $upd_DepartmentModel = DepartmentModel::where( 'sno', $id )->first();
        $upd_DepartmentModel->status = $request->input( 'status', 0 );
        $upd_DepartmentModel->update();

        return response( [
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200 );
    }
}