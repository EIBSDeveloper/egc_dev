<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserRoleModel extends Model
{
    use HasFactory;
    public $table      = "egc_user_role";
    public $primaryKey = 'sno';


    protected $fillable = [
        'role_id',
        'company_type',
        'company_id',
        'entity_id',
        'erp_role_id',
        'erp_under_role_id',
        'role_name',
        'branch_id',
        'entity_id',
        'map_under',
        'user_role_id',
        'created_by',
        'updated_by',
        'created_at',
        'status',
    ];
}