<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobRoleModel extends Model
{
  use HasFactory;
  public $table = "egc_job_role";
  public $primaryKey = 'sno';

  protected $fillable = [
    'job_position_id',
    'erp_job_role_id',
    'erp_department_id',
    'erp_division_id',
    'company_type',
    'company_id',
    'entity_id',
    'branch_id',
    'department_id',
    'division_id',
    'job_position_name',
    'grade_name',
    'level_name',
    'per_hour_cost',
    'job_position_desc',
    'created_by',
    'created_at',
    'status',
  ];
}
