@extends('layouts/layoutMaster')

@section('title', 'Add Staff')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/select2/select2.scss', 'resources/assets/vendor/libs/flatpickr/flatpickr.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/dropzone/dropzone.scss', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js', 'resources/assets/vendor/libs/sortablejs/sortable.js', 'resources/assets/vendor/libs/dropzone/dropzone.js', 'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])
    @vite('resources/assets/js/forms-file-upload.js')
    @vite('resources/assets/js/forms-pickers.js')

@endsection

@section('content')



    <style>
        .dataTables_scroll {
            max-height: 200px;
        }

        /* Completed step */
        .bs-stepper-header .step.crossed .step-trigger .avatar .avatar-initial {
            background-color: #28a745 !important;
            color: #fff !important;
        }

        /* Active/current step */
        .bs-stepper-header .step.active .step-trigger .avatar .avatar-initial {
            background-color: #0d6efd !important;
        }

        /* Pending step */
        .bs-stepper-header .step.disabled .step-trigger .avatar .avatar-initial {
            background-color: #e9ecef;
            color: #6c757d;
            pointer-events: none;
        }
         /* .step-trigger.no-click {
             pointer-events: none; 
           } */

           .err_border{
            border:1px solid red;
           }
           
    /* Horizontal scroll container */
    .file-previews {
        display: flex;
        flex-wrap: nowrap;
        gap: 10px;
        overflow-x: auto;
        overflow-y: hidden;
        padding: 10px 0;
        scroll-behavior: smooth;
        cursor: grab; /* 👈 show grab hand */
        user-select: none;
    }

    /* While dragging */
    .file-previews:active {
        cursor: grabbing; /* 👈 active grab effect */
    }

    /* Optional: scrollbar style */
    .file-previews::-webkit-scrollbar {
        height: 8px;
    }
    .file-previews::-webkit-scrollbar-thumb {
        background: #c94545;
        border-radius: 4px;
    }
    .file-previews::-webkit-scrollbar-track {
        background: #f1f1f1;
    }

        /* Dropzone preview styles */
        .dz-preview {
            border: 1px solid #ccc;
            border-radius: 10px;
            background: #fff;
            text-align: center;
            padding: 5px;
            width: 120px !important;
            height: 150px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            flex: 0 0 auto;
            position: relative;
        }

        /* File image */
        .dz-image img {
            width: 100%;
            height: 100px;
            object-fit: cover;
            border-radius: 6px;
        }

        /* Progress bar */
        .dz-progress {
            position: absolute;
            bottom: 6px;
            left: 5px;
            right: 5px;
            height: 5px;
            background: #eee;
            border-radius: 3px;
            overflow: hidden;
        }
        .dz-filename {
            position: absolute;
            width: 120px;
            overflow: hidden;
            padding: 0.625rem 0.625rem 0 0.625rem;
            background: #fff;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        .dz-upload {
            display: block;
            height: 100%;
            background: #c94545;
            width: 0;
            transition: width 0.3s ease;
        }

        /* Success and error icons */
            .dz-success-mark,
            .dz-error-mark {
                position: absolute;
                top: 40%;
                left: 40%;
                /* transform: translate(-50%, -50%); */
                font-size: 32px;
                display: none;
                z-index: 10; /* ensures it's above the image */
            }

            /* Success checkmark */
            .dz-success-mark {
                color: #28a745; /* green */
            }

            /* Error cross */
            .dz-error-mark {
                color: #dc3545; /* red */
            }

            /* Show only when upload succeeds or fails */
            .dz-success .dz-success-mark {
                display: block;
            }
            .dz-error .dz-error-mark {
                display: block;
            }

            /* Make sure the image wrapper is positioned for absolute centering */
            .dz-image {
                position: relative;
                overflow: hidden;
                border-radius: 6px;
            }



      /* Example: Customizing optgroup label color */
      .select2-results__group {
          color: #beb63c; /* Primary blue color */
          font-weight: bold;
      }

    </style>
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <!-- Lead List Table -->
    <div class="card card-action mb-2">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Add Staff</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                HR Enroll
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Manage Staff
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <form method="POST" action="{{ route('add_staff') }}" enctype="multipart/form-data" autocomplete="off" data-track-percentage
        id="staff_form">
        @csrf
        <input type="hidden" name="completion_percentage" id="completion_percentage" class="form-percentage" value="0">
        <div class="bs-stepper wizard-vertical vertical wizard-vertical-icons-example wizard-vertical-icons mt-2 gap-3 ">
        <div class="bs-stepper-header gap-lg-2">
            <div class="step active" data-target="#staff_add">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="fa-solid fa-handshake"></i>
                        </span>
                    </span>
                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Base Details</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="staff_add" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>  
            <div class="step" data-target="#family_add">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-human-male-male-child fs-3"></i>
                        </span>
                    </span>
                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Family Details</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="family_add" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#contact_add">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-card-account-phone fs-3"></i>
                        </span>
                    </span>
                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Contact Details</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="contact_add" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#socialmedia">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-web fs-3"></i>
                        </span>
                    </span>

                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Social Media</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="socialmedia" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#Education">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-book-education fs-3"></i>
                        </span>
                    </span>
                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Education</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="Education" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#work_add">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-monitor fs-3"></i>
                        </span>
                    </span>
                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Work Type</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="work_add" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#companydetails">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-office-building fs-3"></i>
                        </span>
                    </span>

                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Company Details</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="companydetails" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#application_add">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-file-outline fs-3"></i>
                        </span>
                    </span>

                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Application Details</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="application_add" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>

                    </div>
                </button>
            </div>
            <div class="step" data-target="#checklist_add">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-format-list-checks fs-3"></i>
                        </span>
                    </span>

                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">CheckList</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="checklist_add" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
            <div class="step" data-target="#orientation">
                <button type="button" class="step-trigger no-click">
                    <span class="avatar">
                        <span class="avatar-initial rounded-2">
                            <i class="mdi mdi-calendar-account fs-3"></i>
                        </span>
                    </span>
                    <div class="d-flex flex-column gap-1">
                        <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                            <span class="bs-stepper-title">Orientation</span>
                        </span>
                        <div class="progress step-progress ms-2 rounded" data-step="orientation" style="height: 10px; width:100px;">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 0%" aria-valuenow="0"
                            aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                </button>
            </div>
        </div>
        <div class="bs-stepper-content">
            <div id="staff_add" class="content ">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Personal Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mb-2">Staff Image</label>
                        <div class="d-flex align-items-sm-center justify-content-start">
                            <div class="d-flex align-items-start justify-content-center flex-column gap-2">
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="Attachment"
                                    class="d-block w-px-120 h-px-120 rounded" id="logo_create"
                                    style="border: 2px solid #ab2b22;" />
                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                            </div>
                            <div class="button-wrapper">
                                <div class="d-flex align-items-start justify-content-start mt-2 mb-2 flex-wrap gap-2">
                                    <label class="btn btn-sm btn-primary me-2" tabindex="0">
                                        <span class="fw-semibold text-white fs-6">Upload</span>
                                        <input type="file" name="staff_add_icon" id="fav_upload" class="fav_file-in" hidden accept="image/png, image/jpeg" data-ignore-total/>
                                    </label>
                                    <button type="button" class="btn btn-sm btn-outline-danger fav_file-reset">
                                        <span class="fw-semibold text-primary fs-6">Reset</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="staff_name" name="staff_name"
                            placeholder="Enter Staff Name"
                            oninput="this.value=this.value.replace(/^\w/, txt=>txt.toUpperCase());" />
                            <div class="text-danger" id="staff_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Staff Mobile No<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="mobile_no" name="mobile_no" maxlength="10"
                            oninput="this.value=this.value.replace(/[^0-9]/g,'');" placeholder="Enter Mobile No" onkeyup="mobile_chk(this.value)"/>
                            <div class="text-danger" id="mobile_no_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Gender<span class="text-danger">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="gender_male"
                                    value="1" checked />
                                <label class="form-check-label" for="gender_male">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="gender_female"
                                    value="2" />
                                <label class="form-check-label" for="gender_female">Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" id="gender_others"
                                    value="3" />
                                <label class="form-check-label" for="gender_others">Others</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth<span
                                class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_dob" name="dob" placeholder="Select Date"
                                class="form-control common_datepicker" readonly />
                                
                        </div>
                        <div class="text-danger" id="staff_dob_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="email_id" name="email_id"
                            placeholder="Enter E-Mail ID" oninput="this.value=this.value.toLowerCase();" />
                            <div class="text-danger" id="email_id_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Mother Tongue<span class="text-danger">*</span></label>
                        <select id="mother_tongue" name="mother_tongue" class="select3 form-select">
                            <option value="">Select Mother Tongue</option>
                            @if(isset($languageList))
                            @foreach($languageList as $language)
                                <option value="{{$language->sno}}">{{$language->name}}</option>
                            @endforeach
                            @endif
                        </select>
                            <div class="text-danger" id="mother_tongue_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Languages Known<span
                                class="text-danger">*</span></label>
                        <select id="Languages" name="Languages[]" class="select3 form-select" multiple data-placeholder="Select Languages">
                            <option value="">Select Languages</option>
                            @if(isset($languageList))
                            @foreach($languageList as $language)
                                <option value="{{$language->sno}}">{{$language->name}}</option>
                            @endforeach
                            @endif
                            
                        </select>
                        <div class="text-danger" id="Languages_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Hobby</label>
                        <select id="hobby" name="hobby[]" class="select3 form-select" multiple data-placeholder="Select Hobby">
                            <option value="">Select Hobby</option>
                            @if(isset($hobbyList))
                            @foreach($hobbyList as $hobby)
                                <option value="{{$hobby->sno}}">{{$hobby->hobby_name}}</option>
                            @endforeach
                            @endif
                            
                        </select>
                        <div class="text-danger" id="hobby_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1" id="description" name="description" placeholder="Enter Description"></textarea>
                    </div>
                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary " id="prev1" disabled>
                            <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <button  type="button" class="btn btn-primary" id="stage1" onclick="validation_func(1)">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                            <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div id="family_add" class="content">
                <div class="row">
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Father Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" name="father_name" id="father_name" placeholder="Enter Father Name" />
                        <div class="text-danger" id="father_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Father Occupation<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Father Occupation" name="father_occup" id="father_occup" />
                        <div class="text-danger" id="father_occup_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Mother Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Mother Name" id="mother_name" name="mother_name"/>
                        <div class="text-danger" id="mother_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Mother Occupation<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Mother Occupation" name="mother_occup" id="mother_occup" />
                        <div class="text-danger" id="mother_occup_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Marital Status<span
                                class="text-danger">*</span></label>
                        <select id="marital_status" name="marital_status" class="select3 form-select">
                            <option value="">Select Marital Status</option>
                            <option value="1">Unmarried</option>
                            <option value="2">Married</option>
                            <option value="3">Widowed</option>
                        </select>
                        <div class="text-danger" id="marital_status_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 spouse-field d-none">
                        <label class="text-black fs-6 fw-semibold">Anniversary Date<span
                                class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" name="anniversary_date" placeholder="Select Date" id="anniversary_date"
                                class="form-control common_datepicker" readonly/>
                        </div>
                        <div class="text-danger" id="anniversary_date_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 spouse-field d-none">
                        <label class="text-black fs-6 fw-semibold">Spouse Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Name" name="spouse_name" id="spouse_name" />
                        <div class="text-danger" id="spouse_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 spouse-field d-none">
                        <label class="text-black fs-6 fw-semibold">Spouse Mobile No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Mobile No" name="spouse_mobile" id="spouse_mobile" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="spouse_mobile_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 spouse-field d-none">
                        <label class="text-black fs-6 fw-semibold">Date Of Birth<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="spouse_dob" name="spouse_dob" placeholder="Select Date"
                                class="form-control common_datepicker" value="" readonly/>
                        </div>
                        <div class="text-danger" id="spouse_dob_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 spouse-field d-none">
                        <label class="text-black mb-1 fs-6 fw-semibold">Spouse Working ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_working" id="workingYes"
                                    value="Yes" />
                                <label class="form-check-label" for="workingYes">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_working" id="workingNo" checked
                                    value="No" />
                                <label class="form-check-label" for="workingNo">No</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3 working-fields d-none">
                        <label class="text-black fs-6 fw-semibold">Spouse Designation<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Designation" id="spouse_designation" name="spouse_designation"/>
                        <div class="text-danger" id="spouse_designation_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 working-fields d-none">
                        <label class="text-black fs-6 fw-semibold">Spouse Company Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Company Name" id="spouse_company_name" name="spouse_company_name"/>
                        <div class="text-danger" id="spouse_company_name_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3 working-fields d-none">
                        <label class="text-black fs-6 fw-semibold">Spouse Salary<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Salary" id="spouse_salary" name="spouse_salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                        <div class="text-danger" id="spouse_salary_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Children ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_children" id="childrenYes"
                                    value="Yes" />
                                <label class="form-check-label" for="childrenYes">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_children" id="childrenNo" checked
                                    value="No" />
                                <label class="form-check-label" for="childrenNo">No</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3 children-section d-none">
                        <label class="text-black mb-1 fs-6 fw-semibold">Children Count <span
                                class="text-danger">*</span></label>
                        <input type="text" id="childrenCount" name="childrenCount" class="form-control" placeholder="Enter Children Count"
                            maxlength="1" oninput="this.value = this.value.replace(/[^0-9]/g, '').slice(0,1)">
                            <div class="text-danger" id="childrenCount_err"></div>
                    </div>
                    <div id="childrenDetails" class="col-lg-12 mt-3"></div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Siblings ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_Siblings" id="SiblingsYes"
                                    value="Yes" />
                                <label class="form-check-label" for="SiblingsYes">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_Siblings" id="SiblingsNo" checked
                                    value="No" />
                                <label class="form-check-label" for="SiblingsNo">No</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3 d-none" id="siblingsDescription">
                        <label class="text-black mb-1 fs-6 fw-semibold">Siblings Details<span
                                class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" placeholder="Enter Siblings Details" name="siblings_detail" id="siblings_detail"></textarea>
                        <div class="text-danger" id="siblings_detail_err"></div>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-between mt-4">
                    <button type="button" class="btn btn-outline-secondary" id="prev2" onclick="safePrev(2)">
                        <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button type="button" class="btn btn-primary " id="stage2" onclick="validation_func(2)">
                        <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                        <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                    </button>
                </div>
            </div>
            <div id="contact_add" class="content">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Residential Details</label>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Permanent Address <span class="text-danger">*</span></label>
                        <textarea class="form-control required-field" rows="1" name="permanent_address" id="permanent_address" placeholder="Enter Permanent Address" ></textarea>
                        <div class="text-danger" id="permanent_address_err"></div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Residential Address</label>
                        <textarea class="form-control required-field" rows="1" name="residential_address" id="residential_address"
                            placeholder="Enter Residential Address"></textarea>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Location URL </label>
                        <input type="text" class="form-control required-field" placeholder="Enter Location URL" name="staff_location_url" id="staff_location_url">
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Latitude</label>
                        <input type="text" class="form-control required-field" placeholder="Enter latitude" name="staff_latitude" id="staff_latitude">
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Longitude</label>
                        <input type="text" class="form-control required-field" placeholder="Enter longitude" name="staff_longitude" id="staff_longitude">
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Contact Details</label>
                    </div>
                    <div class="col-lg-12">
                        <div id="altmobile-wrapper">
                            <div class="altmobile-row bg-gray-200 rounded px-2 py-2 mb-2">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold" for="contact_person_name">Contact
                                            Person<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control required-field"
                                            id="contact_person_name" name="contact_person_name[]"
                                            placeholder="Enter Contact Person Name"
                                            oninput="this.value = this.value.replace(/^\w/, txt => txt.toUpperCase());" />
                                            <div class="text-danger" id="contact_person_name_err"></div>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold" for="contact_person_relation">Contact
                                            Person Relation<span class="text-danger">*</span></label>
                                        <select id="contact_person_relation" name="contact_person_relation[]" class="select3 form-select" >
                                                <option value="">Select Relation</option>
                                                @if(isset($relationshipList))
                                                @foreach($relationshipList as $relation)
                                                    <option value="{{$relation->sno}}">{{$relation->relationship_name}}</option>
                                                @endforeach
                                                @endif
                                                
                                            </select>
                                            <div class="text-danger" id="contact_person_relation_err"></div>
                                    </div>
                                    <div class="col-lg-3 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold text-nowrap" for="contact_person_no">Contact
                                            Person Mobile No.
                                            <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control required-field me-2" maxlength="10"
                                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                            id="contact_person_no" name="contact_person_no[]"
                                            placeholder="Enter Contact Person Mobile Number" />
                                            <div class="text-danger" id="contact_person_no_err"></div>
                                    </div>
                                    <div class="col-lg-1 d-flex align-items-center mt-2 justify-content-center">
                                        <div class="d-flex align-items-end mb-2 justify-content-end">
                                            <a href="javascript:;" class="btn text-danger px-2 py-1 altmobile_del"
                                                style="display: none !important;">
                                                <i class="fa-solid fa-trash-can fs-4"></i>
                                            </a>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <div class="mb-1 d-flex align-items-center justify-content-end">
                            <button type="button" class="btn btn-primary" id="add-altmobile-btn">
                                <i class="mdi mdi-plus me-1"></i>Add More
                            </button>
                        </div>
                    </div>
                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary " id="prev3" onclick="safePrev(3)">
                            <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <button type="button" class="btn btn-primary" id="stage3" onclick="validation_func(3)">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                            <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div id="socialmedia" class="content">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Social Media Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            @if(isset($social_media_list))
                                @foreach($social_media_list as $slist)
                                    <div class="col-lg-4 mb-3">
                                        <div class="form-check mb-2">
                                            <input 
                                                class="form-check-input toggle-field" 
                                                type="checkbox" 
                                                id="checkSocialMedia_{{$slist->sno}}" 
                                                data-target="#socialMediaField_{{$slist->sno}}"
                                            >
                                            <label 
                                                class="form-check-label text-black mb-1 fs-6 fw-semibold" 
                                                for="checkSocialMedia_{{$slist->sno}}"
                                            >
                                                {{$slist->social_media_name}}
                                            </label>
                                        </div>

                                        <div id="socialMediaField_{{$slist->sno}}" class="d-none">
                                            <input 
                                                type="text" 
                                                class="form-control" 
                                                name="social_media[{{$slist->sno}}]" 
                                                placeholder="Enter {{$slist->social_media_name}} URL" 
                                            />
                                        </div>
                                        <div class="text-danger" id="checkSocialMedia_{{$slist->sno}}_err"></div>
                                    </div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-between mt-4">
                    <button type="button" class="btn btn-outline-secondary " id="prev4" onclick="safePrev(4)">
                        <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button type="button" class="btn btn-primary" id="stage4" onclick="validation_func(4)">
                        <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                        <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                    </button>
                </div>
            </div>
            <div id="Education" class="content">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Educational Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div id="education-wrapper">
                            <div class="education-row bg-gray-200 rounded px-2 py-2 mb-2">
                                <div class="row">
                                    <div class="col-lg-11">
                                        <div class="row">
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Qualification Type<span
                                                        class="text-danger">*</span></label>
                                                <select id="qualification_type_0" name="qualification_type[]"
                                                    class="select3 form-select required-field">
                                                    <option value="">Select Qualification Type</option>
                                                    @if(isset($qualificationList))
                                                    @foreach($qualificationList as $edu)
                                                        <option value="{{$edu->sno}}">{{$edu->education}}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                                <div class="text-danger error_msg"></div>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Degree<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control required-field" name="degree[]" 
                                                    placeholder="Enter Degree" />
                                                     <div class="text-danger error_msg"></div>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Major<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control required-field" name="major[]"
                                                    placeholder="Enter Major" />
                                                     <div class="text-danger error_msg"></div>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Institute / University
                                                    Name<span class="text-danger">*</span></label>
                                                <input type="text" class="form-control required-field"
                                                    name="univ_name[]" placeholder="Enter Institute / University Name" />
                                                     <div class="text-danger error_msg"></div>
                                            </div>
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Year
                                                    <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control required-field"
                                                    name="pass_year[]" placeholder="Enter Year" maxlength="4" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                                                     <div class="text-danger error_msg"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 d-flex align-items-center mt-2 justify-content-center">
                                        <div class="d-flex align-items-end mb-2 justify-content-end">
                                            <a href="javascript:;" class="btn text-danger px-2 py-1 staff_edu_del"
                                                style="display: none !important;">
                                                <i class="fa-solid fa-trash-can fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mb-1 mt-2 d-flex align-items-center justify-content-end">
                            <button type="button" class="btn btn-primary" id="add-edu-btn">
                                <i class="mdi mdi-plus me-1"></i>Add More
                            </button>
                        </div>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Any Course Completed ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input required-field" type="radio" name="is_Course"
                                    id="CourseYes" value="Yes" />
                                <label class="form-check-label" for="CourseYes">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input required-field" type="radio" name="is_Course"
                                    id="CourseNo" value="No" checked />
                                <label class="form-check-label" for="CourseNo">No</label>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-8 mb-3 d-none" id="courseAttachmentHeader">
                        <label class="text-black mb-1 fs-6 fw-semibold">Enter Course<span
                                class="text-danger">*</span></label>
                        <div class="form-floating form-floating-outline">
                            <input id="course_tag" name="course_tag" class="form-control h-auto course_tag required-field"
                                row="1" placeholder="Select Course Tags" value="">
                                <div class="text-danger error_msg"></div>
                        </div>
                    </div>

                     

                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary " id="prev5" onclick="safePrev(5)">
                            <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <button type="button" class="btn btn-primary " id="stage5" onclick="validation_func(5)">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                            <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div id="work_add" class="content " >
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Work Type</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Type<span
                                        class="text-danger">*</span></label>
                                <select id="work_type" name="work_type" class="select3 form-select required-field">
                                    <option value="">Select Type</option>
                                    <option value="1">Fresher</option>
                                    <option value="2">Experience</option>
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                            <div class="col-lg-4 mb-3 d-none shiftedCompanyField">
                                <label class="text-black fs-6 mb-1 fw-semibold">Shifted Company Count<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field"
                                    placeholder="Enter Shifted Company Count" id="total_company_shift" name="total_company_shift" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                                    <div class="text-danger error_msg"></div>
                            </div>
                            <div class="col-lg-4 mb-3 d-none shiftedCompanyField">
                                <label class="text-black fs-6 mb-1 fw-semibold">Total Years Of Experience<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field"
                                    placeholder="Enter Total Years Of Experience" id="total_experience" name="total_experience" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                                    <div class="text-danger error_msg"></div>
                            </div>
                        </div>

                        <div id="work-exp-wrapper">
                            <div class="col-lg-12 mb-3">
                                <label class="fs-5 text-primary fw-bold">Previous Company Details</label>
                            </div>
                            <div class="work-exp-row bg-gray-200 rounded px-2 py-2 mb-2">
                                <div class="row mt-4">
                                    <div class="col-lg-12">
                                        <div class="row">
                                            <div class="col-lg-11">
                                                <div class="row">
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                                                class="text-danger">*</span></label>
                                                        <input type="text" class="form-control required-field"
                                                            name="company_name[]" placeholder="Enter Company Name" />
                                                            <div class="text-danger error_msg"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Position<span
                                                                class="text-danger">*</span></label>
                                                        <input type="text" class="form-control required-field"
                                                            name="position[]" placeholder="Enter Position" />
                                                            <div class="text-danger error_msg"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Experience
                                                            Years<span class="text-danger">*</span></label>
                                                        <input type="text" class="form-control required-field"
                                                            name="exp_yrs[]" placeholder="Enter Experience Years" maxlength="5" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                                                            <div class="text-danger error_msg"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Salary<span
                                                                class="text-danger">*</span></label>
                                                        <input type="text" class="form-control required-field"
                                                            name="salary[]" placeholder="Enter Salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                                                            <div class="text-danger error_msg"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span
                                                                class="text-danger">*</span></label>
                                                        <div class="input-group input-group-merge">
                                                            <span class="input-group-text"><i
                                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                            <input type="text" id="work_st_date" name="work_st_date[]"
                                                                class="form-control common_datepicker required-field"
                                                                placeholder="Select Date" value="" readonly/>
                                                        </div>
                                                        <div class="text-danger error_msg"></div>
                                                    </div>
                                                    <div class="col-lg-4 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">End Date<span
                                                                class="text-danger">*</span></label>
                                                        <div class="input-group input-group-merge">
                                                            <span class="input-group-text"><i
                                                                    class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                            <input type="text" id="work_end_date"
                                                                name="work_end_date[]"
                                                                class="form-control common_datepicker required-field"
                                                                placeholder="Select Date" value="" readonly/>
                                                        
                                                        </div>
                                                         <div class="text-danger error_msg"></div>
                                                    </div>
                                                    <div class="col-lg-12 mb-3">
                                                        <label class="text-black mb-1 fs-6 fw-semibold">Exit Reason<span class="text-danger">*</span></label>
                                                        <textarea class="form-control required-field" rows="1" name="ExitReason[]" placeholder="Enter Exit Reason"></textarea>
                                                         <div class="text-danger error_msg"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-1 d-flex align-items-center mt-2 justify-content-center">
                                                <div class="d-flex align-items-end mb-2 justify-content-end">
                                                    <a href="javascript:;"
                                                        class="btn text-danger px-2 py-1 staff_work_del"
                                                        style="display: none !important;">
                                                        <i class="fa-solid fa-trash-can fs-4"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="work-exp-div mb-4">
                            <div class="d-flex align-items-center justify-content-end">
                                <button type="button" class="btn btn-primary" id="add-work-btn">
                                    <i class="mdi mdi-plus me-1"></i>Add More
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Attachment Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div id="document-wrapper">
                            <div class="document-row bg-gray-200 rounded px-2 py-2 mb-2">
                                <div class="row">
                                    <div class="col-lg-11">
                                        <div class="row">
                                            <div class="col-lg-6 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Document Type</label>
                                                <select id="doc_type_0" name="doc_type[]"
                                                    class="select3 form-select required-field">
                                                    <option value="">Select Document Type</option>
                                                    @if(isset($documentTypeList))
                                                    @foreach($documentTypeList as $doc)
                                                    <option value="{{$doc->sno}}">{{$doc->document_name}}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                                                <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff_0"
                                                    style="background-color: #fff; border: 1px dotted #c94545;">
                                                    <div class="dz-message needsclick fs-6 text-center text-black me-3">
                                                        Drop files here or click to upload
                                                    </div>

                                                    <!-- Horizontal scroll container for previews -->
                                                    <div class="file-previews"></div>

                                                    <div class="fallback">
                                                        <input type="file" name="attachment[]" multiple class="required-field" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-1 d-flex align-items-center mt-2 justify-content-center">
                                        <div class="d-flex align-items-end mb-2 justify-content-end">
                                            <a href="javascript:;" class="btn text-danger px-2 py-1 staff_doc_del"
                                                style="display: none !important;">
                                                <i class="fa-solid fa-trash-can fs-4"></i>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-1 d-flex align-items-center justify-content-end">
                                <button type="button" class="btn btn-primary" id="add-doc-btn">
                                    <i class="mdi mdi-plus me-1"></i>Add More
                                </button>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary " id="prev6" onclick="safePrev(6)">
                            <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                            <span class="align-middle d-sm-inline-block d-none">Previous</span>
                        </button>
                        <button type="button" class="btn btn-primary " id="stage6" onclick="validation_func(6)">
                            <span class="align-middle d-sm-inline-block d-none me-sm-1" >Next</span>
                            <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div id="companydetails" class="content">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Company Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check form-check-inline mb-3">
                            <label class="form-check-label" for="management">
                                <input class="form-check-input required-field" type="radio" name="company"
                                    id="management" value="1" checked />
                                Management
                            </label>
                        </div>
                        <div class="form-check form-check-inline mb-3">
                            <label class="form-check-label" for="business">
                                <input class="form-check-input required-field" type="radio" name="company"
                                    id="business" value="2" />
                                Business
                            </label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 mb-3 business_div ">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                    class="text-danger">*</span></label>
                            <select id="staff_company_name" name="staff_company_name" class="select3 form-select required-field">
                                <option value="">Select Company Name</option>
                                    @if(isset($company_list))
                                    @foreach($company_list as $clist)
                                    <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                                    @endforeach
                                    @endif
                            </select>
                            <div class="text-danger error_msg"></div>
                        </div>
                        <div class="col-lg-4 mb-3 business_div">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                    class="text-danger">*</span></label>
                            <select id="entity_name" name="entity_name" class="select3 form-select required-field">
                                <option value="">Select Entity Name</option>
                            </select>
                            <div class="text-danger error_msg"></div>
                        </div>
                         <input type="hidden" name="erp_branch_id" id="erp_branch_id">
                         <input type="hidden" name="erp_department_id" id="erp_department_id">
                         <input type="hidden" name="erp_division_id" id="erp_division_id">
                         <input type="hidden" name="erp_job_role_id" id="erp_job_role_id">
                         <input type="hidden" name="erp_role_id" id="erp_role_id">
                         <input type="hidden" name="erp_under_role_id" id="erp_under_role_id">
                        <div class="col-lg-4 mb-3 business_div">
                            <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span
                                    class="text-danger">*</span></label>
                            <select id="branch_id" name="branch_id" class="select3 form-select required-field">
                                <option value="">Select Branch</option>
                            </select>
                            <div class="text-danger error_msg"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                    class="text-danger">*</span></label>
                            <div class="management_div err-chk">
                                <select name="management_depart" id="management_depart" class="select3 form-select required-field">
                                    <option value="">Select Department</option>
                                    @if(isset($management_department))
                                    @foreach($management_department as $depart)
                                    <option value="{{$depart->sno}}">{{$depart->department_name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                            <div class="business_div err-chk">
                                <select name="business_depart" id="business_depart" class="select3 form-select required-field">
                                    <option value="">Select Department</option>
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                        </div>

                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Division<span
                                    class="text-danger">*</span></label>
                            <div class="management_div err-chk">
                                <select name="management_division" id="management_division" class="select3 form-select required-field">
                                    <option value="">Select Division</option>
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                            <div class="business_div err-chk">
                                <select name="business_division" id="business_division" class="select3 form-select required-field">
                                    <option value="">Select Division</option>
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span
                                    class="text-danger">*</span></label>
                            <div class="management_div err-chk">
                                <select name="management_job_role" id="management_job_role" class="select3 form-select required-field">
                                    <option value="">Select Job Role</option>
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                            <div class="business_div err-chk">
                                <select name="business_job_role" id="business_job_role" class="select3 form-select required-field">
                                    <option value="">Select Job Role</option>
                                </select>
                                <div class="text-danger error_msg"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Designation Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pseudo Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field" id="pseudo_name"
                                    name="pseudo_name" placeholder="Enter Pseudo Name" />
                                    <div class="text-danger error_msg"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Date of Joining<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="staff_doj" name="doj" autocomplete="off"
                                        placeholder="Select Date" class="form-control common_datepicker required-field" readonly />
                                </div>
                                <div class="text-danger error_msg"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Basic Salary<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field" id="basic_salary"
                                    name="basic_salary" placeholder="Enter Basic Salary" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                                    <div class="text-danger error_msg"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Per Hour Cost<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control required-field" id="per_hr_cost"
                                    name="per_hr_cost" placeholder="Enter Per Hour Cost" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                                    <div class="text-danger error_msg"></div>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Skill Tag<span
                                        class="text-danger">*</span></label>
                                <div class="form-floating form-floating-outline">
                                    <input id="skill_tag" name="skill_tag"
                                        class="form-control h-auto skill_tag required-field"
                                        placeholder="Select Product Tags" value="">
                                        <div class="text-danger error_msg"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Credentials</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <div class="col-lg-4 err-chk">
                                <label class="fw-semibold mb-1 text-black">
                                    <span id="user_name_label">Login Credentials</span><span
                                        class="text-danger login_fields">*</span>
                                </label>
                                <input type="text" class="form-control login_fields required-field"
                                    id="loginuser_name" name="loginuser_name" placeholder="Enter User Name"
                                    value=""  onkeyup="user_name_chk(this.value)"/>
                                     <div class="text-danger error_msg" id="loginuser_name_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3 login_fields err-chk">
                                <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                        class="text-danger">*</span></label>
                                <div class="form-password-toggle">
                                    <div class="input-group input-group-merge">
                                        <input type="password" class="form-control required-field" id="loginpassword"
                                            name="loginpassword" placeholder="Enter Password" value=""
                                             />
                                        <span class="input-group-text cursor-pointer"><i
                                                class="mdi mdi-eye-off-outline fs-4"></i></span>
                                    </div>
                                     <div class="text-danger error_msg"></div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">User Role<span
                                        class="text-danger">*</span></label>
                                <div class="management_div err-chk">
                                    <select name="management_user_role" id="management_user_role" class="select3 form-select required-field">
                                        <option value="">Select User Role</option>
                                        @if(isset($management_user_role))
                                        @foreach($management_user_role as $role)
                                        <option value="{{$role->sno}}">{{$role->role_name}}</option>
                                        @endforeach
                                        @endif
                                    </select>
                                    <div class="text-danger error_msg"></div>
                                </div>
                                <div class="business_div err-chk">
                                    <select name="business_user_role" id="business_user_role" class="select3 form-select required-field">
                                        <option value="">Select User Role</option>
                                    </select>
                                    <div class="text-danger error_msg"></div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" id="other_access" value="1"
                                        name="other_access" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_other_credentials" />Other Credentials
                                </label>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 d-flex justify-content-between mt-4">
                    <button type="button" class="btn btn-outline-secondary " id="prev7" onclick="safePrev(7)"> <i
                            class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button type="button" class="btn btn-primary " id="stage7" onclick="validation_func(7)"> <span
                            class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                            class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                </div>
            </div>
            <div id="application_add" class="content ">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Applied For </label>
                    </div>
                    <div class="col-lg-6 mb-3 err-chk">
                        <label class="text-black mb-1 fs-6 fw-semibold">Select Position<span
                                class="text-danger">*</span></label>
                       <select id="applied_position" name="applied_position[]" class="select3 form-select required-field" multiple  data-placeholder="Select Position">
                            @if(isset($jobPositionlist))
                                <optgroup label="Technical Position" class="text-primary fw-bold">
                                    @foreach($jobPositionlist as $position)
                                        @if($position->job_type == 1)
                                            <option value="{{ $position->sno }}">{{ $position->job_position_name }}</option>
                                        @endif
                                    @endforeach
                                </optgroup>

                                <optgroup label="Non Technical Position" class="text-primary fw-bold">
                                    @foreach($jobPositionlist as $position)
                                        @if($position->job_type == 2)
                                            <option value="{{ $position->sno }}">{{ $position->job_position_name }}</option>
                                        @endif
                                    @endforeach
                                </optgroup>
                            @endif
                        </select>
                        <div class="text-danger error_msg"></div>
                    </div>

                    <div class="col-lg-6 mb-3 err-chk">
                        <label class="text-black mb-1 fs-6 fw-semibold">Staff Source<span
                                class="text-danger">*</span></label>
                        <select id="source_id" name="source_id" class="select3 form-select required-field">
                            <option value="">Select Source</option>
                                @foreach($source_list as $source)
                                        <option value="{{ $source->sno }}" data-detail="{{$source->detail_check ?? 0}}">{{ $source->source_name }}</option>
                             
                                @endforeach
                        </select>
                         <div class="text-danger error_msg"></div>
                    </div>

                    <div class="col-lg-6 mb-3 d-none err-chk" id="knowDetails">
                        <label class="text-black mb-1 fs-6 fw-semibold">Details</label>
                        <textarea class="form-control required-field" name="source_details" id="source_details" rows="1" placeholder="Enter Details"></textarea>
                        <div class="text-danger error_msg"></div>
                    </div>

                    <div class="col-lg-6 mb-3 err-chk">
                        <label class="text-black mb-1 fs-6 fw-semibold">Which Elysium Group Of Company Are You Attending
                            ?<span class="text-danger">*</span></label>
                        <select id="interview_company" name="interview_company[]" class="select3 form-select required-field"
                            multiple data-placeholder="Select Company">
                            <option value="">Select Attending Company</option>
                             @if(isset($company_list))
                            @foreach($company_list as $clist)
                            <option value="{{$clist->sno}}">{{$clist->company_name}}</option>
                            @endforeach
                            @endif
                        </select>
                        <div class="text-danger error_msg"></div>
                    </div>
                    <!-- dynamic  Questions -->
            
                 {{-- Dynamic Questions --}}
                    @foreach($questions as $question)
                        {{-- Parent Question --}}
                        <div class="col-lg-6 mb-3 dynamic-question" id="question_{{ $question->sno }}">
                            <label class="text-black mb-1 fs-6 fw-semibold">
                                {{ $question->field_name }}
                                @if($question->is_mandatory)<span class="text-danger">*</span>@endif
                            </label>

                            @php $options = json_decode($question->field_option, true) ?? []; @endphp

                            {{-- ✅ Handle all field types --}}
                            @switch($question->field_value)

                                @case('text_field')
                                    <input type="text" 
                                        class="form-control hrq-field"
                                        name="q_{{ $question->sno }}"
                                        data-question="{{ $question->sno }}"
                                        placeholder="Enter {{ $question->field_name }}">
                                    @break

                                @case('text_area')
                                    <textarea class="form-control hrq-field"
                                            name="q_{{ $question->sno }}"
                                            data-question="{{ $question->sno }}"
                                            rows="3"
                                            placeholder="Enter {{ $question->field_name }}"></textarea>
                                    @break

                                @case('date_field')
                                    <input type="date" 
                                        class="form-control hrq-field"
                                        name="q_{{ $question->sno }}"
                                        data-question="{{ $question->sno }}">
                                    @break

                                @case('multiple_images')
                                    <input type="file"
                                        class="form-control hrq-field"
                                        name="q_{{ $question->sno }}[]"
                                        data-question="{{ $question->sno }}"
                                        accept="image/*"
                                        multiple>
                                    @break

                                @case('check_box')
                                    <div class="d-block">
                                        @foreach($options as $opt)
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input hrq-field"
                                                    type="checkbox"
                                                    name="q_{{ $question->sno }}[]"
                                                    value="{{ $opt['label'] }}"
                                                    data-question="{{ $question->sno }}">
                                                <label class="form-check-label">{{ $opt['label'] }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                    @break

                                @case('radio_button')
                                    <div class="d-block">
                                        @foreach($options as $index => $opt)
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input hrq-field"
                                                    type="radio"
                                                    name="q_{{ $question->sno }}"
                                                    value="{{ $opt['label'] }}"
                                                    data-question="{{ $question->sno }}"
                                                    {{ $index === 0 ? 'checked' : '' }}>
                                                <label class="form-check-label">{{ $opt['label'] }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                    @break

                                @case('list_box')
                                    <select class="form-select select3 hrq-field" 
                                            name="q_{{ $question->sno }}"
                                            data-question="{{ $question->sno }}">
                                        <option value="">Select {{$question->field_name}}</option>
                                        @foreach($options as $opt)
                                            <option value="{{ $opt['label'] }}">{{ $opt['label'] }}</option>
                                        @endforeach
                                    </select>
                                    @break

                            @endswitch
                        </div>

                        {{-- Dependent Questions --}}
                        @foreach($question->depends as $depend)
                            @php $dep_options = json_decode($depend->field_option, true) ?? []; @endphp
                            <div class="col-lg-6 mb-3 dependent-question d-none"
                                id="depend_{{ $depend->sno }}"
                                data-parent="{{ $question->sno }}"
                                data-trigger='{{ $depend->depends_on }}'>

                                <label class="text-black mb-1 fs-6 fw-semibold">
                                    {{ $depend->field_name }}
                                    @if($depend->is_mandatory)<span class="text-danger">*</span>@endif
                                </label>

                                {{-- ✅ Same logic for dependents --}}
                                @switch($depend->field_value)

                                    @case('text_field')
                                        <input type="text" name="depend_{{ $depend->sno }}" class="form-control" placeholder="Enter {{ $depend->field_name }}">
                                        @break

                                    @case('text_area')
                                        <textarea class="form-control" name="depend_{{ $depend->sno }}" rows="3" placeholder="Enter {{ $depend->field_name }}"></textarea>
                                        @break

                                    @case('date_field')
                                        <input type="date" name="depend_{{ $depend->sno }}" class="form-control">
                                        @break

                                    @case('multiple_images')
                                        <input type="file" class="form-control" name="depend_{{ $depend->sno }}[]" multiple accept="image/*">
                                        @break

                                    @case('check_box')
                                        <div class="d-block">
                                            @foreach($dep_options as $opt)
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="checkbox" value="{{ $opt['label'] }}" name="depend_{{ $depend->sno }}[]">
                                                    <label class="form-check-label">{{ $opt['label'] }}</label>
                                                </div>
                                            @endforeach
                                        </div>
                                        @break

                                    @case('radio_button')
                                        <div class="d-block">
                                            @foreach($dep_options as $index => $opt)
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" 
                                                        name="depend_{{ $depend->sno }}" 
                                                        value="{{ $opt['label'] }}" 
                                                        {{ $index === 0 ? 'checked' : '' }}>
                                                    <label class="form-check-label">{{ $opt['label'] }}</label>
                                                </div>
                                            @endforeach
                                        </div>
                                        @break

                                    @case('list_box')
                                        <select class="form-select select3" name="depend_{{ $depend->sno }}">
                                            <option value="">Select {{ $depend->field_name }}</option>
                                            @foreach($dep_options as $opt)
                                                <option value="{{ $opt['label'] }}">{{ $opt['label'] }}</option>
                                            @endforeach
                                        </select>
                                        @break

                                @endswitch
                            </div>
                        @endforeach
                    @endforeach

                </div>

                <div class="col-12 d-flex justify-content-between mt-4">
                    <button type="button" class="btn btn-outline-secondary " id="prev8" onclick="safePrev(8)">
                        <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button type="button" class="btn btn-primary " id="stage8" onclick="validation_func(8)">
                        <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                        <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                    </button>
                </div>
            </div>
            <div id="checklist_add" class="content">
                <div class="row">
                    <div class="col-lg-12 d-flex align-items-center justify-content-end mb-5">
                        <div class="form-check mb-2">
                            <input class="form-check-input ignore-progress" type="checkbox" id="selectAll">
                            <label class="form-check-label fw-semibold" for="selectAll">Select All</label>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div style="max-height: 300px; overflow-y: auto;">
                            @if(isset($documentCheckList))
                                @foreach($documentCheckList as $checklist)
                                    <div class="form-check mb-3">
                                        <input class="form-check-input checklist-item start-field" type="checkbox" value="{{$checklist->sno}}" name="document_checked[]"
                                            id="check_{{$checklist->sno}}">
                                        <label class="form-check-label" for="check_{{$checklist->sno}}">{{$checklist->document_checklist}}</label>
                                    </div>
                                @endforeach
                            @endif
                        </div>
                    </div>

                    <div class="col-12 d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary " id="prev9" onclick="safePrev(9)">Previous</button>
                        <button type="button" class="btn btn-primary " id="stage9" onclick="validation_func(9)">Next</button>
                    </div>
                </div>
            </div>
            <div id="orientation" class="content active">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="accordion" id="pending-tasks">
                            <!-- First Mile -->
                            <div class="accordion-item mb-3 rounded">
                                <h2 class="accordion-header" id="headingOne">
                                    <button type="button" class="accordion-button collapsed bg-label-success"
                                        data-bs-toggle="collapse" data-bs-target="#accordionOne" aria-expanded="false"
                                        aria-controls="accordionOne">
                                        <label class="text-black fs-5 fw-semibold">First Mile</label>
                                        <span class="badge bg-warning text-black fs-7 fw-semibold ms-2"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                                            title="Stage Completed Date">30-Sep-2025</span>
                                    </button>
                                </h2>
                                <div id="accordionOne" class="accordion-collapse collapse"
                                    data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col-lg-4 mb-3">
                                                <label class="text-black fs-6 mb-1 fw-semibold">Score<span
                                                        class="text-danger">*</span></label>
                                                <input type="text" class="form-control start-field" name="orientation_score[]"
                                                    placeholder="Enter Score" />
                                                    <div class="text-danger error_msg"></div>
                                            </div>
                                            <div class="col-lg-6 mb-3">
                                                <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span
                                                        class="text-danger">*</span></label>
                                                <select class="select3 form-select start-field" name="orientation_score[]">
                                                    <option value="">Select Staff Name</option>
                                                    @if(isset($staff_list))
                                                    @foreach($staff_list as $staff)
                                                    <option value="">{{$staff->staff_name}} ({{$staff->entity_short_name ??'EGC'}}) - {{$staff->job_role_name}}</option>
                                                    @endforeach
                                                    @endif
                                                </select>
                                                <div class="text-danger error_msg"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 d-flex justify-content-between mt-4">
                            <button type="button" class="btn btn-outline-secondary " id="prev10" onclick="safePrev(10)">
                                <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                                <span class="align-middle d-sm-inline-block d-none">Previous</span>
                            </button>
                            <button type="button" class="btn btn-primary " id="stage10" onclick="validation_func(10)">
                                <span class="align-middle d-sm-inline-block d-none me-sm-1">Add Staff</span>
                                <i class="icon-base ri ri-arrow-right-line icon-sm"></i>
                            </button>
                            <input type="hidden" name="submit_popup" id="submit_popup" data-bs-toggle="modal"
                                    data-bs-target="#kt_modal_confirmation_staff">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </form>

    <div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content">?</div>
                </div>
                <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want
                    to
                    Create Staff ?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label id="create_staff_label"></label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8">
                    <a href="javascript:;" id="submitStaffBtn" class="btn btn-primary me-3" onclick="submit_form()">
                        <span id="yesBtnText">Yes</span>
                        <span id="yesBtnLoader" style="display: none;" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    </a>
                    <a href="#" class="btn btn-secondary" data-bs-dismiss="modal">No</a>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>

    <!--begin::Modal - Other Credentials-->
    <div class="modal fade" id="kt_modal_other_credentials" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <div class="modal-dialog modal-lg">
            <div class="modal-content rounded">
                <div class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Other Credentials</h3>
                    </div>
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded border border-black"
                        data-bs-dismiss="modal">
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                    </div>
                </div>

                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="row mt-2">
                        <div class="col-lg-12 mb-3">
                            @if(isset($credential_list) && count($credential_list) > 0)
                                @foreach($credential_list as $cred)
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input cred_check" type="checkbox"
                                            id="cred_{{$cred->sno}}" data-cred="{{$cred->sno}}" />
                                        <label class="text-black mb-1 fs-6 fw-semibold">
                                            {{$cred->credential_name}}
                                        </label>
                                    </div>
                                @endforeach
                            @endif
                        </div>

                        @if(isset($credential_list))
                            @foreach($credential_list as $cred)
                                <div class="mb-2" id="cred_field_{{$cred->sno}}" style="display:none;">
                                    <h5 class="title fw-bold mt-2">{{$cred->credential_name}} Credentials</h5>
                                    <div class="row mt-2">
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control"
                                                name="credential[{{$cred->sno}}][username]"
                                                placeholder="Enter User Name" />
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control"
                                                name="credential[{{$cred->sno}}][password]"
                                                placeholder="Enter Password" />
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                            <input type="text" class="form-control"
                                                name="credential[{{$cred->sno}}][url]"
                                                placeholder="Enter URL" />
                                        </div>
                                        <div class="col-lg-3 mb-3">
                                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                            <textarea class="form-control" rows="1"
                                                name="credential[{{$cred->sno}}][description]"
                                                placeholder="Enter Description">-</textarea>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @endif
                    </div>

                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <button type="button" class="btn btn-outline-danger me-3"
                            data-bs-dismiss="modal">Cancel</button>
                       <button type="button" class="btn btn-primary" id="btn_give_access">Give Access</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end::Modal - Other Credentials-->


    <!--begin::Modal - Confirmation Staff-->
    <div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content"><i class="mdi mdi-check fs-1"></i></div>
                </div>
                <div class="swal2-html-container mb-2" id="swal2-html-container" style="display: block;">Are you sure
                    you
                    want to
                    Create Staff ?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label class="text-black">Mahesh</label>
                        <span class="ms-2 me-2">-</span>
                        <label class="text-black">EGCS-0001/24</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8 mb-4">
                    <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-success me-3">Yes</a>
                    <a href="#" class="btn btn-outline-danger" data-bs-dismiss="modal">No</a>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Confirmation Staff-->



    <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>

  <script>
$(document).ready(function() {
    // Toggle credential fields in modal
    $('.cred_check').on('change', function() {
        const credId = $(this).data('cred');
        if ($(this).is(':checked')) {
            $('#cred_field_' + credId).slideDown();
        } else {
            $('#cred_field_' + credId).slideUp();
        }
    });

    // Auto-open modal when checkbox checked
    $('#other_access').on('change', function() {
        if ($(this).is(':checked')) {
            $('#kt_modal_other_credentials').modal('show');
        } else {
            // Remove hidden inputs when unchecked
            $('input[name^="credential["], textarea[name^="credential["]').remove();
        }
    });

    // When modal is reopened, restore visibility for already checked creds
    $('#kt_modal_other_credentials').on('show.bs.modal', function() {
        $('.cred_check').each(function() {
            const credId = $(this).data('cred');
            if ($(this).is(':checked')) {
                $('#cred_field_' + credId).show();
            }
        });
    });

    // Validate and save credential data on "Give Access" button click
    $('#btn_give_access').on('click', function() {
        let valid = true;

        // Validate visible credential fields
        $('.cred_check:checked').each(function() {
            const credId = $(this).data('cred');
            const username = $(`input[name="credential[${credId}][username]"]`).val().trim();
            const password = $(`input[name="credential[${credId}][password]"]`).val().trim();

            if (username === '' || password === '') {
                valid = false;
                $(`#cred_field_${credId}`).find('input').addClass('is-invalid');
            } else {
                $(`#cred_field_${credId}`).find('input').removeClass('is-invalid');
            }
        });

        if (!valid) {
            alert('Please fill required Username and Password for selected credentials.');
            return;
        }

        // Remove old hidden credentials before adding new ones
        $('#staff_form').find('input[name^="credential["], textarea[name^="credential["]').remove();

        // Append selected credential data as hidden inputs
        $('.cred_check:checked').each(function() {
            const credId = $(this).data('cred');
            const fields = ['username', 'password', 'url', 'description'];

            fields.forEach(field => {
                const value = $(`input[name="credential[${credId}][${field}]"], textarea[name="credential[${credId}][${field}]"]`).val();
                $('<input>').attr({
                    type: 'hidden',
                    name: `credential[${credId}][${field}]`,
                    value: value
                }).appendTo('#staff_form');
            });
        });

        // Close modal after save
        $('#kt_modal_other_credentials').modal('hide');
    });
});
</script>



    <script>
        var pendingtasks = document.querySelector('#pending-tasks');
        // var completedtasks = document.querySelector('#completed-tasks');
        new Sortable(pendingtasks, {
            animation: 150,
            group: 'tasklist'
        });

        // new Sortable(completedtasks, {
        //     animation: 150,
        //     group: 'tasklist'
        // });
    </script>

    <script>
        document.getElementById('selectAll').addEventListener('change', function() {
            const checked = this.checked;
            document.querySelectorAll('.checklist-item').forEach(item => {
                item.checked = checked;
            });
        });
    </script>

     <script>
        $(document).ready(function() {
            // Run once on load
            toggleDivs();

            // Change event on radio buttons
            $("input[name='company']").on("change", function() {
                toggleDivs();
            });

            function toggleDivs() {
                if ($("#management").is(":checked")) {
                    $(".management_div").show();
                    $(".business_div").hide();
                } else if ($("#business").is(":checked")) {
                    $(".business_div").show();
                    $(".management_div").hide();
                }
            }
        });
    </script>

    <script>
        $(document).ready(function () {
            let eduIndex = 1; // for unique IDs

            // Initialize first select2
            $(".select3").select2();

            // Add new education row
            $("#add-edu-btn").click(function () {
                let clone = $(".education-row:first").clone(false, false);

                // Clear input values
                clone.find("input").val("");
                clone.find("select").val("").trigger("change");

                // Remove select2 container
                clone.find(".select2").remove();
                let newSelect = clone.find("select.select3");

                // Assign unique ID
                newSelect.attr("id", "qualification_type_" + eduIndex);

                // Update input IDs to be unique
                clone.find('input[name="degree[]"]').attr("id", "degree_" + eduIndex);
                clone.find('input[name="major[]"]').attr("id", "major_" + eduIndex);
                clone.find('input[name="univ_name[]"]').attr("id", "univ_name_" + eduIndex);
                clone.find('input[name="pass_year[]"]').attr("id", "pass_year_" + eduIndex);

                // Add error message placeholders (if not present)
                clone.find(".error_msg").remove();
                clone.find(".form-control, .form-select").each(function () {
                    $(this).after('<div class="text-danger error_msg"></div>');
                });

                // Re-init select2
                newSelect.select2();

                // Show delete button
                clone.find(".staff_edu_del").show();

                // Append to wrapper
                $("#education-wrapper").append(clone);

                eduIndex++;
            });

            // Delete Education Row
            $(document).on("click", ".staff_edu_del", function () {
                $(this).closest(".education-row").remove();
            });

            
        });
    </script>



    <script>
        $(document).ready(function() {
            // Hide wrapper by default
            $("#work-exp-wrapper").hide();
            $("#add-work-btn").hide();
            $(".work-exp-div").hide();

            // Handle type change
            $("#work_type").change(function() {
                if ($(this).val() === "2") {
                    // Experience selected
                    $("#work-exp-wrapper").show();
                    $("#add-work-btn").show();
                    $(".work-exp-div").show();
                } else {
                    // Fresher selected
                    $("#work-exp-wrapper").hide();
                    $("#add-work-btn").hide();
                    $(".work-exp-div").hide();

                    // Reset rows to only the first one (clean form)
                    $("#work-exp-wrapper .work-exp-row:not(:first)").remove();
                    $("#work-exp-wrapper")
                        .find("input")
                        .val(""); // clear inputs
                    $("#work-exp-wrapper .staff_work_del").hide(); // hide delete button in first row
                }
            });

            // Add More Work Experience
            $("#add-work-btn").click(function() {
                let clone = $(".work-exp-row:first").clone(false, false);

                // clear values
                clone.find("input").val("");

                // show delete button
                clone.find(".staff_work_del").show();

                // append
                $("#work-exp-wrapper").append(clone);

                // re-init datepicker if needed
                clone.find(".common_datepicker").datepicker({
                    format: "yyyy-mm-dd",
                    autoclose: true,
                    todayHighlight: true
                });
            });

            // Delete Work Row
            $(document).on("click", ".staff_work_del", function() {
                $(this).closest(".work-exp-row").remove();
            });

            // Initialize first datepickers
            $(".common_datepicker").datepicker({
                format: "yyyy-mm-dd",
                autoclose: true,
                todayHighlight: true
            });
        });
    </script>

  

    <script>
        $(document).ready(function () { 
            function initDropzone(selector, dropzoneElement) {
                const previewContainer = dropzoneElement.find(".file-previews");

                // Create a hidden input to store uploaded filenames
                const hiddenInput = $('<input>', {
                    type: 'hidden',
                    name: 'uploaded_files[]'
                });
                dropzoneElement.append(hiddenInput);

                new Dropzone(selector, {
                    url: "/upload-temp-documentstaff",
                    method: "POST",
                    paramName: "file",
                    autoProcessQueue: true,
                    previewsContainer: previewContainer[0],
                    addRemoveLinks: true,
                    acceptedFiles: null, // accept all file types
                    maxFilesize: 20, // 20 MB
                    previewTemplate: `
                        <div class="dz-preview dz-file-preview">
                            <div class="dz-image">
                                <img data-dz-thumbnail />
                                <div class="dz-progress"><span class="dz-upload" data-dz-uploadprogress></span></div>
                                <div class="dz-success-mark text-success"></div>
                                <div class="dz-error-mark text-danger"></div>
                            </div>
                            <div class="dz-details">
                                <div class="dz-filename"><span data-dz-name></span></div>
                                <div class="dz-size" data-dz-size></div>
                            </div>
                            <a class="dz-remove" href="javascript:void(0);" data-dz-remove>×</a>
                        </div>
                    `,
                    init: function () {
                        this.on("sending", function (file, xhr, formData) {
                            // Log file name before uploading
                            console.log("Uploading file:", file.name, file);

                            // CSRF token for Laravel
                            formData.append("_token", $('meta[name="csrf-token"]').attr("content"));
                        });

                        this.on("success", function (file, response) {
                            // Normalize response safely
                            let res = response;
                            if (typeof response === 'string') {
                                try {
                                    res = JSON.parse(response);
                                } catch (err) {
                                    // Not JSON -> treat as plain message
                                    res = { status: false, message: response };
                                }
                            }

                            // Debug print object (don't concat objects with +)
                            console.log("file:", file, "response:", res);

                            if (res && res.status) {
                                file.serverFileName = res.filename;
                                // remove any previous error class and add success
                                if (file.previewElement) {
                                    file.previewElement.classList.remove('dz-error');
                                    file.previewElement.classList.add('dz-success');
                                }

                                // Store filename in hidden input
                                const current = hiddenInput.val() ? JSON.parse(hiddenInput.val()) : [];
                                current.push(res.filename);
                                hiddenInput.val(JSON.stringify(current));

                                console.log("✅ Uploaded successfully:", res.filename);
                            } else {
                                // Provide a clear message to Dropzone error handler
                                const msg = (res && res.message) ? res.message : 'Upload failed';
                                // Mark preview as error and show message
                                if (file.previewElement) {
                                    file.previewElement.classList.remove('dz-success');
                                    file.previewElement.classList.add('dz-error');
                                }
                                // Emit a proper error so Dropzone can show the error UI
                                this.emit("error", file, msg);
                                console.error("Upload error:", msg);
                            }
                        });

                        this.on("error", function (file, errorMessage) {
                            if (file.previewElement) {
                                file.previewElement.classList.add("dz-error");
                            }
                            console.error("❌ Upload failed:", errorMessage);
                        });

                        this.on("removedfile", function (file) {
                            if (file.serverFileName) {
                                // Update hidden input
                                const current = hiddenInput.val() ? JSON.parse(hiddenInput.val()) : [];
                                const updated = current.filter(f => f !== file.serverFileName);
                                hiddenInput.val(JSON.stringify(updated));

                                console.log("🗑️ Removing file:", file.serverFileName);

                                // AJAX call to delete from temp folder
                                $.ajax({
                                    url: "/delete-temp-documentstaff",
                                    type: "POST",
                                    data: {
                                        filename: file.serverFileName,
                                        _token: $('meta[name="csrf-token"]').attr("content")
                                    },
                                    success: function (res) {
                                        if (res.status) {
                                            console.log("✅ Deleted from temp:", res.message);
                                        } else {
                                            console.warn("⚠️ Delete failed:", res.message);
                                        }
                                    },
                                    error: function (xhr) {
                                        console.error("❌ Server error deleting file:", xhr.responseText);
                                    }
                                });
                            }
                        });
                    },
                });
            }


            // Initialize the first Dropzone
            initDropzone("#dropzone-multi_staff_0", $(".document-row:first .dropzone"));

            // Add document row dynamically
            $("#add-doc-btn").click(function () {
                let cloneIndex = $("#document-wrapper .document-row").length;
                let clone = $(".document-row:first").clone(false, false);

                clone.find("select").val("");
                clone.find(".file-previews").empty();
                clone.find("input[type=file]").val("");
                clone.find(".staff_doc_del").show();

                clone.find("select").attr("id", `doc_type_${cloneIndex}`);
                clone.find(".dropzone").attr("id", `dropzone-multi_staff_${cloneIndex}`);

                $("#document-wrapper").append(clone);
                clone.find("select").select2();
                initDropzone(`#dropzone-multi_staff_${cloneIndex}`, clone.find(".dropzone"));
            });

            // Delete document row
            $(document).on("click", ".staff_doc_del", function () {
                $(this).closest(".document-row").remove();
            });

            $("#doc_type_0").select2();
        });
    </script>


    <script>
        $(document).ready(function() {
            let courseIndex = 1;

            // Initialize Select2 for first dropdown
            $(".course-select").select2();

            // Toggle visibility based on Yes/No selection
            $('input[name="is_Course"]').on('change', function() {
                if ($(this).val() === 'Yes') {
                    $('#courseAttachmentHeader, #courseDocumentWrapper, #addCourseBtnWrapper').removeClass(
                        'd-none');
                } else {
                    $('#courseAttachmentHeader, #courseDocumentWrapper, #addCourseBtnWrapper').addClass(
                        'd-none');
                }
            });

            // Add new course row
            $("#add-course-btn").click(function() {
                let clone = $(".course-document-row:first").clone(false, false);
                clone.find("input, select").val("");

                // remove any existing Select2 DOM
                clone.find(".select2").remove();
                let newSelect = clone.find("select.course-select");
                newSelect.attr("id", "course_doc_type_" + courseIndex);
                newSelect.show();
                newSelect.select2();
                courseIndex++;

                // show delete button
                clone.find(".course_doc_del").show();

                // append to wrapper
                $("#courseDocumentWrapper").append(clone);
            });

            // Delete course row
            $(document).on("click", ".course_doc_del", function() {
                $(this).closest(".course-document-row").remove();
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#marital_status').on('change', function() {
                if ($(this).val() === '2') {
                    $('.spouse-field').removeClass('d-none');
                } else {
                    $('.spouse-field').addClass('d-none');
                }
            });
        });
    </script>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const yesRadio = document.getElementById("childrenYes");
            const noRadio = document.getElementById("childrenNo");
            const childrenSections = document.querySelectorAll(".children-section");

            function toggleChildrenFields() {
                childrenSections.forEach(section => {
                    if (yesRadio.checked) {
                        section.classList.remove("d-none");
                    } else {
                        section.classList.add("d-none");
                    }
                });
            }

            yesRadio.addEventListener("change", toggleChildrenFields);
            noRadio.addEventListener("change", toggleChildrenFields);
        });
    </script>

    <script>
        $(document).ready(function() {
            $('input[name="is_working"]').on('change', function() {
                if ($(this).val() === 'Yes') {
                    $('.working-fields').removeClass('d-none');
                } else {
                    $('.working-fields').addClass('d-none');
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            $('input[name="has_Siblings"]').on('change', function() {
                if ($(this).val() === 'Yes') {
                    $('#siblingsDescription').removeClass('d-none');
                } else {
                    $('#siblingsDescription').addClass('d-none');
                }
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('#work_type').on('change', function() {
                if ($(this).val() === '2') {
                    $('.shiftedCompanyField').removeClass('d-none');
                } else {
                    $('.shiftedCompanyField').addClass('d-none');
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            $('#source_id').on('change', function () {
                // Get the selected option
                const selectedOption = $(this).find(':selected');

                // Get the data-detail attribute value
                const detailCheck = selectedOption.data('detail');

                // Show or hide based on data-detail == 1
                if (detailCheck == 1) {
                    $('#knowDetails').removeClass('d-none');
                } else {
                    $('#knowDetails').addClass('d-none');
                }
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('input[name="is_MinimumWork"]').on('change', function() {
                if ($('#MinimumWorkNo').is(':checked')) {
                    $('#minimumWorkReason').removeClass('d-none');
                } else {
                    $('#minimumWorkReason').addClass('d-none');
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            $('input[name="is_OriginalCertificate"]').on('change', function() {
                if ($('#OriginalCertificateNo').is(':checked')) {
                    $('#originalCertificateReason').removeClass('d-none');
                } else {
                    $('#originalCertificateReason').addClass('d-none');
                }
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('input[name="is_Travel"]').on('change', function() {
                if ($('#TravelNo').is(':checked')) {
                    $('#travelReason').removeClass('d-none');
                } else {
                    $('#travelReason').addClass('d-none');
                }
            });
        });
    </script>


    <script>
        document.getElementById('childrenCount').addEventListener('input', function() {
            const count = parseInt(this.value);
            const container = document.getElementById('childrenDetails');
            container.innerHTML = ''; // Clear previous fields

            if (!isNaN(count) && count > 0) {
                for (let i = 1; i <= count; i++) {
                    const childDiv = document.createElement('div');
                    childDiv.classList.add('row', 'mb-3', 'border', 'rounded', 'p-3', 'bg-gray-200');

                    childDiv.innerHTML = `
                    <div class="col-lg-3 err-chk">
                        <label class="text-black fs-6 fw-semibold">Child ${i} Name<span class="text-danger">*</span></label>
                        <input type="text" name="child_name[]" class="form-control" placeholder="Enter Name">
                        <div class="text-danger error_msg"></div>
                    </div>
                    <div class="col-lg-3 err-chk">
                        <label class="text-black fs-6 fw-semibold">Date of Birth<span class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" name="child_dob[]" placeholder="Select Date"
                                class="form-control common_datepicker" value="" readonly/>
                        </div>
                        <div class="text-danger error_msg"></div>
                    </div>
                    <div class="col-lg-3 err-chk">
                        <label class="text-black fs-6 fw-semibold">Standard / Degree<span class="text-danger">*</span></label>
                        <input type="text" name="child_std[]" class="form-control" placeholder="e.g. 12th std / BSc">
                        <div class="text-danger error_msg"></div>
                    </div>
                    <div class="col-lg-3 err-chk">
                        <label class="text-black fs-6 fw-semibold">Completion Year<span class="text-danger">*</span></label>
                        <input type="text" name="child_year[]" class="form-control" placeholder="e.g. 2025" min="2000" max="2099">
                        <div class="text-danger error_msg"></div>
                    </div>
                `;
                    container.appendChild(childDiv);

                    // Initialize Bootstrap Datepicker for the new input
                    $(childDiv).find('.common_datepicker').datepicker({
                        todayHighlight: true,
                        autoclose: true,
                        format: 'dd-M-yyyy',
                        endDate: new Date() // Prevent future dates
                    });
                }
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            // When any checkbox with class .toggle-field is changed
            $('.toggle-field').on('change', function() {
                var target = $(this).data('target'); // get the target div ID

                if ($(this).is(':checked')) {
                    $(target).removeClass('d-none').hide().slideDown(200); // show field smoothly
                } else {
                    $(target).slideUp(200, function() {
                        $(this).addClass('d-none'); // hide and reapply d-none
                        $(this).find('input').val(''); // clear input value when unchecked
                    });
                }
            });
        });
    </script>


 {{-- progress --}}
<script>

  const stepIds = [
    "staff_add",
    "family_add",
    "contact_add",
    "socialmedia",
    "Education",
    "work_add",
    "companydetails",
    "application_add",
    "checklist_add",
    "orientation"
  ];

  /** 🔍 Check if element is visible */
  function isVisible(el) {
    if (el.classList.contains("select2-search__field")) return false;
    return !!(el.offsetParent !== null && !el.classList.contains("d-none"));
  }

  /** 🔍 Exclude irrelevant fields */
  function shouldExclude(el) {
    if (el.classList.contains("select2-search__field")) return true;
    if (el.closest(".select2-container")) return true;
    return false;
  }

  /** ✅ Calculate step progress (with console logging) */
  function calculateStepPercentage(stepId) {
    const section = document.getElementById(stepId);
    if (!section || section.classList.contains("d-none") || section.style.display === "none") return 0;

    const fields = section.querySelectorAll(
      'input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=reset]), select, textarea, .common_datepicker'
    );

    if (!fields.length) return 0;

    let total = 0;
    let filled = 0;

    console.group(`🧩 Step: ${stepId}`);

   fields.forEach(f => {
    const name = f.name || f.id || f.className;
    if (shouldExclude(f)) return;
    if (f.hasAttribute('data-ignore-total')) return;
    if (f.type === "radio") return;
    if (f.classList.contains("ignore-progress")) return;

    // 🚀 Skip hidden elements
    if (!isVisible(f)) return;

    total++;
    let isFilled = false;
    
    if (f.type === "file" && f.files.length > 0) isFilled = true;
    else if (f.type === "checkbox" && f.checked) isFilled = true;
    else if (f.tagName === "SELECT" && f.value !== "") isFilled = true;
    else if (f.classList.contains("common_datepicker") && f.value.trim() !== "") isFilled = true;
    else if ((f.tagName === "INPUT" || f.tagName === "TEXTAREA") && f.value.trim() !== "") isFilled = true;

    if (isFilled) filled++;
    });

    const percent = total > 0 ? Math.round((filled / total) * 100) : 0;
    console.log(`📊 Step: ${stepId} | Total: ${total} | Filled: ${filled} | % = ${percent}`);
    console.groupEnd();

    // Update only this step’s progress bar
    const progressBar = document.querySelector(`.step-progress[data-step="${stepId}"] .progress-bar`);
    if (progressBar) {
      progressBar.style.width = percent + "%";
      progressBar.setAttribute("aria-valuenow", percent);
      progressBar.textContent = percent + "%";

      progressBar.classList.remove("bg-success", "bg-warning", "bg-secondary");
      if (percent >= 90) progressBar.classList.add("bg-success");
      else if (percent > 0) progressBar.classList.add("bg-warning");
      else progressBar.classList.add("bg-secondary");
    }

    return percent;
  }

  /** ✅ Calculate total % (lightweight, no console spam) */
  function calculateTotalPercentage(form) {
    if (!form) return 0;
    const fields = form.querySelectorAll(
      'input:not([type=hidden]):not([type=button]):not([type=submit]):not([type=reset]):not([type=radio]), select, textarea, .common_datepicker'
    );
    let total = 0, filled = 0;
    fields.forEach(f => {
      if (shouldExclude(f)) return;
      if (f.hasAttribute('data-ignore-total')) return;
      total++;
      if (f.type === "file" && f.files.length > 0) filled++;
      else if (f.type === "checkbox" && f.checked) filled++;
      else if (f.tagName === "SELECT" && f.value !== "") filled++;
      else if (f.classList.contains("common_datepicker") && f.value.trim() !== "") filled++;
      else if ((f.tagName === "INPUT" || f.tagName === "TEXTAREA") && f.value.trim() !== "") filled++;
    });
    return total > 0 ? Math.round((filled / total) * 100) : 0;
  }

  /** ✅ Update only the active step */
  function updateStepPercentage(stepId) {
    const form = document.getElementById("staff_form");
    if (!form || !stepId) return;
    calculateStepPercentage(stepId);

    // Update hidden total field
    const total = calculateTotalPercentage(form);
    const hiddenInput = form.querySelector(".form-percentage");
    if (hiddenInput) hiddenInput.value = total;
  }

  /** ✅ Attach event listeners for real-time update of current step */
  function attachStepListeners(stepId) {
    const form = document.getElementById("staff_form");
    if (!form) return;

    form.addEventListener("input", e => {
      if (e.target.closest(`#${stepId}`)) {
        if (e.target.matches("input, textarea, .common_datepicker")) updateStepPercentage(stepId);
      }
    });

    form.addEventListener("change", e => {
      if (e.target.closest(`#${stepId}`)) {
        if (e.target.matches("select, .change-data, input[type=checkbox], .common_datepicker, input[type=file]"))
          updateStepPercentage(stepId);
      }
    });

    if (window.jQuery) {
      $(`#${stepId} .common_datepicker`).on("changeDate change", () => updateStepPercentage(stepId));
      $(`#${stepId} .select3`).on("change.select2 select2:select select2:unselect", () => updateStepPercentage(stepId));
    }

    // Run once initially
    updateStepPercentage(stepId);
  }
</script>



<script>
    function submit_form() {
        const form = document.getElementById("staff_form");
        const submitBtn = document.getElementById("submitStaffBtn");
        const submitBtnText = document.getElementById("yesBtnText");
        const submitBtnLoader = document.getElementById("yesBtnLoader");

        if (form) {
            // Disable the button to prevent duplicate submission
            submitBtn.disabled = true;
            submitBtnText.style.display = "none"; // Hide "Yes"
            submitBtnLoader.style.display = "inline-block"; // Show loader

            const total = calculateTotalPercentage(form);
            $('#completion_percentage').val(total);

            // ✅ Create FormData manually
            const formData = new FormData(form);

            // ✅ Loop through all Dropzones and append files
            Dropzone.instances.forEach((dz, index) => {
                dz.files.forEach((file, i) => {
                    formData.append(`attachment[${index}][]`, file);
                });
            });

            // ✅ Send via AJAX (so files are sent correctly)
            $.ajax({
                url: form.action,
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    console.log("Success:", response);
                    window.location.href = '/hr_enroll/manage_staff';
                },
                error: function(err) {
                    console.error("Error:", err);
                    // In case of an error, re-enable the button and reset the text
                    submitBtn.disabled = false;
                    submitBtnText.style.display = "inline-block"; // Show "Yes" again
                    submitBtnLoader.style.display = "none"; // Hide loader
                }
            });
        }
    }

</script>


<!-- validation  -->

<script>
  // ✅ Initialize Stepper once globally
  let stepper;

  $(document).ready(function () {
      const stepperEl = document.querySelector('.bs-stepper');
      if (stepperEl) {
          stepper = new Stepper(stepperEl);
      }
  });

  function validation_func(stage) {
    let err = false; 
        const nextStep = stepIds[stage]; 
        if (nextStep) {
            attachStepListeners(nextStep);
        }
    // ===== STAGE 1 =====
    if (stage === 1) {
            if (!$('#staff_name').val().trim()) { $('#staff_name_err').text('Staff Name is required.'); err = true; }else{$('#staff_name_err').text('');}
            if (!$('#mobile_no').val().trim()) { $('#mobile_no_err').text('Mobile Number is required.'); err = true; }else{$('#mobile_no_err').text('');}
            if (!$('#staff_dob').val().trim()) { $('#staff_dob_err').text('Date Of Birth is required.'); err = true; }else{$('#staff_dob_err').text('');}
            
          const email = $('#email_id').val().trim();
            const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            if(email == ''){
                $('#email_id_err').text('Email Id is required.'); err = true;
            }else if (email !== '' && !emailPattern.test(email)) {
                $('#email_id_err').text('Enter a valid Email ID.');
                err = true;
            }else{
                $('#email_id_err').text('');
            }
            if (!$('#mother_tongue').val().trim()) { $('#mother_tongue_err').text('Mother Tongue is required.'); err = true; }else{$('#mother_tongue_err').text('');}
            if ($('#Languages').val()=="") { $('#Languages_err').text('Language is required.'); err = true; }else{$('#Languages_err').text('');}

        if (!err) safeNext(stage); // ✅ only go next if no validation errors
    }
    // ===== STAGE 2 =====
    else if(stage === 2) {
        if (!$('#father_name').val().trim()) { $('#father_name_err').text('Father Name is required.'); err = true; }else{$('#father_name_err').text('')}
        if (!$('#father_occup').val().trim()) { $('#father_occup_err').text('Father Occupation is required.'); err = true; }else{$('#father_occup_err').text('')}
        if (!$('#mother_name').val().trim()) { $('#mother_name_err').text('Mother Name is required.'); err = true; }else{$('#mother_name_err').text('')}
        if (!$('#mother_occup').val().trim()) { $('#mother_occup_err').text('Mother Occupation is required.'); err = true; }else{$('#mother_occup_err').text('')}
        if (!$('#marital_status').val().trim()) { $('#marital_status_err').text('Marital Status is required.'); err = true; }else{$('#marital_status_err').text('')}
        var marital_status=$('#marital_status').val().trim();
        
        if(marital_status==2){
            if (!$('#anniversary_date').val().trim()) { $('#anniversary_date_err').text('Anniversary Date is required.'); err = true; }else{$('#anniversary_date_err').text('')}
            if (!$('#spouse_name').val().trim()) { $('#spouse_name_err').text('Spouse Name is required.'); err = true; }else{$('#spouse_name_err').text('')}
            if (!$('#spouse_mobile').val().trim()) { $('#spouse_mobile_err').text('Spouse Mobile No is required.'); err = true; }else{$('#spouse_mobile_err').text('')}
            if (!$('#spouse_dob').val().trim()) { $('#spouse_dob_err').text('Spouse Date Of Birth is required.'); err = true; }else{$('#spouse_dob_err').text('')}
            if($('#workingYes').prop('checked')){
                if (!$('#spouse_designation').val().trim()) { $('#spouse_designation_err').text('Spouse Designation is required.'); err = true; }else{$('#spouse_designation_err').text('')}
                if (!$('#spouse_company_name').val().trim()) { $('#spouse_company_name_err').text('Spouse Company Name is required.'); err = true; }else{$('#spouse_company_name_err').text('')}
                if (!$('#spouse_salary').val().trim()) { $('#spouse_salary_err').text('Spouse Salary is required.'); err = true; }else{$('#spouse_salary_err').text('')}
            }
        }
        
        if ($('#childrenYes').prop('checked')) {
            if (!$('#childrenCount').val().trim()) {
                $('#childrenCount_err').text('Children Count is required.');
                err = true;
            } else {
                $('#childrenCount_err').text('');
            }

            // ✅ Validate each dynamically added child field
            $('#childrenDetails .row').each(function (index) {
                const childIndex = index + 1;

                const childNameField = $(this).find('input[name="child_name[]"]');
                const childDobField = $(this).find('input[name="child_dob[]"]');
                const childStdField = $(this).find('input[name="child_std[]"]');
                const childYearField = $(this).find('input[name="child_year[]"]');

                const childName = childNameField.val().trim();
                const childDob = childDobField.val().trim();
                const childStd = childStdField.val().trim();
                const childYear = childYearField.val().trim();

                // Clear previous error messages
                $(this).find('.error_msg').text('');

                if (!childName) {
                    childNameField.closest('.err-chk').find('.error_msg').text('Please enter the child name.');
                    err = true;
                }

                if (!childDob) {
                    childDobField.closest('.err-chk').find('.error_msg').text('Please select the date of birth.');
                    err = true;
                }

                if (!childStd) {
                    childStdField.closest('.err-chk').find('.error_msg').text('Please enter the standard or degree.');
                    err = true;
                }

                if (!childYear) {
                    childYearField.closest('.err-chk').find('.error_msg').text('Please enter the completion year.');
                    err = true;
                }
            });
        }
        
        if($('#SiblingsYes').prop('checked')){
             if (!$('#siblings_detail').val().trim()) { $('#siblings_detail_err').text('Siblings Detail is required.'); err = true; }else{$('#siblings_detail_err').text('')}
        }
        

        if (!err) safeNext(stage); // ✅ only go next if no validation errors
    }
    // ===== STAGE 3 =====
    else if (stage === 3) {
             if (!$('#permanent_address').val().trim()) { $('#permanent_address_err').text('Permanent Address is required.'); err = true; }else{$('#permanent_address_err').text('')}
               // Validate Contact Person(s)
            $('#altmobile-wrapper .altmobile-row').each(function (index) {
                const nameInput = $(this).find('input[name="contact_person_name[]"]');
                const relationInput = $(this).find('select[name="contact_person_relation[]"]');
                const mobileInput = $(this).find('input[name="contact_person_no[]"]');
                const nameErr = $(this).find('#contact_person_name_err');
                const relationErr = $(this).find('#contact_person_relation_err');
                const mobileErr = $(this).find('#contact_person_no_err');

                let rowErr = false;

                // Name validation
                if (!nameInput.val().trim()) {
                    nameErr.text('Contact person name is required.');
                    rowErr = true;
                } else {
                    nameErr.text('');
                }
                console.log('cname -',nameInput.val())
                console.log('crelation -',relationInput.val())
                if (!relationInput.val()) {

                    relationErr.text('Contact person Relation is required.');
                    rowErr = true;
                } else {
                    relationErr.text('');
                }
                // Mobile validation (required + 10 digits)
                const mobileVal = mobileInput.val().trim();
                if (!mobileVal) {
                    mobileErr.text('Contact person mobile No is required.');
                    rowErr = true;
                } else if (!/^\d{10}$/.test(mobileVal)) {
                    mobileErr.text('Enter a valid 10-digit mobile number.');
                    rowErr = true;
                } else {
                    mobileErr.text('');
                }

                if (rowErr) err = true;
            });
        
        if (!err) safeNext(stage);
    }
    // ===== STAGE 4 =====
    else if (stage === 4) {
        const socialMediaFields = document.querySelectorAll('.toggle-field');
        let err = false; // ensure err variable starts false here if this block runs independently

        socialMediaFields.forEach(checkbox => {
            const socialMediaId = checkbox.getAttribute('id').replace('checkSocialMedia_', '');
            const urlInput = document.querySelector(`#socialMediaField_${socialMediaId} input`);
            const errorElement = document.querySelector(`#checkSocialMedia_${socialMediaId}_err`);

            // Only validate if checkbox is checked
            if (checkbox.checked) {
                const url = urlInput.value.trim();

                if (url === '') {
                    errorElement.textContent = `${checkbox.nextElementSibling.innerText} URL is required.`;
                    err = true;
                } 
                else if (!isValidURL(url)) {
                    errorElement.textContent = `Please enter a valid ${checkbox.nextElementSibling.innerText} URL.`;
                    err = true;
                } 
                else {
                    errorElement.textContent = '';
                }
            } else {
                // Clear error and input if unchecked
                errorElement.textContent = '';
                urlInput.value = '';
            }
        });

        if (!err) safeNext(stage);
    }
    // ===== STAGE 5 =====
    else if (stage === 5) {

         $("#education-wrapper .education-row").each(function (index) {
            const $row = $(this);
            const qualification = $row.find('select[name="qualification_type[]"]');
            const degree = $row.find('input[name="degree[]"]');
            const major = $row.find('input[name="major[]"]');
            const univ = $row.find('input[name="univ_name[]"]');
            const passYear = $row.find('input[name="pass_year[]"]');

            // Find the associated error containers robustly (look inside this row)
            const qualificationErr = $row.find(".error_msg").eq(0); // first error_msg in the row — for select
            const degreeErr = $row.find('input[name="degree[]"]').siblings(".error_msg");
            const majorErr = $row.find('input[name="major[]"]').siblings(".error_msg");
            const univErr = $row.find('input[name="univ_name[]"]').siblings(".error_msg");
            const passYearErr = $row.find('input[name="pass_year[]"]').siblings(".error_msg");

            // Clear previous messages
            qualificationErr.text("");
            degreeErr.text("");
            majorErr.text("");
            univErr.text("");
            passYearErr.text("");

            // --- Qualification check (robust) ---
            const qualVal = qualification.val();
            if (!qualVal || String(qualVal).trim() === "") {
                qualificationErr.text("Qualification Type is required.");
                err = true;
            }

            // Degree
            const degreeVal = degree.val() || "";
            if (!degreeVal.trim()) {
                degreeErr.text("Degree is required.");
                err = true;
            }

            // Major
            const majorVal = major.val() || "";
            if (!majorVal.trim()) {
                majorErr.text("Major is required.");
                err = true;
            }

            // University / Institute
            const univVal = univ.val() || "";
            if (!univVal.trim()) {
                univErr.text("Institute / University Name is required.");
                err = true;
            }

            const passYearVal = passYear.val() || "";
            if (!passYearVal.trim()) {
                passYearErr.text("Qualification Year is required.");
                err = true;
            }
        });

        // === Validate "Any Course Completed?" ===
        const courseTag = $("#course_tag");
        const courseTagErr = courseTag.siblings(".error_msg");
        courseTagErr.text("");

        const selectedCourseOption = $('input[name="is_Course"]:checked').val();

        if (!selectedCourseOption) {
            courseTagErr.text("Please select whether any course is completed.");
            err = true;
        } else if (selectedCourseOption === "Yes") {
            if (!courseTag.val() || !courseTag.val().trim()) {
                courseTagErr.text("Please enter the course name.");
                err = true;
            }
        }
       if (!err) safeNext(stage);
    }
    // ===== STAGE 6 =====
    else if (stage === 6) {
       
        const workType = $("#work_type");
        const workTypeErr = workType.closest(".col-lg-4").find(".error_msg");

        // ✅ Validate Work Type
        if (!workType.val()) {
            workTypeErr.text("Please select Work Type (Fresher or Experience).");
            err = true;
        }

        // ✅ If Experience selected (value = 2)
        if (workType.val() === "2") {
                const companyshift = $("#total_company_shift");
                const companyshiftErr = companyshift.closest(".col-lg-4").find(".error_msg");
                const totalExpr = $("#total_experience");
                const totalExprErr = totalExpr.closest(".col-lg-4").find(".error_msg");

                // ✅ Validate Work Type
                if (!companyshift.val()) {
                    companyshiftErr.text("Company Shift Count is Required");
                    err = true;
                }
                // ✅ Validate Work Type
                if (!totalExpr.val()) {
                    totalExprErr.text("Total Year of Experience Count is Required");
                    err = true;
                }

            // Validate shifted company fields
            $(".shiftedCompanyField").each(function () {
                const input = $(this).find("input");
                const inputErr = $(this).find(".error_msg");

                if (!input.val().trim()) {
                    inputErr.text("This field is required.");
                    err = true;
                } else {
                    inputErr.text("");
                }
            });

            // Validate each Previous Company Detail row
            $("#work-exp-wrapper .work-exp-row").each(function (index) {
                const row = $(this);
                let rowErr = false;

                // Loop through required inputs
                row.find("input, textarea").each(function () {
                    const input = $(this);
                    const inputErr = input.closest(".mb-3").find(".error_msg");

                    if (!input.val().trim()) {
                        inputErr.text("This field is required.");
                        rowErr = true;
                        err = true;
                    } else {
                        inputErr.text("");
                    }
                });

                // ✅ Check start < end date
                const stDate = row.find('input[name="work_st_date[]"]').val().trim();
                const endDate = row.find('input[name="work_end_date[]"]').val().trim();
                const endDateErr = row.find('input[name="work_end_date[]"]').closest(".mb-3").find(".error_msg");

                if (stDate && endDate && new Date(stDate) > new Date(endDate)) {
                    endDateErr.text("End Date must be after Start Date.");
                    rowErr = true;
                    err = true;
                }
            });
        }

        // ✅ Validate Document Attachments
        // $("#document-wrapper .document-row").each(function (index) {
        //     const docType = $(this).find('select[name="doc_type[]"]');
        //     const fileInput = $(this).find('input[type="file"]')[0];
        //     const docTypeErr = docType.closest(".mb-3").find(".error_msg");

        //     if (!docType.val()) {
        //         docTypeErr.text("Please select a Document Type.");
        //         err = true;
        //     } else {
        //         docTypeErr.text("");
        //     }

        //     if (fileInput && fileInput.files.length === 0) {
        //         // Append error message below the dropzone if missing
        //         const fileErrDiv = $(this).find(".dropzone").next(".error_msg");
        //         if (fileErrDiv.length) {
        //             fileErrDiv.text("Please upload a file.");
        //         } else {
        //             $(this).find(".dropzone").after('<div class="text-danger error_msg">Please upload a file.</div>');
        //         }
        //         err = true;
        //     }
        // });


        if (!err){
           var staff_name = $('#staff_name').val().trim();
           var staff_mobile = $('#mobile_no').val().trim();
           var lastFourDigitMobileNo = staff_mobile.slice(-4);
            var name_parts = staff_name.split(' '); // Split the name by spaces
            var randomNumber = Math.floor(1000 + Math.random() * 9000);
           
            // Join all parts except the last part (first name + middle name if present)
            var first_name = name_parts.slice(0, -1).join(''); 
            
            var last_name = name_parts[name_parts.length - 1]; // Last part is the last name
            
            // Construct the username: if the last name is more than one character, just combine the first and last name
            var username = first_name.toLowerCase() + (last_name.length === 1 ? '.' + last_name.toLowerCase() : last_name.toLowerCase());
            // random passs
            // var password = username + '@' + randomNumber;
            // mobile no pass
            var password = username + '@' + lastFourDigitMobileNo;
            // Set the username in the login input field
            $('#loginuser_name').val(username);
            $('#loginpassword').val(password);
            user_name_chk(username)
            safeNext(stage);
        } 
    }
    // ===== STAGE 7 =====
    else if (stage === 7) {
        
        // Get the selected company type (Management or Business)
            const selectedCompanyType = $('input[name="company"]:checked').val();

            
            const management_depart = $("#management_depart");
            const management_user_role = $("#management_user_role");
            const management_division = $("#management_division");
            const management_job_role = $("#management_job_role");
            const staffCompany = $("#staff_company_name");
            const entity_name = $("#entity_name");
            const branch_id = $("#branch_id");
            const business_depart = $("#business_depart");
            const business_user_role = $("#business_user_role");
            const business_division = $("#business_division");
            const business_job_role = $("#business_job_role");
            const loginuser_name = $("#loginuser_name");
            const loginpassword = $("#loginpassword");

            const manageDepartErr = management_depart.closest(".err-chk").find(".error_msg");
            const manageRoleErr = management_user_role.closest(".err-chk").find(".error_msg");
            const managementDivisionErr = management_division.closest(".err-chk").find(".error_msg");
            const managementJobRoleErr = management_job_role.closest(".err-chk").find(".error_msg");
            const staffCompanyErr = staffCompany.closest(".mb-3").find(".error_msg");
            const entityNameErr = entity_name.closest(".mb-3").find(".error_msg");
            const branchIdErr = branch_id.closest(".mb-3").find(".error_msg");
            const businessDepartErr = business_depart.closest(".err-chk").find(".error_msg");
            const businessRoleErr = business_user_role.closest(".err-chk").find(".error_msg");
            const businessDivisionErr = business_division.closest(".err-chk").find(".error_msg");
            const businessJobRoleErr = business_job_role.closest(".err-chk").find(".error_msg");
            const loginUserNameErr = loginuser_name.closest(".err-chk").find(".error_msg");
            const loginPasswordErr = loginpassword.closest(".err-chk").find(".error_msg");

            
            // Clear any previous error messages
            manageDepartErr.text(""); 
            manageRoleErr.text(""); 
            managementDivisionErr.text(""); 
            managementJobRoleErr.text(""); 
            staffCompanyErr.text("");
            entityNameErr.text("");
            branchIdErr.text("");
            businessDepartErr.text(""); 
            businessRoleErr.text(""); 
            businessDivisionErr.text(""); 
            businessJobRoleErr.text(""); 
            loginUserNameErr.text(""); 
            loginPasswordErr.text(""); 


            if (selectedCompanyType == 1) {
                // For Management: Validate the Department field
                if (!management_depart.val() || !management_depart.val().trim()) {
                    manageDepartErr.text("Department is Required.");
                    err = true;  
                } 
                if (!management_division.val() || !management_division.val().trim()) {
                    managementDivisionErr.text("Division is Required.");
                    err = true;  
                } 
                if (!management_job_role.val() || !management_job_role.val().trim()) {
                    managementJobRoleErr.text("Job Role is Required.");
                    err = true; 
                } 

                if (!management_user_role.val() || !management_user_role.val().trim()) {
                    manageRoleErr.text("User Role is Required.");
                    err = true;  
                } 

            } else {
                // For Business: Validate the Company Name field
                if (!staffCompany.val() || staffCompany.val().trim() === '') {
                    staffCompanyErr.text("Company is Required.");
                    err = true;  
                } 
                if (!entity_name.val() || entity_name.val().trim() === '') {
                    entityNameErr.text("Entity is Required.");
                    err = true;  
                } 
                if (!branch_id.val() || branch_id.val().trim() === '') {
                    branchIdErr.text("Branch is Required.");
                    err = true;  
                } 
                if (!business_depart.val() || business_depart.val().trim() === '') {
                    businessDepartErr.text("Department is Required.");
                    err = true;  
                } 
                if (!business_division.val() || business_division.val().trim() === '') {
                    businessDivisionErr.text("Division is Required.");
                    err = true;  
                } 
                if (!business_job_role.val() || business_job_role.val().trim() === '') {
                    businessJobRoleErr.text("Job Role is Required.");
                    err = true;  
                } 
                if (!business_user_role.val() || business_user_role.val().trim() === '') {
                    businessRoleErr.text("User Role is Required.");
                    err = true;  
                } 
            }

            // Check other fields like Pseudo Name, Date of Joining, Basic Salary, Per Hour Cost, etc.
            const pseudo_name = $("#pseudo_name");
            const pseudoNameErr = pseudo_name.closest(".mb-3").find(".error_msg");
            pseudoNameErr.text("");

            if (!pseudo_name.val().trim()) {
                 pseudoNameErr.text('Pseudo Name is required');
                err = true;
            }

            const staff_doj = $("#staff_doj");
            const dojErr = staff_doj.closest(".mb-3").find(".error_msg");
            dojErr.text("");

            if (!staff_doj.val()) {
                dojErr.text("Date of Joining is Required.");
                err = true;
            }

            const basic_salary = $("#basic_salary");
            const basicSalaryErr = basic_salary.siblings(".error_msg");
            basicSalaryErr.text("");

            if (!basic_salary.val().trim()) {
                basicSalaryErr.text("Basic Salary is Required.");
                err = true;
            }

            const per_hr_cost = $("#per_hr_cost");
            const perHrCostErr = per_hr_cost.siblings(".error_msg");
            perHrCostErr.text("");

            if (!per_hr_cost.val().trim()) {
                perHrCostErr.text("Per Hour Cost is Required.");
                err = true;
            }

            const skill_tag = $("#skill_tag");
            const skillTagErr = skill_tag.siblings(".error_msg");
            skillTagErr.text("");

            if (!skill_tag.val().trim()) {
                skillTagErr.text("Skill Tag is Required.");
                err = true;
            }

               if (!loginuser_name.val() || loginuser_name.val().trim() === '') {
                    loginUserNameErr.text("Username is Required.");
                    err = true;  
                } 
                if (!loginpassword.val() || loginpassword.val().trim() === '') {
                    loginPasswordErr.text("Password is Required.");
                    err = true;  
                } 
        if (!err) safeNext(stage);
    }
    // ===== STAGE 8 =====
    else if (stage === 8) {
      
            const applied_position = $("#applied_position");
            const source_id = $("#source_id");
            const interview_company = $("#interview_company");

            const appliedPostionErr = applied_position.closest(".err-chk").find(".error_msg");
            const sourceIdErr = source_id.closest(".err-chk").find(".error_msg");
            const intervCompErr = interview_company.closest(".err-chk").find(".error_msg");

            // 🔹 Clear previous error messages
            $(".error_msg").text("");

            // 🔹 Validate main fields
            if (!applied_position.val() || applied_position.val().length === 0) {
                appliedPostionErr.text("Position is required.");
                err = true;
            }
            if (!source_id.val() || source_id.val().trim() === "") {
                sourceIdErr.text("Source is required.");
                err = true;
            }
            if (!interview_company.val() || interview_company.val().length === 0) {
                intervCompErr.text("Company is required.");
                err = true;
            }

            // 🔹 Validate both dynamic and dependent questions
            $(".dynamic-question, .dependent-question:not(.d-none)").each(function () {
                const label = $(this).find("label").first().text().trim();
                const hasMandatory = $(this).find("span.text-danger").length > 0;
                if (!hasMandatory) return; // skip non-mandatory

                const field = $(this).find(".hrq-field, input, textarea, select").first();
                const fieldType = field.attr("type") || field.prop("tagName").toLowerCase();

                let value = null;
                let isValid = true;

                // --- Text field ---
                if (fieldType === "text") {
                    value = field.val().trim();
                    if (!value) isValid = false;
                }

                // --- Text area ---
                else if (fieldType === "textarea") {
                    value = field.val().trim();
                    if (!value) isValid = false;
                }

                // --- Date field ---
                else if (fieldType === "date") {
                    value = field.val().trim();
                    if (!value) isValid = false;
                }

                // --- Radio buttons ---
                else if (fieldType === "radio") {
                    const name = field.attr("name");
                    if (!$(`input[name='${name}']:checked`).length) isValid = false;
                }

                // --- Checkboxes ---
                else if (fieldType === "checkbox") {
                    const name = field.attr("name");
                    if (!$(`input[name='${name}[]']:checked`).length) isValid = false;
                }

                // --- Select (list_box) ---
                else if (field.prop("tagName").toLowerCase() === "select") {
                    value = field.val();
                    if (!value || value === "") isValid = false;
                }

                // --- File (multiple_images) ---
                else if (fieldType === "file") {
                    const files = field[0].files;
                    if (!files || files.length === 0) isValid = false;
                }

                // --- Show error if invalid ---
                if (!isValid) {
                    err = true;
                    let errorBox = $(this).find(".error_msg");
                    if (errorBox.length === 0) {
                        $(this).append('<div class="text-danger error_msg"></div>');
                        errorBox = $(this).find(".error_msg");
                    }
                    errorBox.text(`${label.replace("*", "").trim()} is required.`);
                } else {
                    $(this).find(".error_msg").text(""); // clear old error
                }
            });



        if (!err) safeNext(stage);
    }
    // ===== STAGE 9 =====
    else if (stage === 9) {
      

        if (!err) safeNext(stage);
    }

    // ===== STAGE 10 =====
    else if (stage === 10) {
        if (!err) {
            var staff_name = $("#staff_name").val().trim();
            $('#create_staff_label').html(staff_name);
            $('#submit_popup').trigger('click');
        } else {
            
        }
    }
  }

function safeNext(stage) {
    // console.log(`== SafeNext(${stage}) ==`);
    // console.log("Before .to():", stepper._currentIndex);

    // 🩹 Force Stepper to truly reset to this stage
    stepper.to(stage);     // ensure we're at the right step
    stepper.to(stage);     // call twice to force internal sync

    // console.log("After double .to():", stepper._currentIndex);

    // Now advance one step
    stepper.next();

    const nextStage = stage + 1;
    const nextStepId = stepIds[nextStage - 1];
    if (nextStepId) {
        console.log(`🎯 Activating next step: ${nextStepId}`);
        updateStepPercentage(nextStepId);
    }

    // console.log("After .next():", stepper._currentIndex);
}
function safePrev(stage) {
    // console.log(`== SafePrev(${stage}) ==`);
    // console.log("Before .to():", stepper._currentIndex);

    // Go back one stage safely
    stepper.to(stage - 1);

    // console.log("After .to():", stepper._currentIndex);
}
</script>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
  
    const faviconFileInput = document.querySelector('.fav_file-in');
    const faviconResetButton = document.querySelector('.fav_file-reset');
  
    // Function to reset favicon image and input
    faviconResetButton.addEventListener('click', function() {
        const faviconImage = document.getElementById('logo_create');
        const resetFaviconImage =
            "{{ asset('assets/egc_images/auth/user_3.png') }}";
        faviconImage.src = resetFaviconImage;
        faviconFileInput.value = null;
    });

    // Function to preview Create image
    faviconFileInput.addEventListener('change', function() {
        const faviconImage = document.getElementById('logo_create');
        if (this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                faviconImage.src = e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
});
</script>
    <script>
        $(document).ready(function() {
            function updateContactLabels() {
                console.log('updateconrt')
                updateStepPercentage(3);
                $("#altmobile-wrapper .altmobile-row").each(function(index) {
                    const personLabel = $(this).find('label[for="contact_person_name"]');
                    const relationLabel = $(this).find('label[for="contact_person_relation"]');
                    const mobileLabel = $(this).find('label[for="contact_person_no"]');
                    if (index === 0) {
                        personLabel.html('Contact Person <span class="text-danger">*</span>');
                        relationLabel.html('Contact Person Relation<span class="text-danger">*</span>');
                        mobileLabel.html('Contact Person Mobile No. <span class="text-danger">*</span>');
                        $(this).find('.altmobile_del').hide(); // hide delete for first row
                    } else {
                        personLabel.html('Contact Person ' + (index + 1) + ' <span class="text-danger">*</span>');
                         relationLabel.html('Contact Person ' + (index + 1) + ' Relation<span class="text-danger">*</span>');
                        mobileLabel.html('Contact Person ' + (index + 1) + ' Mobile No. <span class="text-danger">*</span>');
                        $(this).find('.altmobile_del').show(); // show delete for added rows
                    }
                });
            }

            // Hide all delete buttons first
            $("#altmobile-wrapper .altmobile_del").hide();

            // Initial label setup
            updateContactLabels();

            // Add new contact row
            $("#add-altmobile-btn").click(function() {
                const clone = $(".altmobile-row:first").clone();
                clone.find("input").val(""); // clear input values
                clone.find('.select2-container').remove();
                $("#altmobile-wrapper").append(clone);
                const newSelect = $("#altmobile-wrapper .altmobile-row:last").find('.select3');
                newSelect.select2({
                    dropdownParent: newSelect.closest('.col-lg-4'), // parent column
                    width: '100%'
                });
                
                updateContactLabels();
               
            });

            // Delete a contact row
            $(document).on("click", ".altmobile_del", function() {
                $(this).closest(".altmobile-row").remove();
                updateContactLabels();
               
            });

            // Initialize Select2 for the first dropdown
            $('.select3').select2({
                dropdownParent: $('.select3').closest('.col-lg-4'),
                width: '100%'
            });
            

        });
        
      
        document.addEventListener("DOMContentLoaded", function() {
            const progressBar = document.getElementById('companyProgressBar');
            const container = document.getElementById('companydetails');

            // Track user-modified fields
            const userFilled = new Set();

            // Show Management fields by default
            const managementRadio = document.getElementById('management');
            if (managementRadio.checked) {
                container.querySelectorAll('.management_div').forEach(d => d.classList.remove('d-none'));
                container.querySelectorAll('.business_div').forEach(d => d.classList.add('d-none'));
            }

            // Mark a field as user-filled on interaction
            function markUserFilled(e) {
                userFilled.add(e.target);
            }

            // Attach listeners
            container.querySelectorAll('.required-field').forEach(field => {
                field.addEventListener('input', markUserFilled);
                field.addEventListener('change', markUserFilled);

                // For Select2 or datepickers
                if ($(field).hasClass('select3') || $(field).hasClass('common_datepicker') || $(field)
                    .hasClass('datepicker')) {
                    $(field).on('change', e => markUserFilled({
                        target: field
                    }));
                }
            });

            // Radio show/hide logic
            container.querySelectorAll('input[name="company"]').forEach(radio => {
                radio.addEventListener('change', function() {
                    if (this.id === 'management') {
                        container.querySelectorAll('.management_div').forEach(d => d.classList
                            .remove('d-none'));
                        container.querySelectorAll('.business_div').forEach(d => d.classList.add(
                            'd-none'));
                    } else {
                        container.querySelectorAll('.business_div').forEach(d => d.classList.remove(
                            'd-none'));
                        container.querySelectorAll('.management_div').forEach(d => d.classList.add(
                            'd-none'));
                    }
                    userFilled.add(this);
                });
            });
           
        });
    </script>
    <script>
    $(document).ready(function() {
            // Business dropdown
            $('#staff_company_name').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_name');

                stateDropdown.empty().append('<option value="">Select Entity</option>');

                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('entity_list') }}",
                        type: "GET",
                        data: {
                            company_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .entity_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });
            // depart list
            $('#entity_name').on('change', function() {
                var entity_id = $(this).val();
                var stateDropdown = $('#business_depart');
                var branchDropdown = $('#branch_id');
                var roleDropdown = $('#business_user_role');

                stateDropdown.empty().append('<option value="">Select Department</option>');
                branchDropdown.empty().append('<option value="">Select Branch</option>');
                roleDropdown.empty().append('<option value="">Select User Role</option>');

                if (entity_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('department') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erpdepartmentid', state.erp_department_id)
                                        .text(state.department_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('entity_branch_dropdown_list') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    branchDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erpbranchid', state.erp_branch_id)
                                        .text(state.branch_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Department:', error);
                        }
                    });

                    $.ajax({
                        url: "{{ route('user_role_by_entity') }}",
                        type: "GET",
                        data: {
                            entity_id: entity_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    roleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                        .attr('data-erproleid', state.erp_role_id)
                                        .attr('data-erpunderroleid', state.erp_under_role_id)
                                        .text(state.role_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Role:', error);
                        }
                    });

                }

                
            });
            
            // user Role change
              $('#business_user_role').on('change', function() {
                let erp_role = $(this).find(':selected').data('erproleid');
                let erp_under_role = $(this).find(':selected').data('erpunderroleid');
                    $('#erp_role_id').val(erp_role);
                    $('#erp_under_role_id').val(erp_role);
              });

            //  branch Chnage
              $('#branch_id').on('change', function() {
                let erp_branch = $(this).find(':selected').data('erpbranchid');
                    $('#erp_branch_id').val(erp_branch);
              });

            //  branch Chnage
              $('#business_job_role').on('change', function() {
                let erp_branch = $(this).find(':selected').data('erpjobroleid');
                    $('#erp_job_role_id').val(erp_branch);
              });

            // division dropdown
             $('#business_depart').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#business_division');
                stateDropdown.empty().append('<option value="">Select Division</option>');

                let erp_depert = $(this).find(':selected').data('erpdepartmentid');
                $('#erp_department_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpdivisionid', state.erp_division_id)
                                        .text(state.division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });
                       
                }
             });

              $('#business_division').on('change', function() {
                var department_id = $(this).val();
           
                var jobRoleDropdown = $('#business_job_role');

                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                let erp_depert = $(this).find(':selected').data('erpdivisionid');
                $('#erp_division_id').val(erp_depert);

                if (department_id) {
                    // Fetch and populate states based on selected country
                        // Job role dropdown
                      $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno)
                                         .attr('data-erpjobroleid', state.erp_job_role_id)
                                        .text(state.job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });
                }
             });

           
           

        // management dropdown
            // division dropdown
             $('#management_depart').on('change', function() {
                var department_id = $(this).val();
                var stateDropdown = $('#management_division');
                var jobRoleDropdown = $('#management_job_role');

                stateDropdown.empty().append('<option value="">Select Division</option>');
                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                if (department_id) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('get_division') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .division_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Division:', error);
                        }
                    });

                    // Fetch and populate Job Role
                    $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            department_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });

                }
             });

             $('#management_division').on('change', function() {
                var department_id = $(this).val();
                var jobRoleDropdown = $('#management_job_role');
                jobRoleDropdown.empty().append('<option value="">Select Job Role</option>');

                if (department_id) {

                    // Fetch and populate Job Role
                    $.ajax({
                        url: "{{ route('get_job_role') }}",
                        type: "GET",
                        data: {
                            division_id: department_id
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    jobRoleDropdown.append($('<option></option>').attr(
                                        'value', state.sno).text(state
                                        .job_position_name));
                                });
                                
                            }
                        },
                        error: function(error) {
                            console.error('Error fetching Job Role:', error);
                        }
                    });

                }
             });

            
    });
    </script>

    <script>
        function isValidURL(str) {
            const pattern = /^(https?:\/\/)?([\w-]+\.)+[\w-]{2,}(\/[\w- ./?%&=]*)?$/i;
            return pattern.test(str);
        }
    </script>
     <script>
      document.addEventListener("DOMContentLoaded", function () {
        const tagInputs = document.querySelectorAll(".course_tag");

        const whitelist = [
            "Development", "Managing"
        ];

        tagInputs.forEach((input) => {
            new Tagify(input, {
                whitelist: whitelist,
                maxTags: 10,
                dropdown: {
                    maxItems: 20,
                    classname: "tags-inline",
                    enabled: 0,
                    closeOnSelect: false
                }
            });
        });
      });
    </script>

    <script>
        function mobile_chk(val) {
            if (val != "") {
                $.ajaxSetup({
                    headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' }
                });

                $.ajax({
                    url: "{{ route('checkStaffMobileExists') }}",
                    type: 'POST',
                    data: { mobile: val },
                    dataType: 'json',
                    success: function(response) {
                        console.log(response);
                        if (response.data !== 0) {
                            $('#mobile_no_err').text('Mobile Number is already assigned!');
                            $('#mobile_no').addClass('err_border');
                            $('#stage1').prop('disabled', true);
                        } else {
                            $('#mobile_no_err').text('');
                            $('#mobile_no').removeClass('err_border');
                            $('#stage1').prop('disabled', false);
                        }
                    },
                    error: function() {
                        $('#stage1').prop('disabled', true);
                        
                    }
                });
            }
        }
    </script>


    <script>
        // Enable drag-to-scroll for all .file-previews containers
        $(document).on('mousedown', '.file-previews', function(e) {
            const el = this;
            let startX = e.pageX - el.offsetLeft;
            let scrollLeft = el.scrollLeft;

            let isDown = true;
            $(el).addClass('active');
            $(document).on('mouseup.dragscroll', function() {
                isDown = false;
                $(document).off('.dragscroll');
                $(el).removeClass('active');
            });
        });
    </script>

  <script>
$(document).ready(function () {

    // ✅ Initialize Select2 / Select3 first
    // ✅ Handle radio or select change dynamically
    $(document).on('change', '.hrq-field', function () {
        const qid = $(this).data('question');
        const val = $(this).val();

        // Loop through all dependents linked to this parent question
        $(`.dependent-question[data-parent='${qid}']`).each(function () {
            const triggers = JSON.parse($(this).attr('data-trigger'));
            const match = triggers.some(t => 
                t.label.trim().toLowerCase() === val.trim().toLowerCase()
            );

            // Toggle visibility
            $(this).toggleClass('d-none', !match);
        });
    });

    // ✅ Wait for all dynamic DOM elements to render
    setTimeout(() => {
        // Trigger change manually for all default checked radios
        $('.hrq-field[type="radio"]:checked').each(function () {
            $(this).trigger('change');
             
        });
    }, 100); // small delay ensures dependents exist

});

document.addEventListener("DOMContentLoaded", () => {
    attachStepListeners("staff_add");
  });
</script>
 {{-- username unique check --}}
    <script>
        function user_name_chk(val) {
            if (val != "") {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                });
                $.ajax({
                    url: "{{ route('checkunique_user_name') }}",
                    type: 'POST',
                    data: {
                        value: val
                    },
                    dataType: 'json', // Expect JSON response from server
                    success: function(response) {
                        if (response.data !== 0) {
                            $('#loginuser_name_err').text('Staff username already assigned!.');
                             $('#loginuser_name').addClass('err_border');
                            $('#stage7').prop('disabled', true); // Disable submit button
                        } else {
                            $('#loginuser_name_err').text('');
                             $('#loginuser_name').removeClass('err_border');
                            $('#stage7').prop('disabled', false); // Enable submit button
                        }
                    },
                    error: function(xhr, status, error) {
                        // alert("Error: " + error); // Display error message
                    }
                });
            }

        }
    </script>
    
@endsection
