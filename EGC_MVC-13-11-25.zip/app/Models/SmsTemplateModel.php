<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SmsTemplateModel extends Model
{
  use HasFactory;
  public $table      = 'egc_sms_template';
  public $primaryKey = 'sno';

  protected $fillable = [
    'sms_template_id',
    'branch_id',
    'authkey',
    'sender_id',
    'template_id',
    'country_code',
    'template_name',
    'sms_template_messagecontent',
    'created_at',
    'created_by',
    'updated_at',
    'updated_by',
    'status',
  ];
}
