<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SourceModel extends Model {
    use HasFactory;
    public $table      = 'egc_source';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'source_name',
        'source_desc',
        'detail_check',
        'hook_connect',
        'created_by',
        'created_at',
        'status',
    ];
}