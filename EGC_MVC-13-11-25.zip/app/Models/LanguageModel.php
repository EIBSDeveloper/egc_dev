<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LanguageModel extends Model {
    use HasFactory;
    public $table      = 'egc_languages';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'iso_639_1',
        'name',
        'native_name',
        'script',
        'is_rtl',
        'created_by',
        'created_at',
        'status',
    ];
}