<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class WebhookDispatchAttemptModel extends Model {
    protected $table = 'egc_webhook_dispatch_attempts';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true;

    protected $fillable = [
        'webhook_dispatch_sno','attempted_at','http_status',
        'request_headers','request_body','response_body','error','created_by','updated_by'
    ];
}
