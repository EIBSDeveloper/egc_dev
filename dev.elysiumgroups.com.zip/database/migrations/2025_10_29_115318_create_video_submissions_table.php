<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('video_submissions', function (Blueprint $table) {
            $table->id();
            $table->string('token')->unique(); // unique link token
            $table->unsignedBigInteger('user_id')->nullable(); // optional
            $table->string('video_path')->nullable(); // path to uploaded video
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('video_submissions');
    }
};
