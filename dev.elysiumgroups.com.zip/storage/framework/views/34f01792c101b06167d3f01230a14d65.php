<?php $__env->startSection('title', 'Manage Users'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Users</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/dashboard')); ?>">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                User Management
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-100px">User</th>
                                <th class="min-w-100px">Company / Entity</th>
                                <th class="min-w-100px">Role /Dept</th>
                                <th class="min-w-100px">Log In / Out</th>
                                <th class="min-w-100px">Created By /Date</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-50px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            <tr style="border-left: 5px solid #099DDA;">
                                <td>
                                    <div class="d-flex">      
                                        <span class="floating-badge">
                                            <i class="mdi mdi-badge-account fs-1" style="color: #099DDA;"></i>
                                        </span>                                         
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                <img src="<?php echo e(asset('assets/egc_images/auth/user_2.png')); ?>"
                                                    alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <label>
                                                <span class="fs-7 me-1">Mahesh Kumar</span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                        class="mdi mdi-face-man text-info"></i></span>                                                       
                                            </label>
                                            <div class="d-flex text-primary fs-8">
                                                <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff Nick Name">
                                                    Karthik
                                                </a>
                                                <div class="">
                                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                        data-bs-toggle="dropdown" data-trigger="hover">
                                                        <i class="ms-1 mdi mdi-information fs-9"></i>
                                                    </a>
                                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Mob No</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">9874587450</div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Email ID</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">mahesh1602@gmail.com</div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">DOJ</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                                12-Sep-2024
                                                                <span class="badge fs-8 bg-info">1 yr 10 days</span>
                                                            </div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Educational</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">BBA</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Elysium Techonologies Pvt Ltd">
                                            Elysium Techonologies Pvt Ltd
                                        </label>

                                        <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Click My Project">
                                            Click My Project
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Business Head">
                                            Business Head
                                        </label>
                                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Management">
                                            Management
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #057791ff !important">
                                        <span class="fs-7">25-Sep-2025 11:59 AM</span>
                                    </label>
                                    <label class="d-block">
                                        <span class="fs-7 badge bg-label-youtube fs-7 fw-bold mb-2"  style="color: #dd0558ff !important">25-Sep-2025 07:05 PM</span>
                                    </label>
                                </td>
                                <td>
                                    <div class="d-flex">                                   
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                <img src="<?php echo e(asset('assets/egc_images/auth/user_3.png')); ?>"
                                                    alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <label>
                                                <span class="fs-7 me-1">Ganeshan</span>                                                     
                                            </label>
                                            <div class="d-flex text-primary fs-8">
                                                <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff Nick Name">
                                                    Prem    
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <label class="d-block mt-1">
                                        <span class="bg-secondary py-1 px-2 rounded text-black fs-8 fw-semibold">20-Aug-2023</span>
                                    </label>
                                </td>
                                <td>
                                    <span class="badge bg-info fw-semibold text-black fs-7">Active</span>
                                </td>
                                <td class="text-end">
                                    <span class="text-end">
                                        <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_view_user">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                        </a> 
                                    </span>
                                </td>
                            </tr>
                            <tr style="border-left: 5px solid #2B1A66;">
                                <td>
                                    <div class="d-flex">      
                                        <span class="floating-badge">
                                            <i class="mdi mdi-badge-account fs-1" style="color: #2B1A66;"></i>
                                        </span>                                         
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                            <!-- style="border: 3px solid #2B1A66;border-radius: 50%;" data-kt-image-input="true"> -->
                                                <img src="<?php echo e(asset('assets/egc_images/auth/user_2.png')); ?>"
                                                    alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <label>
                                                <span class="fs-7 me-1">Ram Prasad</span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                        class="mdi mdi-face-man text-info"></i></span>                                                       
                                            </label>
                                            <div class="d-flex text-primary fs-8">
                                                <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff Nick Name">
                                                    Ram
                                                </a>
                                                <div class="">
                                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                        data-bs-toggle="dropdown" data-trigger="hover">
                                                        <i class="ms-1 mdi mdi-information fs-9"></i>
                                                    </a>
                                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Mob No</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">8874512036</div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Email ID</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">ram.p@gmail.com</div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">DOJ</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                                25-Mar-2025
                                                                <span class="badge fs-8 bg-info">6 Months 01 day</span>
                                                            </div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Educational</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">MCA</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Elysian Intelligence Business Solution">
                                            Elysian Intelligence Business Solution
                                        </label>

                                        <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="EiBS">
                                            EiBS
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Business Head">
                                            Business Head
                                        </label>
                                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Management">
                                            Management
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #057791ff !important">
                                        <span class="fs-7">25-Sep-2025 11:59 AM</span>
                                    </label>
                                    <label class="d-block">
                                        <span class="fs-7 badge bg-label-youtube fs-7 fw-bold mb-2"  style="color: #dd0558ff !important">25-Sep-2025 07:05 PM</span>
                                    </label>
                                </td>
                                <td>
                                    <div class="d-flex">                                   
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                <img src="<?php echo e(asset('assets/egc_images/auth/user_1.png')); ?>"
                                                    alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <label>
                                                <span class="fs-7 me-1">James</span>                                                     
                                            </label>
                                            <div class="d-flex text-primary fs-8">
                                                <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff Nick Name">
                                                    Kani    
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <label class="d-block mt-1">
                                        <span class="bg-secondary py-1 px-2 rounded text-black fs-8 fw-semibold">07-Jan-2025</span>
                                    </label>
                                </td>
                                <td>
                                    <span class="badge bg-info fw-semibold text-black fs-7">Active</span>
                                </td>
                                <td class="text-end">
                                    <span class="text-end">
                                        <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_view_user">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                        </a> 
                                    </span>
                                </td>
                            </tr>
                            <tr style="border-left: 5px solid #39484F;">
                                <td>
                                    <div class="d-flex">      
                                        <span class="floating-badge">
                                            <i class="mdi mdi-badge-account fs-1" style="color: #39484F;"></i>
                                        </span>                                         
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                            <!-- style="border: 3px solid #39484F;border-radius: 50%;" data-kt-image-input="true"> -->
                                                <img src="<?php echo e(asset('assets/egc_images/auth/user_5.png')); ?>"
                                                    alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <label>
                                                <span class="fs-7 me-1">Kanimozhi S</span>
                                                <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Male"><i
                                                        class="mdi mdi-face-woman text-danger"></i></span>                                                       
                                            </label>
                                            <div class="d-flex text-primary fs-8">
                                                <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff Nick Name">
                                                    Preethi
                                                </a>
                                                <div class="">
                                                    <a href="javascript:;" class="dropdown-toggle hide-arrow "
                                                        data-bs-toggle="dropdown" data-trigger="hover">
                                                        <i class="ms-1 mdi mdi-information fs-9"></i>
                                                    </a>
                                                    <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Mob No</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">9696320125</div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Email ID</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">preethiKani@gmail.com</div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">DOJ</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold d-flex align-items-center gap-1">
                                                                19-Jan-2023
                                                                <span class="badge fs-8 bg-info">2 Years 8 Months 04 days</span>
                                                            </div>
                                                        </div>
                                                        <div class="mb-2 d-flex">
                                                            <div class="fw-semibold w-30">Educational</div>
                                                            <div class="mx-1">:</div>
                                                            <div class="fw-bold">M.Com</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Elysium Academy">
                                            Elysium Academy
                                        </label>

                                        <label class="fw-semibold fs-7 text-truncate badge bg-label-slack d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="EAPL">
                                            EAPL
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-start justify-content-center flex-column">
                                        <label class="fw-semibold text-black fs-7 text-truncate d-block" 
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Accounts Manager">
                                            Accounts Manager
                                        </label>
                                        <label class="fw-semibold fs-8 text-truncate text-dark d-block"
                                            style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 150px;"
                                            data-bs-toggle="tooltip" data-bs-placement="bottom" 
                                            title="Accounts & Finance">
                                            Accounts & Finance
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label class="badge bg-label-info fs-7 fw-bold mb-2" style="color: #057791ff !important">
                                        <span class="fs-7">24-Sep-2025 05:18 PM</span>
                                    </label>
                                    <label class="d-block">
                                        <span class="fs-7 badge bg-label-youtube fs-7 fw-bold mb-2"  style="color: #dd0558ff !important">24-Sep-2025 07:05 PM</span>
                                    </label>
                                </td>
                                <td>
                                    <div class="d-flex">                                   
                                        <div class="symbol symbol-35px me-2">
                                            <div class="image-input image-input-circle">
                                                <img src="<?php echo e(asset('assets/egc_images/auth/user_5.png')); ?>"
                                                    alt="user-avatar"  class="w-px-40 h-auto rounded-circle"
                                                    id="uploadedlogo" />
                                            </div>
                                        </div>
                                        <div class="mb-0">
                                            <label>
                                                <span class="fs-7 me-1">Pooja</span>                                                     
                                            </label>
                                            <div class="d-flex text-primary fs-8">
                                                <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Staff Nick Name">
                                                    Swetha    
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <label class="d-block mt-1">
                                        <span class="bg-secondary py-1 px-2 rounded text-black fs-8 fw-semibold">08-Feb-2025</span>
                                    </label>
                                </td>
                                <td>
                                    <span class="badge bg-info fw-semibold text-black fs-7">Active</span>
                                </td>
                                <td class="text-end">
                                    <span class="text-end">
                                        <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_view_user">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i></span>
                                        </a> 
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


<!--begin::Modal view staff--->
<div class="modal fade" id="kt_modal_view_user" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-lg">
      <!--begin::Modal content-->
      <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
            <!--begin::Close-->
            <div class="d-flex justify-content-end px-2 py-2">
                <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
            </div>
            <!--end::Close-->
            <!--begin::Modal header-->
            <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                <div class="d-flex flex-column">
                    <div class="row mb-2">
                        <div class="d-flex align-items-center mb-1">
                            <div class="avatar-stack">
                                <img src="<?php echo e(asset('assets/egc_images/auth/user_1.png')); ?>" alt="user-avatar" class="avatar-img" />
                                <img src="<?php echo e(asset('assets/egc_images/auth/user_2.png')); ?>" alt="user-avatar" class="avatar-img" />
                                <img src="<?php echo e(asset('assets/egc_images/auth/user_3.png')); ?>" alt="user-avatar" class="avatar-img" />
                            </div>
                        </div>
                        <h3 class="text-black">View User</h3>
                    </div>
                </div>
                <div class="d-flex flex-column">
                    <label class="fs-5 fw-semibold text-primary">Mahesh Kumar</label>
                    <label class="fs-6 fw-semibold text-black">9874587450</label>
                </div>
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                <div class="row mb-2">
                    <div class="col-lg-8">
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Staff Name</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">Mahesh Kumar</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Nick Name</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">Karthik</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Mobile No</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">9874587450</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Alternate Mobile No</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">9898745120</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Email Id</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">mahesh1602@gmail.com</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Name</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">Dhana Balan P</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Contact Person Mobile</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">9685859641</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Marital Status</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">Married</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Address</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">12/A, First Floor,block C, Park Avenue, Cross Street, Vanathi Street, Narayanapuram, Madurai - 625014</label>
                        </div>
                        <div class="row mb-2">
                            <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                            <label class="col-1 fw-semibold fs-7">:</label>
                            <label class="col-6 fw-semibold fs-6 text-black">-</label>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="symbol symbol-35px me-2">
                            <div class="image-input image-input-circle" data-kt-image-input="true" >
                                <img src="<?php echo e(asset('assets/egc_images/auth/user_2.png')); ?>"
                                    alt="user-avatar"  class="w-px-150 h-auto rounded-circle"
                                    id="uploadedlogo" style="border: 2px solid #ab2b22;"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - view users-->


    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "pageLength": 25,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                 //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Elyisa-Jeya Rosini H\Inhouse\EGC\UI\egc_original\resources\views/content/control_panel/user_management/manage_users/manage_users_list.blade.php ENDPATH**/ ?>