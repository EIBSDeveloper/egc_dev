<?php $__env->startSection('style'); ?>
<?php $__env->startSection('title', 'Document'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-body px-1 py-1">
            <div class="nav-align-right nav-tabs-shadow">

                <div class="tab-content">
                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Questionnaire</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo e(url('/dashboard')); ?>">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">HRM</a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Questionnaire
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                    <form id="add_customer_type_option_form" action="<?php echo e(route('add_hr_question')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <div id="questions_container">

                

                        </div>

                        <div class="mb-1 mt-1">
                            <button type="button" class="btn btn-primary" id="add_Question">
                                <i class="mdi mdi-plus me-1"></i>
                            </button>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <a href="<?php echo e(url('/settings/questionnaire')); ?>" class="btn btn-outline-danger text-primary fw-bold waves-effect">Cancel</a>
                            <button type="button" class="btn btn-primary" id="saveQuestions" onclick="AddvalidateForm()">Create Question</button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>




    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>



<!-- Label Value Function Start -->
<script>
    function payment_mode_option_label_func() {
        var payment_mode_option_label_value = document.getElementById("payment_mode_option_label_value").value;
        var payment_mode_option_check_box = document.getElementById("payment_mode_option_check_box");
        var payment_mode_option_radio_button = document.getElementById("payment_mode_option_radio_button");
        var payment_mode_option_list_box = document.getElementById("payment_mode_option_list_box");

        if (payment_mode_option_label_value == "check_box") {
            payment_mode_option_check_box.style.display = "block";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "none";
        } else if (payment_mode_option_label_value == "radio_button") {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "block";
            payment_mode_option_list_box.style.display = "none";
        } else if (payment_mode_option_label_value == "list_box") {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "block";
        } else {
            payment_mode_option_check_box.style.display = "none";
            payment_mode_option_radio_button.style.display = "none";
            payment_mode_option_list_box.style.display = "none";
        }
    }
</script>


<script>
function createQuestionBlock(isDefault = false) {
    // Delete button only for non-default blocks
    var deleteButtonHTML = isDefault ? '' : `
        <div class="col-lg-1">
            <a href="javascript:;" class="btn btn-outline-danger mt-4 px-1 py-2 del-question">
                <i class="mdi mdi-delete fs-4"></i>
            </a>
        </div>
    `;

    var block = `
    <div class="altmobile-row rounded mb-3">
       <div class="payment_mode_question_block px-2 py-2">
            <div class="row my-2">
              <div class="col-lg-11">
                  <div class="row">
                      <div class="col-lg-4 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Question Name<span class="text-danger">*</span></label>
                          <input type="text" class="form-control label-name" name="label_names[]" placeholder="Enter Question Name" />
                         
                      </div>
                      <div class="col-lg-4 mb-3">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Input Value<span class="text-danger">*</span></label>
                          <select class="select3 form-select input-value-select" name="label_values[]">
                              <option>Select Input Value</option>
                              <option value="text_field">Text Field</option>
                              <option value="text_area">Text Area</option>
                              <option value="multiple_images">Multiple Images</option>
                              <option value="date_field">Date Field</option>
                              <option value="check_box">Check Box</option>
                              <option value="radio_button">Radio Button</option>
                              <option value="list_box">List Box</option>
                          </select>
                         
                      </div>

                      <div class="col-lg-4 mb-3 mt-3 option-blocks"></div>

                      <div class="col-lg-2 mb-3  d-flex align-items-center">
                          <div class="form-check form-check-inline mt-4">
                              <input class="form-check-input cred_check" type="checkbox" />
                              <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                          </div>
                      </div>


                  </div>
              </div>
              ${deleteButtonHTML}
          </div>
          <hr class="bg-light m-1">
          <div class="row my-2">
              <div class="col-lg-11">
                  <div class="row">
                    <div class="col-lg-4 mb-3 mt-3">
                        <div class="form-check form-check-inline mb-1">
                            <input class="form-check-input depends-checkbox" type="checkbox" />
                            <label class="text-dark fs-6 fw-semibold">Depends
                                <span class="text-danger" style="display: none;">*</span>
                            </label>
                        </div>
                        <div class="depends-tbox " style="display: none;">
                            <select class="select3 form-select depends-select">
                                <option value="">Select Label</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3 mt-3 depends-tbox" style="display: none;">
                        <label class="text-dark mb-2 fs-6 fw-semibold">Label Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Label Name" />
                    </div>
                    <div class="col-lg-4 mb-3 mt-3 depends-tbox" style="display: none;">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Input Value<span class="text-danger">*</span></label>
                        <select class="select3 form-select depends-input-value">
                            <option>Select Input Value</option>
                            <option value="text_field">Text Field</option>
                            <option value="text_area">Text Area</option>
                            <option value="multiple_images">Multiple Images</option>
                            <option value="date_field">Date Field</option>
                            <option value="check_box">Check Box</option>
                            <option value="radio_button">Radio Button</option>
                            <option value="list_box">List Box</option>
                        </select>
                    </div>
                    <div class="col-lg-2 mb-3 mt-3 d-flex align-items-center depends-tbox" style="display: none;">
                        <div class="form-check form-check-inline depends-tbox">
                            <input class="form-check-input depend_check" type="checkbox" />
                            <label class="text-dark mb-1 fs-6 fw-semibold">Mandatory</label>
                        </div>
                    </div>
                </div>
              </div>
          </div>
          <hr class="bg-light m-1">
        </div>
    </div>
    `;
    return block;
}

// Add default block on page load
$(document).ready(function(){
    var $firstBlock = $(createQuestionBlock(true));
    $('#questions_container').append($firstBlock);
    initializeBlock($firstBlock);
});

// Add new question block
$('#add_Question').on('click', function() {
    var $block = $(createQuestionBlock(false));
    $('#questions_container').append($block);
    initializeBlock($block);
});

// Initialize block behavior
function initializeBlock($block){
    $block.find('.select3').select2({width: '100%'});
    handleInputValueChange($block);

    // Depends checkbox toggle visibility
    $block.find('.depends-checkbox').on('change', function() {
        var checked = $(this).is(':checked');
        $(this).closest('.row').find('.depends-tbox').toggle(checked);
    });

    // Delete question block
    $block.find('.del-question').on('click', function() {
        $block.remove();
    });

    // Handle depends input value logic
    $block.find('.depends-input-value').on('change', function() {
        var value = $(this).val();
        var $container = $(this).closest('.row').find('.depends-option-blocks');
        $container.remove(); // clear existing depends options

        if(value === 'check_box' || value === 'radio_button' || value === 'list_box') {
            var type = value;
            var uniqueId = 'depends-' + type + '-' + new Date().getTime();
            var typeText = type.replace('_',' ');
            typeText = typeText.charAt(0).toUpperCase() + typeText.slice(1);

            var html = `
              <div class="col-lg-4 mb-3 depends-option-blocks depends-tbox">
                <div class="accordion">
                  <div class="accordion-item mb-2">
                    <h2 class="accordion-header">
                      <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#${uniqueId}">
                        ${typeText} Options
                      </button>
                    </h2>
                    <div id="${uniqueId}" class="accordion-collapse collapse">
                      <div class="accordion-body px-2">
                        <div class="scroll-y max-h-200px ${type}-dep-container p-3" style="overflow-x: hidden;">
                          <div class="option-item row mb-2">
                            <div class="col-lg-10">
                              <label class="text-dark mb-1 fs-6 fw-semibold">Option 1 <span class="text-danger">*</span></label>
                              <textarea class="form-control" rows="1" placeholder="Enter Option 1"></textarea>
                            </div>
                            <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1">
                              <!-- no delete for first -->
                            </div>
                          </div>
                        </div>
                        <div class="mb-1 mt-1">
                          <button type="button" class="btn btn-primary mt-2 add-dep-option-btn">Add Option</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>`;
            $(this).closest('.row').append(html);

            var $optionsContainer = $(this).closest('.row').find(`.${type}-dep-container`);
            $(this).closest('.row').find('.add-dep-option-btn').on('click', function(e){
                e.preventDefault();
                var nextNum = $optionsContainer.find('.option-item').length + 1;
                var $newRow = $(`
                    <div class="option-item row mb-2">
                      <div class="col-lg-10">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Option ${nextNum} <span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" placeholder="Enter Option ${nextNum}"></textarea>
                      </div>
                      <div class="col-lg-2 d-flex justify-content-start align-items-end mb-1">
                        <div>
                          <a href="javascript:;" class="btn btn-outline-danger delete-dep-option w-100 h-100 d-flex justify-content-center align-items-center p-1">
                          <i class="mdi mdi-delete fs-4"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                `);
                $optionsContainer.append($newRow);

                // delete handler
                $newRow.find('.delete-dep-option').on('click', function(){
                    $newRow.remove();
                    updateDepOptionNumbers($optionsContainer);
                });
            });
        }
    });
}

// Handle Input Value (Main Section)
function handleInputValueChange($block) {
    $block.find('.input-value-select').on('change', function() {
        var value = $(this).val();
        var $container = $block.find('.option-blocks');
        $container.empty();

        if(value === 'check_box' || value === 'radio_button' || value === 'list_box') {
            var type = value;
            var uniqueId = 'accordion-' + type + '-' + new Date().getTime();
            var typeText = type.replace('_',' ');
            typeText = typeText.charAt(0).toUpperCase() + typeText.slice(1);

            var html = `
            <div class="accordion">
              <div class="accordion-item mb-2">
                <h2 class="accordion-header">
                  <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#${uniqueId}"> ${typeText} </button>
                </h2>
                <div id="${uniqueId}" class="accordion-collapse collapse">
                  <div class="accordion-body px-2">
                    <div class="scroll-y max-h-200px ${type}-container p-3" style="overflow-x: hidden;">
                      <div class="option-item row mb-2">
                        <div class="col-lg-10">
                          <label class="text-dark mb-1 fs-6 fw-semibold">Option 1 <span class="text-danger">*</span></label>
                          <textarea class="form-control" rows="1" placeholder="Enter Option 1"></textarea>
                        </div>
                        <div class="col-lg-2 d-flex justify-content-center align-items-center mb-1"></div>
                      </div>
                    </div>
                    <div class="mb-1 mt-1">
                      <button type="button" class="btn btn-primary mt-2 add-option-btn">Add Option</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>`;
            $container.append(html);

            $container.find('.add-option-btn').on('click', function(e){
                e.preventDefault();
                var $optionsContainer = $container.find(`.${type}-container`);
                var nextNum = $optionsContainer.find('.option-item').length + 1;
                var $newRow = $(`
                    <div class="option-item row mb-2">
                      <div class="col-lg-10">
                        <label class="text-dark mb-1 fs-6 fw-semibold">Option ${nextNum} <span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" placeholder="Enter Option ${nextNum}"></textarea>
                      </div>
                      <div class="col-lg-2 d-flex justify-content-start align-items-end mb-1">
                        <div>
                          <a href="javascript:;" class="btn btn-outline-danger delete-option w-100 h-100 d-flex justify-content-center align-items-center p-1">
                            <i class="mdi mdi-delete fs-4"></i>
                          </a>
                        </div>
                      </div>
                    </div>
                `);
                $optionsContainer.append($newRow);

                $newRow.find('.delete-option').on('click', function() {
                    $newRow.remove();
                    updateOptionNumbers($optionsContainer);
                    updateDependsSelect($block);
                });

                $newRow.find('textarea').on('input', function() {
                    updateDependsSelect($block);
                });

                updateDependsSelect($block);
            });

            $container.find('textarea').on('input', function() {
                updateDependsSelect($block);
            });
            updateDependsSelect($block);
        }
    });
}

// Update depends select based on main options only
function updateDependsSelect($block) {
    var $dependsSelect = $block.find('.depends-select');
    $dependsSelect.empty().append('<option value="">Select Label</option>');
    $block.find('.option-blocks textarea').each(function(){
        var val = $(this).val().trim();
        if(val) $dependsSelect.append(`<option value="${val}">${val}</option>`);
    });
}

// Update numbering for main options
function updateOptionNumbers($optionsContainer){
    $optionsContainer.find('.option-item').each(function(index){
        $(this).find('label').html(`Option ${index+1} <span class="text-danger">*</span>`);
        $(this).find('textarea').attr('placeholder', `Enter Option ${index+1}`);
    });
}

// Update numbering for depends local options
function updateDepOptionNumbers($container){
    $container.find('.option-item').each(function(index){
        $(this).find('label').html(`Option ${index+1} <span class="text-danger">*</span>`);
        $(this).find('textarea').attr('placeholder', `Enter Option ${index+1}`);
    });
}
</script>
<script>
function AddvalidateForm() {
    const $form = $('#add_customer_type_option_form');
    const $blocks = $('#questions_container .payment_mode_question_block');
    let isValid = true;

    // Reset old validation
    $form.find('.is-invalid').removeClass('is-invalid');
    $form.find('.invalid-feedback-dynamic').remove();

    // Validate each question block
    $blocks.each(function(index) {
        const $block = $(this);
        const $labelName = $block.find('.label-name');
        const $inputValue = $block.find('.input-value-select');
        const labelName = $labelName.val()?.trim();
        const inputValue = $inputValue.val();

        // ---- Question Name ----
        if (!labelName) {
            showError($labelName, "Question Name is required.");
            isValid = false;
        }

        // ---- Input Value ----
        if (!inputValue || inputValue === "Select Input Value") {
            showError($inputValue.next('.select2'), "Please select an Input Value.");
            isValid = false;
        }

        // ---- Option Validation ----
        if (['check_box', 'radio_button', 'list_box'].includes(inputValue)) {
            const $options = $block.find('.option-blocks textarea');
            if ($options.length === 0) {
                showError($block.find('.option-blocks'), "Option is required.");
                isValid = false;
            } else {
                $options.each(function() {
                    if (!$(this).val().trim()) {
                        showError($(this), "Option is required.");
                        isValid = false;
                    }
                });
            }
        }

        // ---- Depends Validation ----
        const $dependsCheckbox = $block.find('.depends-checkbox');
        if ($dependsCheckbox.is(':checked')) {
            const $dependsSelect = $block.find('.depends-select');
            const $dependsLabelName = $block.find('.depends-tbox input[type="text"]');
            const $dependsInputValue = $block.find('.depends-input-value');
            const dependsValue = $dependsInputValue.val();

            // Depends Select
            if (!$dependsSelect.val()) {
                showError($dependsSelect.next('.select2'), "Please select a dependent label.");
                isValid = false;
            }

            // Label Name
            if (!$dependsLabelName.val()?.trim()) {
                showError($dependsLabelName, "Dependent label name is required.");
                isValid = false;
            }

            // Input Value
            if (!dependsValue || dependsValue === "Select Input Value") {
                showError($dependsInputValue.next('.select2'), "Please select a dependent input value.");
                isValid = false;
            }

            // Dependent Options
            if (['check_box', 'radio_button', 'list_box'].includes(dependsValue)) {
                const $depOptions = $block.find('.depends-option-blocks textarea');
                if ($depOptions.length === 0) {
                    showError($block.find('.depends-option-blocks'), "Dependent option is required.");
                    isValid = false;
                } else {
                    $depOptions.each(function() {
                        if (!$(this).val().trim()) {
                            showError($(this), "Dependent option is required.");
                            isValid = false;
                        }
                    });
                }
            }
        }
    });

    // Scroll to first invalid field
    if (!isValid) {
        $('html, body').animate({
            scrollTop: $('.is-invalid').first().offset().top - 120
        }, 400);
        return false;
    }

    serializeQuestions($form);
}

// Helper: Show inline validation message
function showError($el, message) {
    $el.addClass('is-invalid');
    if ($el.next('.invalid-feedback-dynamic').length === 0) {
        $(`<div class="invalid-feedback invalid-feedback-dynamic">${message}</div>`).insertAfter($el);
    }

    // Remove error dynamically when corrected
    $el.on('input change', function() {
        if ($(this).val()?.trim()) {
            $(this).removeClass('is-invalid');
            $(this).next('.invalid-feedback-dynamic').remove();
        }
    });
}

// Serialize questions into hidden inputs
function serializeQuestions($form) {

    $form.find('input[type="hidden"]').not('[name="_token"]').remove();

    // Ensure CSRF token exists
    if ($form.find('input[name="_token"]').length === 0) {
        $('<input>', {
            type: 'hidden',
            name: '_token',
            value: '<?php echo e(csrf_token()); ?>'
        }).appendTo($form);
    }

    const questionsData = [];
    $('#questions_container .payment_mode_question_block').each(function() {
        const $block = $(this);
        const q = {
            label_name: $block.find('.label-name').val()?.trim() || '',
            label_value: $block.find('.input-value-select').val() || '',
            is_mandatory: $block.find('.cred_check').is(':checked') ? 1 : 0,
            is_depend_mandatory: $block.find('.depend_check').is(':checked') ? 1 : 0,
            is_depends: $block.find('.depends-checkbox').is(':checked') ? 1 : 0,
            options: [],
            depends: {}
        };

        // Collect options
        $block.find('.option-blocks textarea').each(function() {
            const opt = $(this).val()?.trim();
            if (opt) q.options.push({ label: opt });
        });

        // Collect depends if active
        if (q.is_depends) {
            q.depends.label = $block.find('.depends-select').val() || '';
            q.depends.label_name = $block.find('.depends-tbox input[type="text"]').val()?.trim() || '';
            q.depends.input_value = $block.find('.depends-input-value').val() || '';
            q.depends.options = [];

            $block.find('.depends-option-blocks textarea').each(function() {
                const depOpt = $(this).val()?.trim();
                if (depOpt) q.depends.options.push({ label: depOpt });
            });
        }

        questionsData.push(q);
    });

    // Convert questions to hidden inputs
    questionsData.forEach((q, i) => {
        $('<input>', { type: 'hidden', name: `label_names[${i}]`, value: q.label_name }).appendTo($form);
        $('<input>', { type: 'hidden', name: `label_values[${i}]`, value: q.label_value }).appendTo($form);
        $('<input>', { type: 'hidden', name: `mandatory[${i}]`, value: q.is_mandatory }).appendTo($form);
        $('<input>', { type: 'hidden', name: `depend_mandatory[${i}]`, value: q.is_depend_mandatory }).appendTo($form);
        $('<input>', { type: 'hidden', name: `depends[${i}]`, value: q.is_depends }).appendTo($form);

        q.options.forEach((opt, j) => {
            $('<input>', { type: 'hidden', name: `options[${i}][${j}][label]`, value: opt.label }).appendTo($form);
        });

        if (q.is_depends) {
            $('<input>', { type: 'hidden', name: `depends_label[${i}]`, value: q.depends.label }).appendTo($form);
            $('<input>', { type: 'hidden', name: `depends_label_name[${i}]`, value: q.depends.label_name }).appendTo($form);
            $('<input>', { type: 'hidden', name: `depends_input_value[${i}]`, value: q.depends.input_value }).appendTo($form);

            q.depends.options.forEach((opt, j) => {
                $('<input>', { type: 'hidden', name: `depends_options[${i}][${j}][label]`, value: opt.label }).appendTo($form);
            });
        }
    });

    $form.get(0).submit();
}
</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_8.2.12\htdocs\server_dev_egc\dev.elysiumgroups.com\resources\views/content/settings/hrm/questionnaire/questionnaire_add.blade.php ENDPATH**/ ?>