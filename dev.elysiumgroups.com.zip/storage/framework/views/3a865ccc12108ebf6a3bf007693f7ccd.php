<?php $__env->startSection('style'); ?>
<?php $__env->startSection('title', 'Internal Cugs'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<!-- Vendor Scripts -->
<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="<?php echo e(url('/settings/general_settings')); ?>" type="button" class="nav-link scroll-link"
                                role="tab">
                                General Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/settings/sms_template')); ?>" type="button"
                                class="nav-link scroll-link active">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/settings/credential_book')); ?>" type="button"
                                class="nav-link scroll-link">
                                Entity
                            </a>
                        </li>
                         <li class="nav-item">
                            <a href="<?php echo e(url('/settings/document')); ?>" type="button" class="nav-link scroll-link ">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(url('/settings/applicant_status')); ?>" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card-body px-1 py-1">
            <div class="nav-align-right nav-tabs-shadow">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/sms_template')); ?>" type="button" class="nav-link" role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-message-processing me-2 fs-3"></i></span>
                                SMS Template
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/email_template')); ?>" type="button" class="nav-link" role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-email me-2 fs-3"></i></span>
                                Email Template
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/whatsapp_template')); ?>" type="button" class="nav-link" role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-whatsapp me-2 fs-3"></i></span>
                                Whatsapp Template
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/finiancial_year')); ?>" type="button" class="nav-link" role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-finance me-2 fs-3"></i></span>
                                Finiancial Year
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/currency_format')); ?>" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-currency-inr me-2 fs-3"></i></span>
                                Currency Format
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/country')); ?>" type="button" class="nav-link  " role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-map-legend me-2 fs-3"></i></span>
                                Country
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/state')); ?>" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-map-marker-radius me-2 fs-3"></i></span>
                                State
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/city')); ?>" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-city me-2 fs-3"></i></span>
                                City
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/timezone')); ?>" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-web-clock me-2 fs-3"></i></span>
                               Time Zone
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/settings/internal_cugs')); ?>" type="button" class="nav-link active" role="tab">
                            <label class="fs-6 right_nav">
                                <span><i class="mdi mdi-phone-classic me-2 fs-3"></i></span>
                                Internal Cugs
                            </label>
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0" style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black">Internal CUGs</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="<?php echo e(url('/dashboard')); ?>">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Common </a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Internal CUGs
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_Internal_Cugs">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Internal Cugs
                            </a>
                        </div>
                    </div>        
                     <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                 <?php $perpage_count = $perpage ? $perpage : 10; ?>
                                <div>
                                    <span>Show</span>
                                    <br>
                                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px" onchange="sort_filter(this.value);">
                                        <?php
                                        $options = [10, 25, 100, 500]; // Define available options
                                        ?>
                                        <?php foreach ($options as $option): ?>
                                        <option value="<?php echo e($option); ?>" <?php echo ($perpage_count == $option) ? 'selected' : ''; ?>>
                                            <?php echo $option; ?>
                                        </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <form id="filter_form" method="POST" action="/settings/internal_cugs">
                                     <?php echo csrf_field(); ?>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                            <input type="hidden" name="page" value="<?php echo e(request('page', 1)); ?>">
                                            <input type="hidden" name="filter_on" value="1">
                                            <input type="hidden" class="sorting_filter_class" name="sorting_filter" id="sorting_filter" value="<?php echo $perpage ? $perpage : 10; ?>" />
                                        <input class="searchQueryInput" type="text" placeholder="Enter Internal CUGs" id="search_filter" name="search_filter" value="<?php echo e($search_filter ?? ""); ?>" />
                                        <button class="searchQuerySubmit" type="submit" >
                                            <svg style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="#ab2b22" d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">S.No</th>
                                        <th class="min-w-100px">User Name</th>
                                        <th class="min-w-100px">Phone Number</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php if(isset($holi_list)): ?>
                                            <?php $__currentLoopData = $holi_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                    <tr>
                                        <td>
                                            <label class="fs-7 fw-medium"><?php echo e($loop->iteration); ?></label>
                                        </td>
                                        <td>
                                            <label class="fs-7 fw-medium"> <?php echo e($list->user_name); ?></label>
                                        </td>
                                        <td>
                                            <label class="fs-7 fw-medium"><?php echo e($list->cug_mobile_no); ?></label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_edit_Internal_Cugs" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom" title="Edit"  onclick="populateUpdateModal(`<?php echo e($list->sno); ?>`, `<?php echo e($list->user_name); ?>`,`<?php echo e($list->cug_mobile_no); ?>`)">
                                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="javascript:;" class="btn btn-icon btn-sm"
                                                    data-bs-toggle="modal" data-bs-target="#kt_modal_delete_Internal_Cugs"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Delete" onclick="confirmDelete(`<?php echo e($list->sno); ?>`,`<?php echo e($list->user_name); ?>`,`<?php echo e($list->cug_mobile_no); ?>`)">
                                                    <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <tr>
                                        <th></th>
                                        <th>No data available</th>
                                        <th></th>
                                        <th></th>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="mt-4">
                            <?php echo e($holi_list->appends(request()->except(['page', '_token']))->links()); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!--begin::Modal - Add  Internal Cugs -->
    <div class="modal fade" id="kt_modal_add_Internal_Cugs" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Internal Cugs</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form id="addForm" action="<?php echo e(route('Internal_cugs_add')); ?>"  method="POST" >
                       <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter User Name" id="user_name"  name="user_name" >
                             <div class="text-danger" id="user_name_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Phone Number<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Mobile Number" id="phone_no" name="phone_no" maxlength="10"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                             <div class="text-danger" id="phone_no_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="createbtn" class="btn btn-primary" onclick="addValidateForm()">Create
                             Internal Cugs</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add  Internal Cugs-->


    <!--begin::Modal - Edit  Internal Cugs -->
    <div class="modal fade" id="kt_modal_edit_Internal_Cugs" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update  Internal Cugs</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form id="updateForm"  method="POST" action="<?php echo e(route('Internal_cugs_update')); ?>" >
                        <?php echo csrf_field(); ?>
                    <div class="row">
                        <input type="hidden" id="edit_id" name="edit_id" />
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">User Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter User Name" id="user_name_edit"  name="user_name_edit" value="Sesha">
                            <div class="text-danger" id="user_name_edit_err"></div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Phone Number<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Mobile Number" value="8452169842" id="phone_no_edit" name="phone_no_edit" maxlength="10"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');">
                            <div class="text-danger" id="phone_no_edit_err"></div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="updatebtn" class="btn btn-primary"
                            onclick="editValidateForm()">Update  Internal Cugs</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit  Internal Cugs-->

    <!--begin::Modal - Delete  Internal Cugs-->
    <div class="modal fade" id="kt_modal_delete_Internal_Cugs" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Sesha</b>
                        User ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" onclick="deleteFunc()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete  Internal Cugs-->




    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
    // Display Toastr messages
        <?php if(Session::has('toastr')): ?>
            var type = "<?php echo e(Session::get('toastr')['type']); ?>";
            var message = "<?php echo e(Session::get('toastr')['message']); ?>";
            toastr[type](message);
        <?php endif; ?>
</script>
<script>
function sort_filter(val) {
    if (val != "") {
    $('.sorting_filter_class').val(val);
    $('#filter_form').submit();
    } else {
    $('.sorting_filter_class').val(10);
    $('#filter_form').submit();
    }
}
</script>
    <script>
        
    </script>
    <script>
        function populateUpdateModal(sno, user, mobile) {
            document.getElementById('edit_id').value = sno;
            document.getElementById('user_name_edit').value = user;
            document.getElementById('phone_no_edit').value = mobile; 
        }
    </script>
    <script>   
        function addValidateForm() {
            $("#createbtn").prop('disabled', true);
         var err = 0;
         
             var user_name = document.getElementById("user_name").value;
             if (user_name === "") {
                 $('#user_name_err').html('User Name is required...!');
                 err++;
             } else {
                 $('#user_name_err').html('');
             }
         
           var mobile = $('#phone_no').val().trim();
           if (mobile == '') {
               
               if (err == 0) {
                   $('#phone_no_err').html('Enter Mobile Number is Required..!');
                   err++;
               }
           } else {
               var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
               if (filter.test(mobile)) {
                   $('#phone_no_err').html('');
               } else {
                   if (err == 0) {
                       $('#phone_no_err').html('Enter a valid Phone number (e.g., 6311111111)..!');
                       err++;
                   }
               }
           }
   
         
            if(err>0){
                $("#createbtn").prop('disabled', false);
                return false;
            }else{
                $("#createbtn").prop('disabled', true);
                $('#addForm').submit();
            }
       }
   </script>
    <script>   
        function editValidateForm() {
         var err = 0;
         
             var user_name_edit = document.getElementById("user_name_edit").value;
             if (user_name_edit === "") {
                 $('#user_name_edit_err').html('User Name is required...!');
                 err++;
             } else {
                 $('#user_name_edit_err').html('');
             }
         
           var mobile = $('#phone_no_edit').val().trim();
           if (mobile == '') {
               
               if (err == 0) {
                   $('#phone_no_edit_err').html('Enter Mobile Number is Required..!');
                   err++;
               }
           } else {
               var filter = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;
               if (filter.test(mobile)) {
                   $('#phone_no_edit_err').html('');
               } else {
                   if (err == 0) {
                       $('#phone_no_edit_err').html('Enter a valid Phone number (e.g., 6311111111)..!');
                       err++;
                   }
               }
           }
   
         
       
          if(err>0){
            $("#updatebtn").prop('disabled', false);
            return false;
            }else{
                $("#updatebtn").prop('disabled', true);
                $('#updateForm').submit();
            }
       }
   </script>
   <script>
    function confirmDelete(id, user, mobile) {
        const deleteButton = document.querySelector('#kt_modal_delete_Internal_Cugs .btn-danger');
        
        if (deleteButton) {

            deleteButton.setAttribute('data-id', id);

            $('#delete_message').html(`Are you sure you want to delete <br><b class="text-danger"> ${user} [ ${mobile} ]</b> Internal cugs?`);
  
        } else {
            console.error('Delete button not found');
        }
    }

    function deleteFunc() {
        const deleteButton = document.querySelector('#kt_modal_delete_Internal_Cugs .btn-danger');
        const categoryId = deleteButton ? deleteButton.getAttribute('data-id') : null;

        if (categoryId) {
            fetch(`/Internal_cugs_delete/${categoryId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' // Ensure CSRF token is set correctly
                }
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 200) {
                    toastr.success(data.message);
                    location.reload();
                } else {
                    toastr.error(data.message);
                }
            })
            .catch(error => {
                toastr.error('An error occurred. Please try again. ' + error.message);
            });
        } else {
            toastr.error('Category ID not found.');
        }
    }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_8.2.12\htdocs\EGC_09_10-25\resources\views/content/settings/common/internal_cugs/internal_cugs_list.blade.php ENDPATH**/ ?>