<?php
    $currentRouteName = Route::currentRouteName();
?>

<ul class="menu-sub">
  <?php if(isset($menu)): ?>
    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
        $activeClass = null;
        $active = $configData["layout"] === 'vertical' ? 'active open' : 'active';
        $currentRouteName = Route::currentRouteName();

        if ($currentRouteName === $submenu->slug) {
            $activeClass = 'active';
        } elseif (isset($submenu->submenu)) {
            $slugList = is_array($submenu->slug) ? $submenu->slug : [$submenu->slug];
            foreach ($slugList as $slug) {
                if (str_starts_with($currentRouteName, $slug)) {
                    $activeClass = $active;
                }
            }
        }
      ?>

      <li class="menu-item <?php echo e($activeClass); ?>">
        <a href="<?php echo e(isset($submenu->url) ? url($submenu->url) : 'javascript:void(0)'); ?>" 
           class="<?php echo e(isset($submenu->submenu) ? 'menu-link menu-toggle' : 'menu-link'); ?>"
           <?php if(isset($submenu->target) && !empty($submenu->target)): ?> target="_blank" <?php endif; ?>>
          <?php if(isset($submenu->icon)): ?>
            <i class="<?php echo e($submenu->icon); ?>"></i>
          <?php endif; ?>
          <div><?php echo e(__($submenu->name ?? '')); ?></div>
          <?php if(isset($submenu->badge)): ?>
            <div class="badge bg-<?php echo e($submenu->badge[0]); ?> rounded-pill ms-auto">
              <?php echo e($submenu->badge[1]); ?>

            </div>
          <?php endif; ?>
        </a>

        
        <?php if(isset($submenu->submenu)): ?>
          <ul class="menu-sub">
            <?php $__currentLoopData = $submenu->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subsubmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="menu-item <?php echo e(\App\Helpers\Helpers::isActiveMenu($subsubmenu, $currentRouteName) ? 'active' : ''); ?>">
                <a href="<?php echo e(isset($subsubmenu->url) ? url($subsubmenu->url) : 'javascript:void(0)'); ?>" 
                   class="menu-link">
                  <?php if(isset($subsubmenu->icon)): ?>
                    <i class="<?php echo e($subsubmenu->icon); ?>"></i>
                  <?php endif; ?>
                  <div><?php echo e(__($subsubmenu->name ?? '')); ?></div>
                </a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        <?php endif; ?>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
</ul>
<?php /**PATH D:\Elyisa-Jeya Rosini H\Inhouse\EGC\UI\egc_original\resources\views/layouts/sections/menu/submenu.blade.php ENDPATH**/ ?>