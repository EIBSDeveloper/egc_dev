<?php
  $currentRouteName = Route::currentRouteName();
  $configData = \App\Helpers\Helpers::appClasses();
  $activeClass = '';

  // Default active class depending on layout type
  $active = $configData['layout'] === 'vertical' ? 'active open' : 'active';

  // Determine active menu based on slug
  if ($currentRouteName === ($menu->slug ?? '')) {
      $activeClass = 'active';
  } elseif (isset($menu->submenu)) {
      // Recursively check submenus for match
      foreach ($menu->submenu as $submenu) {
          if (isset($submenu->slug) && str_starts_with($currentRouteName, $submenu->slug)) {
              $activeClass = $active;
              break;
          }
      }
  }
  
  $hasSubmenu = isset($menu->submenu);
?>

<li class="menu-item <?php echo e($activeClass); ?>">
  <a href="<?php echo e(isset($menu->url) ? url($menu->url) : 'javascript:void(0);'); ?>"
     class="<?php echo e($hasSubmenu ? 'menu-link menu-toggle' : 'menu-link'); ?>"
     <?php if(isset($menu->target) && !empty($menu->target)): ?> target="_blank" <?php endif; ?>>
    
    
    <?php if(isset($menu->icon)): ?>
      <i class="<?php echo e($menu->icon); ?>"></i>
    <?php endif; ?>

    
    <div class="fs-7 fw-medium d-flex align-items-center">
      <?php echo e(__($menu->name ?? '')); ?>

    </div>

    
    <?php if(isset($menu->badge)): ?>
      <div class="badge bg-<?php echo e($menu->badge[0]); ?> rounded-pill ms-auto">
        <?php echo e($menu->badge[1]); ?>

      </div>
    <?php endif; ?>
  </a>

  
  <?php if($hasSubmenu): ?>
    <ul class="menu-sub">
      <?php $__currentLoopData = $menu->submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('layouts.sections.menu.menu_item', ['menu' => $submenu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  <?php endif; ?>
</li>
<?php /**PATH /home/elyerp2025/public_html/dev.elysiumgroups.com/resources/views/layouts/sections/menu/menu_item.blade.php ENDPATH**/ ?>