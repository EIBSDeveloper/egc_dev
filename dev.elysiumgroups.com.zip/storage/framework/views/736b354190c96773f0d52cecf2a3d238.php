<?php $__env->startSection('title', 'Update Email Template'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/quill/typography.scss', 'resources/assets/vendor/libs/quill/katex.scss', 'resources/assets/vendor/libs/quill/editor.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/quill/katex.js', 'resources/assets/vendor/libs/quill/quill.js', 'resources/assets/vendor/libs/highlight/highlight.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/forms-editors.js']); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">

        <div class="card-header border-bottom pb-1">
            <h5 class="card-title mb-1">Update Email Template</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/dashboards')); ?>" class="d-flex align-items-center"><i
                                class="mdi mdi-home text-body fs-4"></i></a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Settings</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Common</a>
                    </li>
                    <span class="text-dark opacity-75 me-1 ms-1">
                        <i class="mdi mdi-chevron-double-right fs-4"></i>
                    </span>
                    <li class="breadcrumb-item">
                        <a href="javascript:;" class="d-flex align-items-center">Email Template</a>
                    </li>
                </ol>
            </nav>
        </div>


        <div class="card-body">
            <div class="row mt-4">
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Template Name<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="email_name" name="email_name"
                        placeholder="Enter Email Name" value="Course Completeion" />
                    <div class="text-danger" id="email_name_err"></div>
                </div>
                <div class="col-lg-12 mb-3">
                    <label class="text-dark mb-1 fs-6 fw-semibold">Subject of Email<span
                            class="text-danger">*</span></label>
                    

                    <div id="snow-toolbar">
                        <span class="ql-formats">
                            <select class="ql-font"></select>
                            <select class="ql-size"></select>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-bold"></button>
                            <button class="ql-italic"></button>
                            <button class="ql-underline"></button>
                            <button class="ql-strike"></button>
                        </span>
                        <span class="ql-formats">
                            <select class="ql-color"></select>
                            <select class="ql-background"></select>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-script" value="sub"></button>
                            <button class="ql-script" value="super"></button>
                        </span>
                        <span class="ql-formats">
                            <button class="ql-header" value="1"></button>
                            <button class="ql-header" value="2"></button>
                            <button class="ql-blockquote"></button>
                            <button class="ql-code-block"></button>
                        </span>
                    </div>
                    <div id="snow-editor">
                        <div class="fs-6">Conngratulations on Completing Your Course!</div>
                    </div>
                </div>
            </div>
            <div class="d-flex justify-content-end align-items-center mt-4">
                <a href="<?php echo e(url('/settings/common/email_template')); ?>" class="btn btn-secondary me-3">Cancel</a>
                <button type="button" class="btn btn-primary">Update Email
                    Template</button>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_8.2.12\htdocs\EGC_09_10-25\resources\views/content/settings/common/email_template/edit.blade.php ENDPATH**/ ?>