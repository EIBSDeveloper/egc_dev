<?php
  $currentRouteName = Route::currentRouteName();
  $menuJson = \App\Helpers\Helpers::getMenuJson();
  $menuCollection = collect($menuJson);

  $menusOff = $menuCollection->whereIn('slug', [
      'hrm-hr-management', 'accounts-finance', 'corporate-admin', 'it-support', 'control-panel'
  ])->values();

  $menusOn = $menuCollection->whereIn('slug', [
      'etpl', 'eapl', 'eibs', 'ees'
  ])->values();

  // Example: get portal state from session (you can also use cookie)
  $portalState = session('portalState', 'off');
?>

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme" style="background-color:#AB2B22!important;">
    <!-- ! Hide app brand if navbar-full -->
  <?php if(!isset($navbarFull)): ?>
  <div class="app-brand demo">
    <a href="<?php echo e(url('/dashboard')); ?>" class="app-brand-link bg-white rounded px-1 py-0">
      <!-- Image for Left (Wide state) -->
      <img id="logo-left" src="<?php echo e(asset('assets/common/logo_full.png')); ?>" class="app-brand-logo demo" width="180px" height="50px" alt="EGC Logo">
      
      <!-- Image for Right (Compact state) - Initially hidden -->
      <img id="logo-right" src="<?php echo e(asset('assets/common/logo_small.png')); ?>" class="app-brand-logo demo" width="45" alt="EGC Logo" style="display: none;">
    </a>
  
    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto" style="  border: 2px solid rgba(255, 255, 255, 0.8);
      border-radius: 12px;
      background: rgba(255, 255, 255, 0.2);
      transition: all 0.3s ease;">
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M11.4854 4.88844C11.0081 4.41121 10.2344 4.41121 9.75715 4.88844L4.51028 10.1353C4.03297 10.6126 4.03297 11.3865 4.51028 11.8638L9.75715 17.1107C10.2344 17.5879 11.0081 17.5879 11.4854 17.1107C11.9626 16.6334 11.9626 15.8597 11.4854 15.3824L7.96672 11.8638C7.48942 11.3865 7.48942 10.6126 7.96672 10.1353L11.4854 6.61667C11.9626 6.13943 11.9626 5.36568 11.4854 4.88844Z" fill="#ffffff"/>
        <path d="M15.8683 4.88844L10.6214 10.1353C10.1441 10.6126 10.1441 11.3865 10.6214 11.8638L15.8683 17.1107C16.3455 17.5879 17.1192 17.5879 17.5965 17.1107C18.0737 16.6334 18.0737 15.8597 17.5965 15.3824L14.0778 11.8638C13.6005 11.3865 13.6005 10.6126 14.0778 10.1353L17.5965 6.61667C18.0737 6.13943 18.0737 5.36568 17.5965 4.88844C17.1192 4.41121 16.3455 4.41121 15.8683 4.88844Z" fill="#ffffff"/>
      </svg>
    </a>
  </div>
  <?php endif; ?>
  <ul class="menu-inner py-1 mb-10">
      
      
        <li class="menu-item">
          <form method="POST" action="<?php echo e(route('portal.switch')); ?>">
            <?php echo csrf_field(); ?>
              <label class="toggle-wrapper">
                  <input type="checkbox" name="portal_state" <?php echo e($portalState === 'on' ? 'checked' : ''); ?>>
                  <span class="toggle">
                      <span class="toggle-option management">Management</span>
                      <span class="toggle-option business">Business</span>
                  </span>
              </label>
          </form>
        </li>

    
    <?php $__currentLoopData = $menuJson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($menu->slug === 'dashboard'): ?>
        <li class="menu-item <?php echo e(\App\Helpers\Helpers::isActiveMenu($menu, $currentRouteName) ? 'active' : ''); ?>">
          <a href="<?php echo e(url($menu->url)); ?>" class="menu-link">
            <i class="<?php echo e($menu->icon); ?>"></i>
            <div class="fs-7 fw-medium"><?php echo e($menu->name); ?></div>
          </a>
        </li>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    

    
    <?php if($portalState === 'on'): ?>
      
      <?php $__currentLoopData = $menusOn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="menu-item">
          <?php echo $__env->make('layouts.sections.menu.menu_item', ['menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      
      <?php $__currentLoopData = $menusOff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="menu-item">
          <?php echo $__env->make('layouts.sections.menu.menu_item', ['menu' => $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

  </ul>
</aside>

<style>
  .toggle-wrapper {
    position: relative;
    display: inline-block;
    width: 100%;
    height: 45px;
    cursor: pointer;
  }

  .toggle-wrapper input {
    display: none;
  }

  .toggle {
    position: relative;
    width: 93%;
    height: 100%;
    background: #9333ea; /* Base purple */
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 5px;
    margin-left: 10px;
    color: white;
    font-weight: 600;
    font-size: 16px;
    transition: background 0.3s ease;
    overflow: hidden;
  }

  .toggle::before {
    content: '';
    position: absolute;
    top: 4px;
    left: 4px;
    width: 47%;
    height: calc(100% - 8px);
    background: #fff;
    border-radius: 6px;
    transition: 0.4s ease;
  }

  .toggle-option {
    position: relative;
    z-index: 2;
    flex: 1;
    text-align: center;
    transition: color 0.3s ease;
  }

  /* Default state → Management active */
  .toggle-wrapper input:not(:checked) + .toggle .management {
    color: #9333ea;
  }

  .toggle-wrapper input:not(:checked) + .toggle .business {
    color: #fff;
  }

  /* Checked state → Business active */
  .toggle-wrapper input:checked + .toggle::before {
    left: 49%;
  }

  .toggle-wrapper input:checked + .toggle .business {
    color: #9333ea;
  }

  .toggle-wrapper input:checked + .toggle .management {
    color: #fff;
  }
</style>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const toggle = document.getElementById("switch-portal-toggle");
    const portalName = document.getElementById("portal_name");
    const sidebar = document.getElementById("layout-menu");

    if (!toggle || !portalName || !sidebar) return;

    // Load persisted state
    const portalState = localStorage.getItem("portalState") || "off";
    toggle.checked = portalState === "on";
    updateMenus();

    toggle.addEventListener("change", () => {
      const state = toggle.checked ? "on" : "off";
      localStorage.setItem("portalState", state);
      updateMenus();
    });

    function updateMenus() {
      if (toggle.checked) {
        sidebar.classList.add("portal-on");
        portalName.textContent = "Business";
      } else {
        sidebar.classList.remove("portal-on");
        portalName.textContent = "Management";
      }
    }
  });
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const toggleInput = document.querySelector('.toggle-wrapper input[type="checkbox"]');
    const form = toggleInput.closest('form');

    toggleInput.addEventListener('change', function() {
        form.submit(); // Auto-submit when toggled
    });
});
</script>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const toggleButton = document.querySelector('.layout-menu-toggle');
    const logoLeft = document.getElementById('logo-left');
    const logoRight = document.getElementById('logo-right');

    const portalName = document.getElementById('portal-name');
    const portalButton = document.getElementById('portal-toggle-button');

    toggleButton.addEventListener('click', function() {
        // Toggle sidebar logos
        if (logoLeft.style.display === 'none') {
            logoLeft.style.display = 'block';
            logoRight.style.display = 'none';
            // Expand portal button
            portalName.style.display = 'block';
            portalButton.classList.remove('w-70');
            portalButton.classList.add('w-90');
        } else {
            logoLeft.style.display = 'none';
            logoRight.style.display = 'block';
            // Collapse portal button
            portalName.style.display = 'none';
            portalButton.classList.remove('w-90');
            portalButton.classList.add('w-70');
        }
    });
});
</script><?php /**PATH C:\Xampp_8.2.12\htdocs\server_dev_egc\dev.elysiumgroups.com\resources\views/layouts/sections/menu/verticalMenu.blade.php ENDPATH**/ ?>