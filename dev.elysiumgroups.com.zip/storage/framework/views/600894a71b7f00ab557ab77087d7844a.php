<?php $__env->startSection('title', 'Manage Company'); ?>

<?php $__env->startSection('vendor-style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
     'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
     'resources/assets/vendor/libs/select2/select2.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/form_wizard_icons.js']); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
 <?php
      $helper = new \App\Helpers\Helpers();
  ?>
  <!-- <style>
    .step-trigger.no-click {
      pointer-events: none; 
    }
  </style> -->
<div class="card mb-2">
    <div class="card-header border-bottom pb-1">
        <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Create Branch</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('/dashboard')); ?>">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item " aria-current="page">
                            <a href="javascript:void(0);" >
                                Entity Hub
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Manage Branch
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
    </div>
</div>
<form method="POST" action="<?php echo e(route('add_branch_franchise')); ?>" enctype="multipart/form-data" autocomplete="off"
            id="branch_form">
            <?php echo csrf_field(); ?>
      <div class="bs-stepper wizard-vertical vertical wizard-vertical-icons-example wizard-vertical-icons mt-2 gap-3 ">
        <div class="bs-stepper-header gap-lg-2">
          <div class="step" data-target="#location">
            <button type="button" class="step-trigger no-click" >

              <span class="avatar">
                <span class="avatar-initial rounded-2">
                  <i class="fa-solid fa-location-dot"></i>
                </span>
              </span>
              <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                <span class="bs-stepper-title">Branch And Location</span>
                <span class="bs-stepper-subtitle">Setup Address And Location</span>
              </span>
            </button>
          </div>
          <div class="step" data-target="#Contact" >
            <button type="button" class="step-trigger no-click">
              <span class="avatar">
                <span class="avatar-initial rounded-2">
                  <i class="fa-solid fa-phone"></i>
                </span>
              </span>
              <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                <span class="bs-stepper-title">Contact & Online Presence</span>
                <span class="bs-stepper-subtitle">Setup Contact & Online Presence</span>
              </span>
            </button>
          </div>
          <div class="step" data-target="#Compliance">
            <button type="button" class="step-trigger no-click">
              <span class="avatar">
                <span class="avatar-initial rounded-2">
                  <i class="fa-solid fa-handshake"></i>
                </span>
              </span>
              <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                <span class="bs-stepper-title">Compliance & Agreements</span>
                <span class="bs-stepper-subtitle">Setup Compliance & Agreements</span>
              </span>
            </button>
          </div>
           <div class="step" data-target="#Banking">
            <button type="button" class="step-trigger no-click">
              <span class="avatar">
                <span class="avatar-initial rounded-2">
                  <i class="fa-solid fa-building-columns"></i>
                </span>
              </span>
              <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                <span class="bs-stepper-title">Banking</span>
                <span class="bs-stepper-subtitle">Setup Banking</span>
              </span>
            </button>
          </div>
          <div class="step" data-target="#Collection">
            <button type="button" class="step-trigger no-click">
              <span class="avatar">
                <span class="avatar-initial rounded-2">
                  <i class="fa-solid fa-grip"></i>
                </span>
              </span>
              <span class="bs-stepper-label flex-column align-items-start gap-1 ms-2">
                <span class="bs-stepper-title">Collection Info & API</span>
                <span class="bs-stepper-subtitle">Setup Collection Info & API </span>
              </span>
            </button>
          </div>
        </div>
        <div class="bs-stepper-content">
            <div id="location" class="content">
              <div class="row">
                <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Branch Name<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Branch Name" maxlength="70"  id="branch_name" name="branch_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"  />
                      <div class="text-danger" id="branch_name_err"></div>
                  </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="countryId" name="country">
                            <option value="">Select Country</option>
                        </select>
                        <div class="text-danger" id="countryId_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="stateId" name="state">
                            <option value="">Select State</option>
                        </select>
                         <div class="text-danger" id="stateId_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="cityId" name="city">
                            <option value="">Select City</option>
                        </select>
                        <div class="text-danger" id="cityId_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Area / Street" id="area_street"  name="area_street" maxlength="80" />
                        <div class="text-danger" id="area_street_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Door/Flat No" id="door_flat_no" name="door_flat_no" maxlength="70" />
                        <div class="text-danger" id="door_flat_no_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Pincode" maxlength="7"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"  id="pincode" name="pincode"/>
                        <div class="text-danger" id="pincode_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">City Short Code<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter City Short Code" maxlength="5"  id="city_short_code" name="city_short_code" oninput="this.value = this.value.toUpperCase().replace(/[^a-zA-Z]/g, '');"/>
                        <div class="text-danger" id="city_short_code_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Latitude<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Latitude" maxlength="20" id="latitude" name="latitude"/>
                        <div class="text-danger" id="latitude_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Longitude<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Longitude" id="longitude" name="longitude" maxlength="20"/>
                        <div class="text-danger" id="longitude_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Time Zone<span class="text-danger">*</span></label>
                        <select class="select3 form-select" id="time_zone" name="time_zone">
                            <option value="">Select Time Zone</option>
                        </select>
                         <div class="text-danger" id="time_zone_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Currency Format<span
                              class="text-danger">*</span></label>
                      <select class="select3 form-select" id="currency_format" name="currency_format">
                          <option value="">Select Currency Format</option>
                      </select>
                       <div class="text-danger" id="currency_format_err"></div>
                  </div>
                  </div>
                  <div class="col-12 d-flex justify-content-between">
                    <button type="button" id="prev1" class="btn btn-outline-secondary"> 
                      <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button type="button" id="stage1"  class="btn btn-primary " onclick="validation_func(1)"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> </button>
                  </div>

            </div>
            <div id="Contact" class="content">
              <div class="row">
                <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Call Tracker Company ID</label>
                      <input type="text" class="form-control" placeholder="Enter Call Tracker Company ID"   maxlength="2" id="call_tracker_id" name="call_tracker_id" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Business Mobile No<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Business Mobile No"  id="business_mobile_no" name="business_mobile_no" maxlength="10" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" />
                      <div class="text-danger" id="business_mobile_no_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Business Email ID<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Business Email ID" id="business_email_id" name="business_email_id"  oninput=" this.value = this.value.toLowerCase();"/>
                       <div class="text-danger" id="business_email_id_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Communication Email ID<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Communication Email ID"  id="comm_email_id" name="comm_email_id" oninput=" this.value = this.value.toLowerCase();" />
                       <div class="text-danger" id="comm_email_id_err"></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="divider text-center">
                        <div class="divider-text text-black fs-5">Online Presence</div>
                      </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Location URL" name="location_url" id="location_url"/>
                        <div class="text-danger" id="location_url_err"></div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Website URL" />
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Facebook Link</label>
                        <input type="text" class="form-control" placeholder="Enter Facebook Link" />
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Instagram Link</label>
                        <input type="text" class="form-control" placeholder="Enter Instagram Link" />
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Just Dial Branch Code</label>
                        <input type="text" class="form-control" placeholder="Enter Just Dial Branch Code" />
                    </div>
                  </div>

              </div>
              <div class="col-12 d-flex justify-content-between">
                  <button type="button" id="prev2" class="btn btn-outline-secondary " onclick="safePrev(2)"> 
                    <span class="align-middle d-sm-inline-block d-none">Previous</span>
                  </button>
                  <button type="button" id="stage2" class="btn btn-primary " onclick="validation_func(2)"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> </button>
              </div>
            </div>
            <div id="Compliance" class="content">
              <div class="row">
                <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                      <input type="text" class="form-control" placeholder="Enter CIN No" id="tax_no" name="tax_no" maxlength="70"/>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                      <input type="text" class="form-control" placeholder="Enter GST No" id="gst_no" name="pan_no" maxlength="70" />
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                      <input type="text" class="form-control" placeholder="Enter PAN No" id="pan_no" name="pan_no" maxlength="70" />
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="divider text-center">
                        <div class="divider-text text-black fs-5">Agreement Info</div>
                      </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Agreement Start Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="agree_stdt" name="share_start_date"  placeholder="Select Date" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Agreement End Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="agree_eddt" name="share_end_date" placeholder="Select Date" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Opening Date</label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="open_dt" name="opening_date" placeholder="Select Date" class="form-control" readonly>
                        </div>
                    </div>
                  </div>

              </div>
              <div class="col-12 d-flex justify-content-between">
                    <button type="button" id="prev3" class="btn btn-outline-secondary " onclick="safePrev(3)"> <i class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1"></i>
                      <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button type="button" id="stage3" class="btn btn-primary " onclick="validation_func(3)"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> </button>
                  </div>
            </div>
            <div id="Banking" class="content">
              <div class="row">
                <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Bank Name" id="bank_name" name="bank_name" maxlength="70" />
                      <div class="text-danger" id="bank_name_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                              class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Bank Branch Name" id="bank_branch"  name="bank_branch" maxlength="70"/>
                      <div class="text-danger" id="bank_branch_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Account Holder" id="bank_holder"  name="bank_holder" maxlength="70"/>
                      <div class="text-danger" id="bank_holder_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Account No" id="bank_account_no"  name="bank_account_no" maxlength="20"/>
                      <div class="text-danger" id="bank_account_no_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter IFSC Code" id="bank_ifsc"  name="bank_ifsc" maxlength="150"/>
                      <div class="text-danger" id="bank_ifsc_err"></div>
                  </div>
              </div>
              <div class="col-12 d-flex justify-content-between">
                <button type="button" id="prev4" class="btn btn-outline-secondary" onclick="safePrev(4)"> 
                  <span class="align-middle d-sm-inline-block d-none">Previous</span>
                </button>
                <button type="button" id="stage4" class="btn btn-primary " onclick="validation_func(4)"> <span class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> </button>
              </div>
            </div>
            <div id="Collection" class="content">
              <div class="row">
                <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Collection Closing Date<span
                              class="text-danger">*</span></label>
                      <div class="input-group input-group-merge">
                          <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                          <input type="text" id="cllt_cl_dt" name="collection_close" placeholder="Select Date" class="form-control" readonly>
                      </div>
                       <div class="text-danger" id="cllt_cl_dt_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Registeration Closing Date<span
                              class="text-danger">*</span></label>
                      <div class="input-group input-group-merge">
                          <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                          <input type="text" id="reg_cl_dt" name="registeration_close" placeholder="Select Date" class="form-control" readonly>
                      </div>
                      <div class="text-danger" id="reg_cl_dt_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Minimum Amount Receive<span
                              class="text-danger">*</span></label>
                      <input type="text" class="form-control" placeholder="Enter Minimum Amount Receive"  id="min_amnt_receive" name="min_amnt_receive" maxlength="10" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"/>
                      <div class="text-danger" id="min_amnt_receive_err"></div>
                  </div>
                  <div class="col-lg-6 mb-3">
                      <input class="form-check-input" type="checkbox" id="bus_cls_dt" name="bus_closing_chk_month"  value="1" onclick="bus_cls_dt_func();" />
                      <label class="text-black mb-1 fs-6 fw-semibold" id="bus_cls_dt_txt">Business Closing Date (In
                          Count)<span class="text-danger">*</span></label>
                      <input type="text" class="form-control" id="bus_cls_dt_tbox" name="bus_closing_day_count"
                          placeholder="Enter Business Closing Date(In Count)" maxlength="2" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"/>
                      <div class="text-danger" id="bus_cls_dt_tbox_err"></div>
                  </div>
                  <div class="row">
                    <div class="col-lg-12">
                      <div class="divider text-center">
                        <div class="divider-text text-black fs-5">API Details</div>
                      </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Cloud Call API Key</label>
                        <textarea class="form-control" rows="1" placeholder="Enter Cloud Call API Key" id="cloud_call_api_key" name="cloud_call_api_key" maxlength="150"></textarea>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control h-auto" rows="1" placeholder="Enter Description" id="api_desc" name="api_desc" maxlength="150"></textarea>
                    </div>
                  </div>

              </div>
              <div class="col-12 d-flex justify-content-between">
                <button type="button" id="prev5" class="btn btn-outline-secondary " onclick="safePrev(5)">
                  <span class="align-middle d-sm-inline-block d-none">Previous</span>
                </button>
                <button type="button" id="brch_fran_butt" class="btn btn-primary"  onclick="validation_func(5)">Add Branch</button>
                 <input type="hidden" name="submit_popup" id="submit_popup" data-bs-toggle="modal" data-bs-target="#kt_modal_create_branch">
              </div>
            </div>
        </div>
      </div>
</form>




<!--begin::Modal - Create Branch-->
<div class="modal fade" id="kt_modal_create_branch" tabindex="-1" aria-hidden="true" aria-hidden="true"
    data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to
                <span id="create_label"> Create Branch </span> ?
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="button" class="btn fw-bold btn-primary me-3" onclick="submit_form()">Yes</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Create Branch-->



<script>
function bus_cls_dt_func() {
    var bus_cls_dt = document.getElementById("bus_cls_dt");
    var bus_cls_dt_txt = document.getElementById("bus_cls_dt_txt");
    var bus_cls_dt_tbox = document.getElementById("bus_cls_dt_tbox");

    if (bus_cls_dt.checked) {
        bus_cls_dt_txt.innerHTML = "Business Closing Date is Month End";
        bus_cls_dt_tbox.style.setProperty("display", "none", "important");
    } else {
        bus_cls_dt_txt.innerHTML = "Business Closing Date (In Count) <span class='text-danger'>*</span>";
        bus_cls_dt_tbox.style.setProperty("display", "block", "important");
    }
}
</script>


<!-- dropdown ajax country,state,city,timezone,currency-->
 <script>
      $(document).ready(function() {
          // Fetch and populate countries
          $.ajax({
              url: "<?php echo e(route('country')); ?>",
              type: "GET",
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      var countryDropdown = $('#countryId');
                      countryDropdown.empty();
                      countryDropdown.append('<option value="">Select Country</option>');
                      response.data.forEach(function(country) {
                          countryDropdown.append($('<option></option>').attr('value', country
                              .id).text(country.name));
                      });
                      // countryDropdown.val(selectedCountryId).trigger('change'); // Set the selected country and trigger change
                  }
              },
              error: function(error) {
                  console.error('Error fetching countries:', error);
              }
          });
          // Event listener for country change
          $('#countryId').on('change', function() {
              var countryId = $(this).val();
              var stateDropdown = $('#stateId');

              stateDropdown.empty().append('<option value="">Select State</option>');

              var city = $('#cityId');

              city.empty().append('<option value="">Select City</option>');

              if (countryId) {
                  // Fetch and populate states based on selected country
                  $.ajax({
                      url: "<?php echo e(route('state')); ?>",
                      type: "GET",
                      data: {
                          country_id: countryId
                      },
                      success: function(response) {
                          if (response.status === 200 && response.data) {
                              response.data.forEach(function(state) {
                                  stateDropdown.append($('<option></option>').attr(
                                      'value', state.id).text(state.name));
                              });
                              // stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                          }
                      },
                      error: function(error) {
                          console.error('Error fetching states:', error);
                      }
                  });
              }
          });

          // state change
          $('#stateId').on('change', function() {
              var countryId = $(this).val();
              var stateDropdown = $('#cityId');

              stateDropdown.empty().append('<option value="">Select City</option>');

              if (countryId) {
                  // Fetch and populate states based on selected country
                  $.ajax({
                      url: "<?php echo e(route('city')); ?>",
                      type: "GET",
                      data: {
                          state_id: countryId
                      },
                      success: function(response) {
                          if (response.status === 200 && response.data) {
                              response.data.forEach(function(state) {
                                  stateDropdown.append($('<option></option>').attr(
                                      'value', state.id).text(state.name));
                              });
                              // stateDropdown.val(selectedStateId).trigger('change'); // Set the selected state and trigger change
                          }
                      },
                      error: function(error) {
                          console.error('Error fetching states:', error);
                      }
                  });
              }
          });

          $.ajax({
              url: "<?php echo e(route('time_zone')); ?>",
              type: "GET",
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      // Populate the select dropdown with fetched time zones
                      var selectDropdown = $('select[name="time_zone"]');
                      selectDropdown.empty();
                      selectDropdown.append($(
                          '<option value="" >Select Time Zone</option>'));
                      response.data.forEach(function(t) {
                          var optionText = t.country_name + " (UTC " + t.utc_offset + ")";
                          var optionElement = $('<option></option>').attr('value', t.sno)
                              .text(optionText);
                          selectDropdown.append(optionElement);
                      });
                  }
              },
              error: function(error) {
                  console.error('Error fetching time zones:', error);
              }
          });

          $.ajax({
              url: "<?php echo e(route('currency_format')); ?>",
              type: "GET",
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      // Populate the select dropdown with fetched time zones
                      var selectDropdown = $('select[name="currency_format"]');
                      selectDropdown.empty();
                      selectDropdown.append($('<option value="">Select Currency Format</option>'));
                      response.data.forEach(function(t) {
                          var optionText = t.currency_code + " - " + t.currency_symbol;
                          var optionElement = $('<option></option>').attr('value', t.sno)
                              .text(optionText);
                          selectDropdown.append(optionElement);
                      });

                  }
              },
              error: function(error) {
                  console.error('Error fetching time zones:', error);
              }
          });
      });
 </script>

<script>
  function submit_form() {
        $('#branch_form').submit();
    }
</script>

<!-- validation  -->

<script>
  // ✅ Initialize Stepper once globally
  let stepper;

  $(document).ready(function () {
      const stepperEl = document.querySelector('.bs-stepper');
      if (stepperEl) {
          stepper = new Stepper(stepperEl);
      }
  });

  function validation_func(stage) {
    let err = false; // ✅ start false — assume no errors

    // ===== STAGE 1 =====
    if (stage === 1) {
        if (!$('#branch_name').val().trim()) { $('#branch_name_err').text('Branch Name is required.'); err = true; }
        if (!$('#countryId').val().trim()) { $('#countryId_err').text('Country is required.'); err = true; }
        if (!$('#stateId').val().trim()) { $('#stateId_err').text('State is required.'); err = true; }
        if (!$('#cityId').val().trim()) { $('#cityId_err').text('City is required.'); err = true; }
        if (!$('#area_street').val().trim()) { $('#area_street_err').text('Area / Street is required.'); err = true; }
        if (!$('#door_flat_no').val().trim()) { $('#door_flat_no_err').text('Door / Flat No is required.'); err = true; }
        if (!$('#pincode').val().trim()) { $('#pincode_err').text('Pincode is required.'); err = true; }
        if (!$('#city_short_code').val().trim()) { $('#city_short_code_err').text('City Short Code is required.'); err = true; }
        if (!$('#latitude').val().trim()) { $('#latitude_err').text('Latitude is required.'); err = true; }
        if (!$('#longitude').val().trim()) { $('#longitude_err').text('Longitude is required.'); err = true; }
        if (!$('#time_zone').val().trim()) { $('#time_zone_err').text('Time Zone is required.'); err = true; }
        if (!$('#currency_format').val().trim()) { $('#currency_format_err').text('Currency Format is required.'); err = true; }

        if (!err) safeNext(stage); // ✅ only go next if no validation errors
    }

    // ===== STAGE 2 =====
    else if (stage === 2) {
        if (!$('#business_mobile_no').val().trim()) { $('#business_mobile_no_err').text('Business Mobile Number is required.'); err = true; }

        const email1 = $('#business_email_id').val().trim();
        const email2 = $('#comm_email_id').val().trim();

        if (!email1) { $('#business_email_id_err').text('Business Email is required.'); err = true; }
        else if (!/^\S+@\S+\.\S+$/.test(email1)) { $('#business_email_id_err').text('Enter a valid Email ID.'); err = true; }

        if (!email2) { $('#comm_email_id_err').text('Communication Email is required.'); err = true; }
        else if (!/^\S+@\S+\.\S+$/.test(email2)) { $('#comm_email_id_err').text('Enter a valid Email ID.'); err = true; }

        if (!$('#location_url').val().trim()) { $('#location_url_err').text('Location URL is required.'); err = true; }

        if (!err) safeNext(stage);
    }

    // ===== STAGE 3 =====
    else if (stage === 3) {
        safeNext(stage);
    }

    // ===== STAGE 4 =====
    else if (stage === 4) {
        if (!$('#bank_name').val().trim()) { $('#bank_name_err').text('Bank Name is required.'); err = true; }
        if (!$('#bank_branch').val().trim()) { $('#bank_branch_err').text('Bank Branch is required.'); err = true; }
        if (!$('#bank_holder').val().trim()) { $('#bank_holder_err').text('Account Holder is required.'); err = true; }
        if (!$('#bank_account_no').val().trim()) { $('#bank_account_no_err').text('Account No is required.'); err = true; }
        if (!$('#bank_ifsc').val().trim()) { $('#bank_ifsc_err').text('IFSC Code is required.'); err = true; }

        if (!err) safeNext(stage);
    }

    // ===== STAGE 5 =====
    else if (stage === 5) {
        if (!$('#cllt_cl_dt').val().trim()) { $('#cllt_cl_dt_err').text('Collection Closing Date is required.'); err = true; }
        if (!$('#reg_cl_dt').val().trim()) { $('#reg_cl_dt_err').text('Registration Closing Date is required.'); err = true; }
        if (!$('#min_amnt_receive').val().trim()) { $('#min_amnt_receive_err').text('Minimum Amount Receive is required.'); err = true; }

        if (!$('#bus_cls_dt')[0]?.checked && !$('#bus_cls_dt_tbox').val().trim()) {
            $('#bus_cls_dt_tbox_err').text('Business Closing Date Count is required.');
            err = true;
        }

        if (!err) {
            $('#submit_popup').trigger('click');
        } else {
            $('#pop_cancel').trigger('click');
        }
    }
  }

function safeNext(stage) {
    console.log(`== SafeNext(${stage}) ==`);
    console.log("Before .to():", stepper._currentIndex);

    // 🩹 Force Stepper to truly reset to this stage
    stepper.to(stage);     // ensure we're at the right step
    stepper.to(stage);     // call twice to force internal sync

    console.log("After double .to():", stepper._currentIndex);

    // Now advance one step
    stepper.next();

    console.log("After .next():", stepper._currentIndex);
}
function safePrev(stage) {
    console.log(`== SafePrev(${stage}) ==`);
    console.log("Before .to():", stepper._currentIndex);

    // Go back one stage safely
    stepper.to(stage - 1);

    console.log("After .to():", stepper._currentIndex);
}
</script>

<script>
        let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            $.ajax({
                url: '/check-branch-duplicates',
                method: 'POST',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    field: field,
                    value: value,
                    sno: null
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#branch_name').on('input', debounce(function() {
            checkUniqueField('branch_name', $(this).val(), 'branch_name_err', 'brch_fran_butt');
        }, 600));
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/layoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Xampp_8.2.12\htdocs\EGC_09_10-25\resources\views/content/control_panel/entity_hub/manage_branch/add.blade.php ENDPATH**/ ?>