<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class ApplicantStatus extends Controller
{
    public function index()
    {
        return view(
            'content.settings.recruitment.applicant_status.applicant_status_list');
    }

}
