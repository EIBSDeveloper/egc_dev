<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BranchTypeModel extends Model
{
    use HasFactory;
    public $table = 'egc_branch_type';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'branchtype_id',
        'branch_id',
        'branchtype_name',
        'branchtype_desc',
        'created_by',
        'created_at',
        'status',
    ];
}
