@extends('layouts/blankLayout')

@section('title', 'Login')

@section('page-style')
@vite([
'resources/assets/vendor/scss/pages/page-auth.scss',
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
'resources/assets/vendor/libs/@form-validation/auto-focus.js'
])
@endsection

@section('content')

<div class="position-relative auth-background">
  <div class="authentication-wrapper authentication-basic container-p-y">
    <div class="authentication-inner py-4">

      <!-- Login Card -->
      <div class="card glass-card p-3 shadow-lg slide-login">
        <!-- Logo -->
        <div class="app-brand justify-content-center mt-0">
          <a href="{{ url('/') }}" class="app-brand-link gap-2">
            <span class="app-brand-logo demo">
              <img src="{{ asset('assets/common/logo_small.png') }}" width="120" height="120" alt="Company Logo">
            </span>
          </a>
        </div>
        <!-- /Logo -->

        <div class="card-body mt-0 mb-2">
          <h4 class="mb-2 text-center fw-bold mb-4">Empower with EGC</h4>

          <form class="mb-3" action="{{route('login_auth')}}" method="POST" onsubmit="return LoginvalidateForm()">
            @csrf
            <div class="mb-3">
                <div class="form-floating form-floating-outline">
                  <input type="text" class="form-control" id="user_name" name="name" placeholder="Enter username" autofocus value="">
                  <label for="user_name">Username</label>
                </div>
                <div class="text-danger ms-2" id="user_name_err"></div>
            </div>
            <div class="mb-3">
              <div class="form-password-toggle">
                <div class="input-group input-group-merge">
                  <div class="form-floating form-floating-outline">
                    <input type="password" id="password" class="form-control" name="password" placeholder="Enter password" />
                    <label for="password">Password</label>
                  </div>
                  <span class="input-group-text cursor-pointer">
                    <i class="mdi mdi-eye-off-outline"></i>
                  </span>
                </div>
              </div>
              <div class="text-danger ms-2" id="password_err"></div>
            </div>

            <div class="mb-3 d-flex justify-content-between align-items-center">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" id="remember-me" name="remember" value="1">
                <label class="form-check-label" for="remember-me">Remember Me</label>
              </div>
            </div>
            <div class="mb-3">
              <button type="submit" class="btn btn-sm btn-primary w-100 fs-6">Connect Workspace</button>
            </div>
            <p class="text-center text-primary mt-3" style="font-size: 0.9rem;">
              Innovation starts here – log in and drive progress.
              <!--<br>IP Address - <span class="text-danger mt-2 fs-6 fw-bold">{{ $ipAddress }}<span>-->
            </p>
            
          </form>
        </div>
      </div>
      <!-- /Login Card -->
    </div>
  </div>
</div>

<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<style>
  .btn-primary {
    text-transform: none;
  }
  .toast {
    background-color: #39484f;
  }
  .toast-success {
    background-color: green;
  }
  .toast-error {
    background-color: red;
  }
  .error_msg {
    border: solid 2px red !important;
    border-color: red !important;
  }
</style>
<style>
/* General Corporate Theme */
body {
  /* font-family: 'Segoe UI', 'Roboto', sans-serif; */
  background-color: #f5f6fa;
  color: #000;
}
.auth-background {
  position: relative;
  min-height: 100vh;
  display: flex;

  /* Gradient overlay + background image */
  background-image: 
    /* linear-gradient(135deg, rgba(199, 199, 199, 0.55), rgba(230, 235, 242, 0.26)), */
    url("{{ asset('assets/common/login_bg_1.jpg') }}");
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}

.auth-background::before {
  content: "";
  flex: 1;
  /* background: linear-gradient(135deg, #f5f6fa 0%, #e6ebf2 100%); */
}

.auth-background::after {
  content: "";
  flex: 1;
  background: url('assets/common/egc-image.jpg') center/cover no-repeat;
}

.glass-card {
  position: relative;
  z-index: 2;

  /* Frosted glass look */
  background: rgba(255, 255, 255, 0.81); /* more transparent */
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  /* backdrop-filter: blur(12px) saturate(180%);
  -webkit-backdrop-filter: blur(12px) saturate(180%);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2); */
  padding: 2rem;
}
/* Button style */
.btn-primary {
  background: linear-gradient(90deg, #ab2b22, #FBA919);
  border: none;
  transition: all 0.3s ease;
}

.btn-primary:hover {
  background: linear-gradient(90deg, #FBA919, #ab2b22);
  transform: scale(1.03);
}

/* Form inputs */
.form-control {
  border-radius: 6px;
  border: 1px solid #ced4da;
}

.form-control:focus {
  border-color: #ab2b22;
  box-shadow: 0 0 8px rgba(171, 43, 34, 0.3);
  transition: all 0.3s ease-in-out;
}

/* Links */
a.text-primary {
  color: #ab2b22 !important;
}

a.text-primary:hover {
  color: #FBA919 !important;
}

/* Responsive for Mobile */
@media (max-width: 991px) {
.glass-card {
  /* Frosted glass look */
  background: rgba(255, 255, 255, 0.74); /* more transparent */
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);

  /* Glassmorphism magic */
  backdrop-filter: blur(12px) saturate(180%);
  -webkit-backdrop-filter: blur(12px) saturate(180%);

  /* Depth */
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.2);
}
}

.form-control, .btn {
  border-radius: 8px;
}

@keyframes gradientBG {
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
}
</style>
<style>
button.btn-primary:disabled {
  background-color: #cce5ff !important;
  border-color: #b8daff !important;
  color: #ab2b22 !important;
  cursor: not-allowed;
}
</style>
<script type="text/javascript">
    function LoginvalidateForm() {
        var uname = document.getElementById("user_name").value;
        var pwd = document.getElementById("password").value;

        if (uname !== '' && pwd !== '') {
            login_validation(); // Assuming this is a valid function
            return true; // Allow form submission
        } else {
            // Handle error (e.g., show a message)
            return false; // Prevent form submission
        }
    }
</script>
<script>
  @if(Session::has('toastr'))
  var type = "{{ Session::get('toastr')['type'] }}";
  var message = "{{ Session::get('toastr')['message'] }}";
    toastr[type](message);
  @endif

  function LoginvalidateForm() {
    var err = 0;
    var user_name = document.getElementById("user_name").value.trim();
    if (user_name === "") {
        document.getElementById('user_name_err').innerHTML = 'User Name is required...!';
        document.getElementById('user_name').classList.add('error_msg');
        err++;
    } else {
        document.getElementById('user_name').classList.remove('error_msg');
        document.getElementById('user_name_err').innerHTML = '';
    }
    var password = document.getElementById("password").value.trim();
    if (password === "") {
        document.getElementById('password_err').innerHTML = 'Password is required...!';
        document.getElementById('password').classList.add('error_msg');
        err++;
    } else {
        document.getElementById('password').classList.remove('error_msg');
        document.getElementById('password_err').innerHTML = '';
    }
    if (err === 0) {
      showLoadingScreen();
      return true;
    }
    return false;
  }

  document.getElementById('user_name').addEventListener('input', function() {
    document.getElementById('user_name_err').innerHTML = '';
    this.classList.remove('error_msg');
  });

  document.getElementById('password').addEventListener('input', function() {
    document.getElementById('password_err').innerHTML = '';
    this.classList.remove('error_msg');
  });

  function showLoadingScreen() {
    document.getElementById('loadingScreen').style.display = 'block';
  }
</script>
@endsection
