'use strict';
(function () {
  const lead_potential_type_add = document.getElementById('lead_potential_type_add'),
    lead_potential_score_input = document.getElementById('lead_potential_score_input'),
    lead_potential_type_edit = document.getElementById('lead_potential_type_edit'),
    lead_potential_score_input_edit = document.getElementById('lead_potential_score_input_edit'),
    practical_theory_add = document.getElementById('practical_theory_add'),
    practical_theory_edit = document.getElementById('practical_theory_edit'),
    colorOptions_add = {
      start: [0, 10],
      connect: true,
      behaviour: 'tap-drag',
      step: 1,
      // tooltips: true,
      range: {
        min: 0,
        max: 10
      },
      pips: {
        mode: 'steps',
        stepped: true,
        density: 10
      }
      // direction: isRtl ? 'rtl' : 'ltr'
    },
    colorOptions_edit = {
      start: [7, 10],
      connect: true,
      behaviour: 'tap-drag',
      step: 1,
      // tooltips: true,
      range: {
        min: 0,
        max: 10
      },
      pips: {
        mode: 'steps',
        stepped: true,
        density: 10
      },
      direction: isRtl ? 'rtl' : 'ltr'
    },
    practical_theory_add_colorOpt = {
      start: [40],
      connect: true,
      behaviour: 'tap-drag',
      step: 10,
      // tooltips: true,
      range: {
        min: 0,
        max: 100
      },
      pips: {
        mode: 'steps',
        stepped: true,
        density: 10
      },
      direction: isRtl ? 'rtl' : 'ltr'
    },
    practical_theory_edit_colorOpt = {
      start: [40],
      connect: true,
      behaviour: 'tap-drag',
      step: 10,
      // tooltips: true,
      range: {
        min: 0,
        max: 100
      },
      pips: {
        mode: 'steps',
        stepped: true,
        density: 10
      },
      direction: isRtl ? 'rtl' : 'ltr'
    };

  if (lead_potential_type_add) {
    // lead_potential_type_add.style.height = '15px';
    noUiSlider.create(lead_potential_type_add, colorOptions_add);
    // Event listener for when the slider value changes
    // lead_potential_type_add.noUiSlider.on('update', function (values, handle) {
    //   const score = values[handle]; // Get the selected score
    //   lead_potential_score_input.value = score; // Set the value of the hidden input field
    // });
    lead_potential_type_add.noUiSlider.on('update', function (values, handle) {
      const minScore = Math.round(parseFloat(values[0])); // Get the selected minimum score
      const maxScore = Math.round(parseFloat(values[1])); // Get the selected maximum score
      const scoreRange = `${minScore}-${maxScore}`;
      lead_potential_score_input.value = scoreRange; // Set the value of the hidden input field
    });
  }

  if (lead_potential_type_edit) {
    // lead_potential_type_edit.style.height = '15px';
    noUiSlider.create(lead_potential_type_edit, colorOptions_edit);

    lead_potential_type_edit.noUiSlider.on('update', function (values, handle) {
      const minScore = Math.round(parseFloat(values[0])); // Get the selected minimum score
      const maxScore = Math.round(parseFloat(values[1])); // Get the selected maximum score
      const scoreRange = `${minScore}-${maxScore}`;
      lead_potential_score_input_edit.value = scoreRange; // Set the value of the hidden input field
    });
  }

  if (practical_theory_add) {
    // practical_theory_add.style.height = '15px';
    noUiSlider.create(practical_theory_add, practical_theory_add_colorOpt);
  }
  if (practical_theory_edit) {
    // practical_theory_edit.style.height = '15px';
    noUiSlider.create(practical_theory_edit, practical_theory_edit_colorOpt);
  }
})();
