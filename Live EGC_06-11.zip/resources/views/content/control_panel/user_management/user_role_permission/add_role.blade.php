@extends('layouts/layoutMaster')

@section('title', 'Add Role')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js', 
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Add User Role</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            User Management 
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            User Role Permission
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
    </div>
    <div class="card-body">
       <div class="row">
            <div class="col-lg-12 mb-2">
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">User Role Details</label>
                    </div>
                    <div class="col-lg-3 mb-3">
                        <label class="text-black fs-6 fw-semibold mb-3">User Role Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="user_role_name" name='user_role_name' placeholder="Enter User Role Name"
                            oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); }" />
                    </div>
                    <div class="col-lg-3 mb-3">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="map_under" id="map_under" value="1" 
                                onclick="document.getElementById('user_role_select').style.display = this.checked ? 'block' : 'none';" />
                            <label class="form-check-label" for="map_under">Map Under</label>
                        </div>
                        <div style="display: none;"  id="user_role_select">
                            <select name="user_role_select" class="select3 form-select">
                                <option value="">Select User Role</option>
                                <option value="1">Super Admin</option>
                                <option value="2">Sub Admin</option>
                                <option value="3">CFO</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Permission Details</label>
                    </div>
                    <div class="col-lg-4 mb-2" id="accessHeadDiv" style="display: none;">
                        <div class="card" style="background-color: #bebebeff !important;">
                            <div class="card-body">  
                                <div class="row px-1">
                                    <div class="col-lg-4 ">
                                        <input class="form-check-input " type="radio" name="access_head" id="view_rbh" value="1" checked/>
                                        <label class="text-black fs-6 fw-semibold" for="view_rbh" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Regional Branch Head">RBH</label>
                                    </div>
                                    <div class="col-lg-4 ">
                                        <input class="form-check-input " type="radio" name="access_head" id="view_rfh" value="2"  />
                                        <label class="text-black fs-6 fw-semibold" for="view_rfh" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Regional Franchises Head">RFH</label>
                                    </div>
                                    <div class="col-lg-4 ">
                                        <input class="form-check-input " type="radio" name="access_head" id="view_gm" value="3" />
                                        <label class="text-black fs-6 fw-semibold" for="view_gm" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Global Head">GH</label>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                    <div class="col-lg-4 mb-2 ">
                        <div class="card" style="background-color: #bebebeff !important;">
                            <div class="card-body">
                            <div class="row px-1">
                                <div class="col-lg-6">
                                    <input class="form-check-input " type="radio" name="manage_branch" id="view_mm" value="2" />
                                    <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi Manage</label>

                                </div>
                                <div class="col-lg-6">
                                    <input class="form-check-input " type="radio" name="manage_branch" id="view_sm" value="1" checked />
                                    <label class="text-black fs-6 fw-semibold" for="view_sm" title="Sigle Manage">Single Manage</label>

                                </div>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center py-4">
                        <div class="form-check form-check-inline">
                            <input class="form-check-input select-all" type="checkbox" id="selectAllMain" />
                            <label class="text-dark fs-6 fw-semibold" for="selectAllMain">Select All</label>
                        </div>
                    </div>  
                </div>  
                <div class="row">
                    <div class="col-lg-12 mb-2">
                        <div class="accordion accordion-danger-solid" id="accordionDashboard">
                            <div class="accordion-item">
                                <h2 class="accordion-header border border-white border-2 rounded" id="headingDashboard" >
                                    <button class="accordion-button collapsed d-flex align-items-center bg-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseDashboard" aria-expanded="false" aria-controls="collapseDashboard">
                                        <input type="checkbox" class="form-check-input me-3 parent-checkbox text-white" data-target="#collapseDashboard" name="dashboard">
                                        <span class="fs-6 fw-bold">Dashboard</span>
                                    </button>
                                </h2>
                                <div id="collapseDashboard" class="accordion-collapse collapse" aria-labelledby="headingDashboard" data-bs-parent="#accordionDashboard">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="dashboard_list">
                                                <label class="fs-6">CEO</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="dashboard_add">
                                                <label class="fs-6">Accounts</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="dashboard_edit">
                                                <label class="fs-6">Corporate Admin</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="dashboard_delete">
                                                <label class="fs-6">IT Support</label>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="card" style="background-color: #bebebeff !important;">
                                                    <div class="card-body">
                                                        <div class="row px-1">
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_mm" value="2" />
                                                                <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi Manage</label>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_sm" value="1" checked />
                                                                <label class="text-black fs-6 fw-semibold" for="view_sm" title="Sigle Manage">Single Manage</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-2">
                        <div class="accordion accordion-danger-solid" id="accordionSwitchPanel">
                            <div class="accordion-item">
                                <h2 class="accordion-header border border-white border-2 rounded" id="headingSwitchPanel" >
                                    <button class="accordion-button collapsed d-flex align-items-center bg-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSwitchPanel" aria-expanded="false" aria-controls="collapseSwitchPanel">
                                        <input type="checkbox" class="form-check-input me-3 parent-checkbox text-white" data-target="#collapseSwitchPanel" name="dashboard">
                                        <span class="fs-6 fw-bold">Switch Portal</span>
                                    </button>
                                </h2>
                                <div id="collapseSwitchPanel" class="accordion-collapse collapse" aria-labelledby="headingSwitchPanel" data-bs-parent="#accordionSwitchPanel">
                                    <div class="accordion-body">
                                        <div class="row">
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="management">
                                                <label class="fs-6">Management</label>
                                            </div>
                                            <div class="col-lg-2 d-flex align-items-center">
                                                <input type="checkbox" class="form-check-input me-2 child-checkbox" name="business">
                                                <label class="fs-6">Business</label>
                                            </div>
                                            <div class="col-lg-4">
                                                <div class="card" style="background-color: #bebebeff !important;">
                                                    <div class="card-body">
                                                        <div class="row px-1">
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_mm" value="2" />
                                                                <label class="text-black fs-6 fw-semibold" for="view_mm" title="Multi Manage">Multi Manage</label>
                                                            </div>
                                                            <div class="col-lg-6">
                                                                <input class="form-check-input " type="radio" name="manage_branch" id="view_sm" value="1" checked />
                                                                <label class="text-black fs-6 fw-semibold" for="view_sm" title="Sigle Manage">Single Manage</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>  
            </div>  
            <div class="col-lg-12 mb-2 d-flex align-items-center justify-content-between">
                <a href="{{url('user_management/manage_permission')}}" class="btn btn-outline-danger text-primary fw-bold">Cancel</a>
                <a href="javascript:;" type="submit" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_confirmation_role">Create User Role</a>
            </div>
       </div>
    </div>
</div>


<!--begin::Modal - Confirmation Staff-->
<div class="modal fade" id="kt_modal_confirmation_role" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content"><i class="mdi mdi-check fs-1"></i></div>
            </div>
            <div class="swal2-html-container mb-2" id="swal2-html-container" style="display: block;">Are you sure you want to
                Create User Role ?
                <div class="d-block fw-bold fs-5 py-2">
                    <label class="text-black">Super Admin</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8 pb-8 mb-4">
                <a href="{{url ('/user_management/manage_permission')}}" class="btn btn-success me-3">Yes</a>
                <a href="#" class="btn btn-outline-danger" data-bs-dismiss="modal">No</a>
            </div>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Confirmation Staff-->

<script>
  $(document).ready(function() {
      // Hide or show the div based on the selected radio button
      $('input[name="manage_branch"]').on('change', function() {
          if ($('#view_mm').is(':checked')) {
              $('#accessHeadDiv').show(); // Show the div when "Multi Manage" is selected
          } else {
              $('#accessHeadDiv').hide(); // Hide the div when "Single Manage" is selected
          }
      });

      // Trigger change event on page load to check the initial state
      $('input[name="manage_branch"]:checked').trigger('change');
  });
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {

        // Handle "select all" (parent checkbox)
        document.querySelectorAll(".parent-checkbox").forEach(function (parent) {
            parent.addEventListener("change", function () {
                const target = document.querySelector(this.dataset.target);
                if (target) {
                    const children = target.querySelectorAll(".child-checkbox");
                    children.forEach(child => child.checked = this.checked);
                }
            });
        });

        // Auto-check parent if any child is checked
        document.querySelectorAll(".child-checkbox").forEach(function (child) {
            child.addEventListener("change", function () {
                const parentCollapse = this.closest(".accordion-collapse");
                if (parentCollapse) {
                    const parentCheckbox = parentCollapse.previousElementSibling.querySelector(".parent-checkbox");
                    const children = parentCollapse.querySelectorAll(".child-checkbox");
                    const allChecked = [...children].every(ch => ch.checked);
                    const anyChecked = [...children].some(ch => ch.checked);

                    parentCheckbox.checked = allChecked;
                    parentCheckbox.indeterminate = !allChecked && anyChecked;
                }
            });
        });

    });
</script>

@endsection
