<?php

namespace App\Http\Controllers\hr_management\hr_enroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SocialMediaModel;
use App\Models\DepartmentModel;
use App\Models\QualificationModel;
use App\Models\LanguageModel;
use App\Models\StaffFamilyModel;
use App\Models\JobpositionModel;
use App\Models\SourceModel;
use App\Models\CompanyModel;
use App\Models\DocumentModel;
use App\Models\DocumentCheckListModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\User;
use App\Models\CredentialModel;
use App\Models\StaffWorkInfoModel;
use App\Models\StaffEducationInfoModel;
use App\Models\StaffCredentialModel;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use App\Events\WebhookDispatchedEvent;

class ManageStaff extends Controller
{
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
     $helper = new \App\Helpers\Helpers();
     $general_setting=$helper->general_setting_data();
    $staffData = StaffModel::where('egc_staff.status', '!=', 2)
      ->select('egc_staff.*',
      'egc_entity.entity_name',
      'egc_company.company_name',
      'egc_company.company_base_color',
      'egc_department.department_name',
      'egc_division.division_name',
      'egc_job_role.job_position_name as job_role_name',
      )
      ->leftJoin('egc_company', 'egc_staff.company_id', 'egc_company.sno')
      ->leftJoin('egc_entity', 'egc_staff.entity_id', 'egc_entity.sno')
      ->join('egc_department', 'egc_staff.department_id', 'egc_department.sno')
      ->join('egc_division', 'egc_staff.division_id', 'egc_division.sno')
      ->join('egc_job_role', 'egc_staff.job_role_id', 'egc_job_role.sno');
      
       if ($search_filter != '') {
            $staffData->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_staff.staff_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.nick_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_staff.mobile_no', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_division.division_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_job_role.job_position_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $staffData=$staffData->orderBy('egc_staff.sno', 'desc')->paginate($perpage);

        foreach($staffData as $staff){
            if($staff->company_type == 1){
                  $staff->company_name=$general_setting->title;
                  $staff->company_base_color ='#ab2b22';
            }
        }

       

        if ($request->ajax()) {
            $data = $staffData->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'staff_name' => $item->staff_name,
                    'nick_name' => $item->nick_name,
                    'gender' => $item->gender,
                    'company_id' => $item->company_id,
                    'entity_id' => $item->entity_id,
                    'company_type' => $item->company_type,
                    'department_name' => $item->department_name,
                    'division_name' => $item->division_name,
                    'job_role_name' => $item->job_role_name,
                    'exp_type' => $item->exp_type,
                    'basic_salary' => $item->basic_salary,
                    'completion_percentage' => $item->completion_percentage,
                    'company_base_color' => $item->company_base_color,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $staffData->currentPage(),
                'last_page' => $staffData->lastPage(),
                'total' => $staffData->total(),
            ]);
        }
        
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     
    return view('content.hr_management.hr_enroll.manage_staff.staff_list',[
        'company_list' => $company_list,
        'perpage' => $perpage,
        'search_filter' => $search_filter,
        ]);
  }
  
   public function AddOldStaff(Request $request)
  {

  
    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'staff_data_payload' => 'required'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $user_id = $request->user()->user_id;
    
    $company_type=2;
    $company_id=$request->staff_company_name;
    $entity_id=$request->staff_entity_name;
    $branch_id=$request->staff_branch_name;
    $staffData = json_decode($request->staff_data_payload, true); 
    //   return $staffData;
    foreach($staffData as $staff){
      
        $staff_check = StaffModel::where('company_id', $company_id)->orderBy('sno', 'desc')->first();
        $sno = $staff_check ? $staff_check->sno + 1 : 1;
      $staff_id = sprintf("EGC%02d%03d", $company_id, $sno);
      
        // Handle staff image upload
        $staff_image_url = $staff['staff_image'] ?? null;
        $staff_image = null;

        if ($staff_image_url) {
            // Determine file extension
            $ext = pathinfo(parse_url($staff_image_url, PHP_URL_PATH), PATHINFO_EXTENSION);
            if (!$ext) {
                $ext = 'jpg';
            }

            // Define target folder
            $folderPath = public_path("staff_images/Buisness/{$company_id}/{$entity_id}");

            // Ensure the folder exists
            if (!File::exists($folderPath)) {
                File::makeDirectory($folderPath, 0777, true, true);
            }
            return $folderPath;
            // ✅ Find the next available image number in this folder
            $existingFiles = File::files($folderPath);
            $maxNumber = 0;

            foreach ($existingFiles as $file) {
                // Match filenames like staff_image_5.jpg
                if (preg_match('/staff_image_(\d+)\./', $file->getFilename(), $matches)) {
                    $num = (int) $matches[1];
                    if ($num > $maxNumber) {
                        $maxNumber = $num;
                    }
                }
            }

            // Next available number
            $nextNumber = $maxNumber + 1;

            // Create new filename
            $staff_image_name = "staff_image_{$nextNumber}.{$ext}";
            $savePath = $folderPath . '/' . $staff_image_name;

            // Download and save the image
            try {
                $imageData = @file_get_contents($staff_image_url);
                if ($imageData !== false) {
                    file_put_contents($savePath, $imageData);
                    $staff_image = $staff_image_name;
                } else {
                    $staff_image = null;
                }
            } catch (Exception $e) {
                $staff_image = null;
            }
        }



    // Create new staff record
    $add_staff = new StaffModel();
    $add_staff->staff_id = $staff_id;
    $add_staff->company_id = $company_id;
    $add_staff->entity_id = $entity_id;
    $add_staff->branch_id = $branch_id;
    $add_staff->sub_department_id = $request->division_id ?? 0;
    $add_staff->department_id = $request->department_id ?? 0;
    $add_staff->role_id = $request->role_id;
    $add_staff->exp_type = $request->staff_type;
    $add_staff->staff_name = $request->staff_name;
    $add_staff->mobile_no = $request->mobile_no;
    $add_staff->alternative_no = $request->alternative_no;
    $add_staff->email_id = $request->email_id;
    $add_staff->gender = $request->gender;
    $add_staff->dob = date('Y-m-d', strtotime($request->dob));
    $add_staff->date_of_joining = date('Y-m-d', strtotime($request->date_of_joinig));
    $add_staff->contact_person_name = $request->contact_person_name;
    $add_staff->contact_person_no = $request->contact_person_no;
    $add_staff->martial_status = $request->martial_status ?? null;
    $add_staff->address = $request->address ?? null;
    $add_staff->staff_image = $staff_image ?? null;
    $add_staff->attachment = json_encode($attachments) ?? null;
    $add_staff->nick_name = $request->nick_name ?? null;
    $add_staff->position_role = $request->position_role ?? null;
    $add_staff->description = $request->description ?? null;
    $add_staff->basic_salary = $request->salary ?? null;
    $add_staff->per_hour_cost = $request->hour_cost ?? null;
    $add_staff->login_access = $request->login_access ?? 0;
    $login_access = $request->login_access ?? 0;
    $add_staff->employee_skill_id = $request->employee_skill;
    if ($login_access == 1) {
      $add_staff->user_name = $request->loginuser_name;
      $add_staff->password  = $request->loginpassword;
    } else {
      $add_staff->user_name = '';
      $add_staff->password  = '';
    }
    $add_staff->created_by = $request->user()->user_id;
    $add_staff->updated_by = $request->user()->user_id;

    $add_staff->save();
    // return $add_staff->sno;
    if ($add_staff) {
      // Add User for login credentials
      $login_access = $request->login_access;
      if ($login_access == 1) {
        User::create([
          'user_id' => $add_staff->sno,
          'role_id' => $request->role_id ?? 0,
          'branch_id' =>  $request->auth_branch_id,
          'entity_id' => $request->user()->entity_id,
          'name' => $request->loginuser_name,
          'password' => Hash::make($request->loginpassword),
          'email' => $request->email_id,
          'created_by' => $request->user()->user_id ?? 1,
          'updated_by' => $request->user()->user_id ?? 1,
        ]);
      }


      // Handle work information
      if ($request->staff_type == 2) {
        $positions = $request->input('position_') ?? [];
        foreach ($positions as $key => $position) {
          StaffWorkInfoModel::create([
            'staff_id' => $add_staff->sno,
            'staff_type' => $request->staff_type,
            'position' => $position,
            'year_of_experience' => $request->input("year_of_experience_")[$key] ?? 0,
            'company_name' => $request->input("company_name_")[$key],
            'work_start_date' => $request->input("exper_srt_date_")[$key] ? date('Y-m-d', strtotime($request->input("exper_srt_date_")[$key])) : null,
            'work_end_date' => $request->input("exper_end_date_")[$key] ? date('Y-m-d', strtotime($request->input("exper_end_date_")[$key])) : null,
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }
      // Handle staff credentials


      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff added Successfully!'
      ]);
    } 
        
    }
    
    // return $request;
    // Determine staff serial number
    $staff_check = StaffModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();
    $sno = $staff_check ? $staff_check->sno + 1 : 1;

    // Handle staff image upload
    $staff_image = '';
    if ($request->hasFile('staff_add_icon')) {
        $image = $request->file('staff_add_icon');
        $extension = $image->extension();

      if ($company_type == 1) {
          $folderPath = public_path('staff_images/Management');
      } else {
          $folderPath = public_path("staff_images/Buisness/{$company_id}/{$entity_id}");
      }
      // Create directory if not exists
        if (!File::exists($folderPath)) {
            File::makeDirectory($folderPath, 0777, true, true);
        }
          // Build file name
            $staff_imageName = 'staff_' . $staff->sno . '.' . $extension;
          // Move uploaded image
            $image->move($folderPath, $staff_imageName);
            $staff_image = $staff_imageName;
    }

    

    // Handle attachments
    $attachments = [];
    if ($request->hasFile('attachment')) {
      foreach ($request->file('attachment') as $file) {
        $attachmentName = 'attachment_' . $sno . '_' . $file->getClientOriginalName();
        $file->move(public_path('staff_attachments/staff_' . $sno), $attachmentName);
        $attachments[] = $attachmentName;
      }
    }

    // Generate staff ID
    $year = substr(date("y"), -2);
    $staff_id = sprintf("SF-%04d/%s", $sno, $year);

    // return json_encode($request->KnowledgeTag);
    $access_bran = $request->acces_branch_id ?? [];
    $access_fra  = $request->acces_franchise_id ?? [];
    // Combine the two arrays
    $access_multi = array_merge($access_bran, $access_fra);
    $bran_multi   = json_encode($access_multi);

    // Create new staff record
    $add_staff = new StaffModel();
    $add_staff->staff_id = $staff_id;
    $add_staff->branch_id = $request->auth_branch_id;
    $add_staff->shift_time_id = $request->shift_time;
    $add_staff->multi_branch_access    = $bran_multi ?? '';
    $add_staff->sub_department_id = $request->division_id ?? 0;
    $add_staff->department_id = $request->department_id ?? 0;
    $add_staff->role_id = $request->role_id;
    $add_staff->exp_type = $request->staff_type;
    $add_staff->staff_name = $request->staff_name;
    $add_staff->mobile_no = $request->mobile_no;
    $add_staff->alternative_no = $request->alternative_no;
    $add_staff->email_id = $request->email_id;
    $add_staff->gender = $request->gender;
    $add_staff->dob = date('Y-m-d', strtotime($request->dob));
    $add_staff->date_of_joining = date('Y-m-d', strtotime($request->date_of_joinig));
    $add_staff->contact_person_name = $request->contact_person_name;
    $add_staff->contact_person_no = $request->contact_person_no;
    $add_staff->martial_status = $request->martial_status ?? null;
    $add_staff->address = $request->address ?? null;
    $add_staff->staff_image = $staff_image ?? null;
    $add_staff->attachment = json_encode($attachments) ?? null;
    $add_staff->nick_name = $request->nick_name ?? null;
    $add_staff->position_role = $request->position_role ?? null;
    $add_staff->description = $request->description ?? null;
    $add_staff->basic_salary = $request->salary ?? null;
    $add_staff->per_hour_cost = $request->hour_cost ?? null;
    $add_staff->login_access = $request->login_access ?? 0;
    $login_access = $request->login_access ?? 0;
    $add_staff->employee_skill_id = $request->employee_skill;
    if ($login_access == 1) {
      $add_staff->user_name = $request->loginuser_name;
      $add_staff->password  = $request->loginpassword;
    } else {
      $add_staff->user_name = '';
      $add_staff->password  = '';
    }
    $add_staff->created_by = $request->user()->user_id;
    $add_staff->updated_by = $request->user()->user_id;

    $add_staff->save();
    // return $add_staff->sno;
    if ($add_staff) {
      // Add User for login credentials
      $login_access = $request->login_access;
      if ($login_access == 1) {
        User::create([
          'user_id' => $add_staff->sno,
          'role_id' => $request->role_id ?? 0,
          'branch_id' =>  $request->auth_branch_id,
          'entity_id' => $request->user()->entity_id,
          'name' => $request->loginuser_name,
          'password' => Hash::make($request->loginpassword),
          'email' => $request->email_id,
          'created_by' => $request->user()->user_id ?? 1,
          'updated_by' => $request->user()->user_id ?? 1,
        ]);
      }


      // Handle work information
      if ($request->staff_type == 2) {
        $positions = $request->input('position_') ?? [];
        foreach ($positions as $key => $position) {
          StaffWorkInfoModel::create([
            'staff_id' => $add_staff->sno,
            'staff_type' => $request->staff_type,
            'position' => $position,
            'year_of_experience' => $request->input("year_of_experience_")[$key] ?? 0,
            'company_name' => $request->input("company_name_")[$key],
            'work_start_date' => $request->input("exper_srt_date_")[$key] ? date('Y-m-d', strtotime($request->input("exper_srt_date_")[$key])) : null,
            'work_end_date' => $request->input("exper_end_date_")[$key] ? date('Y-m-d', strtotime($request->input("exper_end_date_")[$key])) : null,
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }
      // Handle staff credentials


      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Staff !'
      ]);
    }
    return redirect('hr_management/staff');
  }



  public function staff_add()
  {
     $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $source_list = SourceModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $jobPositionlist = JobpositionModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $documentTypeList = DocumentModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $documentCheckList = DocumentCheckListModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $qualificationList = QualificationModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $languageList = LanguageModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $credential_list = CredentialModel::where('status', 0)->orderBy('sno', 'ASC')->get(); 
     $management_department = DepartmentModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'ASC')->get();
     $management_user_role = UserRoleModel::where('status', 0)->where('company_type',1)->orderBy('sno', 'ASC')->get();
     $social_media_list = SocialMediaModel::where('status', 0)->orderBy('sno', 'ASC')->get();
     $questions = HrQuestionnaireModel::with(['depends' => function($q) {
        $q->where('status', 0);
    }])->where('status', 0)->get();
    return view('content.hr_management.hr_enroll.manage_staff.add_staff',[
        'social_media_list' => $social_media_list,
        'company_list' => $company_list,
        'source_list' => $source_list,
        'documentTypeList' => $documentTypeList,
        'jobPositionlist' => $jobPositionlist,
        'qualificationList' => $qualificationList,
        'languageList' => $languageList,
        'management_department' => $management_department,
        'management_user_role' => $management_user_role,
        'documentCheckList' => $documentCheckList,
        'credential_list' => $credential_list,
        'questions' => $questions
        ]);
  }

  public function Add(Request $request)
  {

    // return $request;
    // Validate incoming request
    $validator = Validator::make($request->all(), [
      'staff_name' => 'required|max:255'
    ]);

    if ($validator->fails()) {
      return response()->json([
        'status' => 401,
        'message' => 'Incorrect format input fields',
        'error_msg' => $validator->errors()->all(),
        'data' => null,
      ], 200);
    }

    $user_id = $request->user()->user_id;
    // return $request;
    // Determine staff serial number
    

      $company_type = $request->company ?? 1;
      $company_id   = $request->staff_company_name ?? 0;
      $entity_id    = $request->entity_name ?? 0;
      $branch_id    = $request->branch_id ?? 0;
       $staff_check = StaffModel::where('company_type',1)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();
       $sno = $staff_check ? $staff_check->sno + 1 : 1;
    
      // Generate staff ID
      if ($company_type == 1) {
          // Example: EGC01001, EGC01002 ...
          $staff_id = sprintf("EGC01%03d", $sno);
      } elseif ($company_type == 2) {
         $staff_company_check = StaffModel::where('company_id',$company_id)->where('status', '!=', 2)->orderBy('sno', 'desc')->first();
           $company_sno =$staff_company_check ? $staff_company_check->sno + 1 : 1;
          $prefix_num = 1 + (int)$company_id; // company_id=1→2, company_id=2→3
          $staff_id = sprintf("EGC%02d%03d", $prefix_num, $company_sno);
      } else {
          // Default / fallback
          $staff_id = sprintf("EGC01%03d", $sno);
      }

      return $request;
    // Stage 1 Base Details
    // Handle staff image upload
    $staff_image = '';
    if ($request->hasFile('staff_add_icon')) {
        $image = $request->file('staff_add_icon');
        $extension = $image->extension();

       if ($company_type == 1) {
          $folderPath = public_path('staff_images/Management');
      } else {
          $folderPath = public_path("staff_images/Buisness/{$company_id}/{$entity_id}");
      }
       // Create directory if not exists
        if (!File::exists($folderPath)) {
            File::makeDirectory($folderPath, 0777, true, true);
        }
          // Build file name
            $staff_imageName = 'staff_' . $staff->sno . '.' . $extension;
          // Move uploaded image
            $image->move($folderPath, $staff_imageName);
             $staff_image = $staff_imageName;
    }

    $staff_name = $request->staff_name;
    $completion_percentage = $request->completion_percentage;
    $mobile_no = $request->mobile_no;
    $gender = $request->gender ?? 1;
    $dob = $request->dob ? date('Y-m-d', strtotime($request->dob)) : NULL;
    $email_id = $request->email_id ?? NULL;
    $mother_tongue = $request->mother_tongue ?? NULL;
    $languages = $request->Languages ? json_encode($request->Languages) : NULL;
    $hobby = $request->hobby ?? NULL;
    $description = $request->description ?? NULL;

    // Stage 2 Family Details
      $father_name = $request->father_name;
      $father_occup = $request->father_occup;
      $mother_name = $request->mother_name ?? NULL;
      $mother_occup = $request->mother_occup ?? NULL;
      $marital_status = $request->marital_status ?? 2;
      $anniversary_date = $request->anniversary_date ? date('Y-m-d', strtotime($request->anniversary_date)) : NULL;
      $spouse_name = $request->spouse_name ?? NULL;
      $spouse_mobile = $request->spouse_mobile ?? NULL;
      $spouse_is_working = $request->is_working ?? 'No';
      $spouse_dob = $request->spouse_dob ? date('Y-m-d', strtotime($request->spouse_dob)) : NULL;
      $spouse_designation = $request->spouse_designation ?? NULL;
      $spouse_company_name = $request->spouse_company_name ?? NULL;
      $spouse_salary = $request->spouse_salary ?? NULL;
      $has_children = $request->has_children ?? NULL;
      $childrenCount = $request->childrenCount ?? 0;
      $child_name = $request->child_name ??  NULL;
      $child_dob = $request->child_dob ??  NULL;
      $child_std = $request->child_std ??  NULL;
      $child_year = $request->child_year ?? NULL;
      $has_Siblings = $request->has_Siblings ?? 0;
      $siblings_detail = $request->siblings_detail ?? Null;

      // Handle children details
      $children_details = null;
      if (!empty($childrenCount) && $childrenCount > 0) {
          $children_details_array = [];

          for ($i = 0; $i < $childrenCount; $i++) {
              $children_details_array[] = [
                  'child_name' => $child_name[$i] ?? null,
                  'child_dob' => isset($child_dob[$i]) ? date('Y-m-d', strtotime($child_dob[$i])) : null,
                  'child_std' => $child_std[$i] ?? null,
                  'child_year' => $child_year[$i] ?? null,
              ];
          }

          $children_details = json_encode($children_details_array);
      }


    // Stage 3 Contact Details
      $permanent_address =$request->permanent_address ?? Null;
      $residential_address = $request->residential_address ?? NULL;
      $staff_location_url = $request->staff_location_url ?? NULL;
      $staff_latitude = $request->staff_latitude ?? NULL;
      $staff_longitude = $request->staff_longitude ?? NULL;
      $contact_person_name = $request->contact_person_name ? json_encode($request->contact_person_name) : NULL;
      $contact_person_no = $request->contact_person_no ? json_encode($request->contact_person_no) : NULL;
    
      // Stage 4 social Media Detils
      $socialMediaData = $request->social_media;
         $socialMediaData = array_filter($socialMediaData, function($value) {
            return !is_null($value) && $value !== '';
        });
      $socialMediaData = $socialMediaData ? json_encode($socialMediaData) : Null;

      // stage 5 Educational Details 
        $qualification_type = $request->qualification_type ?? [];
        $degree = $request->degree ?? [];
        $major = $request->major ?? [];
        $univ_name = $request->univ_name ?? [];
        $is_Course = $request->is_Course ?? NULL;
        $course_tag = $request->course_tag ?? NULL;

      // stage 6 Work Exp Details 
        $work_exp_type = $request->work_type ?? 1;
        $work_company_name = $request->company_name ?? [];
        $work_position = $request->position ?? [];
        $work_exp_yrs = $request->exp_yrs ?? [];
        $work_salary = $request->salary ?? [];
        $work_st_date = $request->work_st_date ?? [];
        $work_end_date = $request->work_end_date ?? [];
        $exit_reason = $request->ExitReason ?? [];

      
        // attachments
        $doc_types = $request->doc_type ?? [];
        $attachments = [];
        $attachments_url=[];
        if ($request->hasFile('attachment')) {
            foreach ($request->file('attachment') as $index => $file) {
                if (!$file) continue; // skip empty or null

                // ✅ Determine base path depending on company type
                if ($company_type == 1) {
                    $destination = public_path('staff_attachments/Management');
                    $baseUrl = url('staff_attachments/Management');
                } else {
                    $destination = public_path("staff_attachments/Buisness/{$company_id}/{$entity_id}/staff_{$sno}");
                    $baseUrl = url("staff_attachments/Buisness/{$company_id}/{$entity_id}/staff_{$sno}");
                }

                // ✅ Create directory if not exists
                if (!File::exists($destination)) {
                    File::makeDirectory($destination, 0777, true, true);
                }

                // ✅ Build file name
                $originalName = $file->getClientOriginalName();
                $timestamp = time() . '_' . $index; // make unique per upload
                $attachmentName = "attachment_{$sno}_{$timestamp}_" . $originalName;

                // ✅ Move file to destination
                $file->move($destination, $attachmentName);

                // ✅ Build full URL for file
                $fileUrl = "{$baseUrl}/{$attachmentName}";

                // ✅ Push into two arrays
                $attachments[] = [
                    'doc_type'  => $doc_types[$index] ?? null,
                    'file_name' => $attachmentName,
                ];
                $attachments_url[] = $fileUrl;
            }
        }

      
      //  return  $request;
       // stage 7 Company Details
          if($company_type == 1){
            $department_id = $request->management_depart ?? 0;
            $division_id = $request->management_division ?? 0;
            $role_id = $request->management_user_role ?? 0;
            $job_role_id = $request->management_job_role ?? 0;
          }else{
            $department_id = $request->business_depart ?? 0;
            $division_id = $request->business_division ?? 0;
            $role_id = $request->business_user_role ?? 0;
            $job_role_id = $request->business_job_role ?? 0;
          }

            $erp_branch_id = $request->erp_branch_id ?? 0;
            $erp_department_id = $request->erp_department_id ?? 0;
            $erp_division_id = $request->erp_division_id ?? 0;
            $erp_job_role_id = $request->erp_job_role_id ?? 0;
            $erp_role_id = $request->erp_role_id ?? 0;
            $erp_under_role_id = $request->erp_under_role_id ?? 0;
          
          $nick_name = $request->pseudo_name ?? NULL;
          $doj = $request->doj ? date('Y-m-d', strtotime($request->doj)) : NULL;
          $basic_salary = $request->basic_salary ?? 0;
          $per_hr_cost = $request->per_hr_cost ?? 0;
          $skill_tag = $request->skill_tag ? json_encode($request->skill_tag) : NULL;
          $loginuser_name = $request->loginuser_name ?? Null;
          $loginpassword = $request->loginpassword ?? Null;
          $credential_check = $request->other_access ?? 0;

        // Other credential

      // stage 8 Application Details

          $applied_position = $request->applied_position ? json_encode($request->applied_position) : NULL;
          $source_id = $request->source_id;
          $source_details = $request->source_details ?? Null;

          $data = $request->all();
          // initialize arrays
          $questions = [];
          $dependents = [];
          // loop through request inputs
          foreach ($data as $key => $value) {
              // 🎯 Handle main question inputs (like q_1, q_2)
              if (preg_match('/^q_(\d+)$/', $key, $matches)) {
                  $questionId = $matches[1];
                  $questions[$questionId] = $value ?? null;
              }
              // 🎯 Handle dependent question inputs (like depend_1, depend_2)
              if (preg_match('/^depend_(\d+)$/', $key, $matches)) {
                  $dependId = $matches[1];
                  $dependents[$dependId] = $value ?? null;
              }
          }
          // Combine both into one structured JSON
          $application_details = [
              'questions' => (object) $questions,
              'dependents' => (object) $dependents,
          ];

      // return $application_details;


      // stage 8 Document Checklist Details
          $document_checked =$request->document_checked ? json_encode($request->document_checked) : NULL;
   
      // Create new staff record
        $add_staff = new StaffModel();
        $add_staff->staff_id = $staff_id;
        $add_staff->company_type = $company_type;
        $add_staff->company_id = $company_id;
        $add_staff->entity_id    = $entity_id;
        $add_staff->entity_id    = $entity_id;
        $add_staff->branch_id    = $branch_id;
        $add_staff->division_id = $division_id ?? 0;
        $add_staff->department_id = $department_id ?? 0;
        $add_staff->role_id = $role_id;
        $add_staff->job_role_id = $job_role_id;
        $add_staff->staff_name = $request->staff_name;
        $add_staff->mobile_no = $request->mobile_no;
        // $add_staff->alternative_no = $request->alternative_no;
        $add_staff->email_id = $request->email_id;
        $add_staff->exp_type = $work_exp_type;
        $add_staff->gender = $request->gender;
        $add_staff->hobby = $hobby;
        $add_staff->mother_tongue = $mother_tongue;
        $add_staff->languages = $languages;
        $add_staff->dob = date('Y-m-d', strtotime($request->dob));
        $add_staff->date_of_joining = $doj;
        $add_staff->contact_person_name = $contact_person_name;
        $add_staff->contact_person_no = $contact_person_no;
        $add_staff->martial_status = $marital_status ?? null;
        $add_staff->address = $permanent_address ?? null;
        $add_staff->residential_address = $residential_address ?? null;
        $add_staff->location_url = $staff_location_url ?? null;
        $add_staff->latitude = $staff_latitude ?? null;
        $add_staff->longitude = $staff_longitude ?? null;
        $add_staff->staff_image = $staff_image ?? null;
        $add_staff->attachment = !empty($attachments) ? json_encode($attachments) : null;
        $add_staff->nick_name = $nick_name ?? null;
        $add_staff->applied_position = $applied_position ?? null;
        $add_staff->source_id = $source_id ?? null;
        $add_staff->source_details = $source_details ?? null;
        $add_staff->description = $description ?? null;
        $add_staff->basic_salary = $basic_salary;
        $add_staff->per_hour_cost = $per_hr_cost;
        $add_staff->knowledge_tag = $skill_tag;
        $add_staff->credential = $credential_check;
        $add_staff->user_name = $loginuser_name;
        $add_staff->password  = $loginpassword;
        $add_staff->completion_percentage  = $completion_percentage;
        $add_staff->social_media_details  = $socialMediaData;
        $add_staff->document_checklist  = $document_checked;
        $add_staff->application_details = json_encode($application_details, JSON_PRETTY_PRINT);
        $add_staff->created_by = $request->user()->user_id;
        $add_staff->updated_by = $request->user()->user_id;

        $add_staff->save();
    // return $add_staff->sno;
    if ($add_staff) {

      // Save family details
      $add_family = new StaffFamilyModel();
      $add_family->staff_id = $add_staff->sno;
      $add_family->father_name = $father_name;
      $add_family->father_occup = $father_occup;
      $add_family->mother_name = $mother_name;
      $add_family->mother_occup = $mother_occup;
      $add_family->marital_status = $marital_status;
      $add_family->anniversary_date = $anniversary_date;
      $add_family->spouse_name = $spouse_name;
      $add_family->spouse_mobile = $spouse_mobile;
      $add_family->spouse_dob = $spouse_dob;
      $add_family->spouse_working = $spouse_is_working;
      $add_family->spouse_designation = $spouse_designation;
      $add_family->spouse_company_name = $spouse_company_name;
      $add_family->spouse_salary = $spouse_salary ?? 0;
      $add_family->has_children = $has_children;
      $add_family->children_count = $childrenCount;
      $add_family->children_details = $children_details;
      $add_family->has_siblings = $has_Siblings;
      $add_family->siblings_detail = $siblings_detail;
      $add_family->created_by = $request->user()->user_id ?? 1;
      $add_family->updated_by = $request->user()->user_id ?? 1;
      $add_family->save();


      // Add User for login credentials
        User::create([
          'user_id' => $add_staff->sno,
          'company_type' => $add_staff->company_type,
          'company_id' => $add_staff->company_id,
          'entity_id' => $add_staff->entity_id,
          'role_id' => $add_staff->role_id ?? 0,
          'branch_id' =>  $add_staff->branch_id,
          'name' => $loginuser_name,
          'password' => Hash::make($loginpassword),
          'email' => $request->email_id,
          'created_by' => $request->user()->user_id ?? 1,
          'updated_by' => $request->user()->user_id ?? 1,
        ]);
      
      
      // Handle education information
      
        foreach ($qualification_type as $key => $qualification) {
          StaffEducationInfoModel::create([
            'staff_id' => $add_staff->sno,
            'qualification_type' => $qualification,
            'degree_name' => $degree[$key],
            'major' => $major[$key],
            'university_name' => $univ_name[$key],
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
    //  return $request;
      // Handle work information
      if ($work_exp_type == 2) {
        foreach ($work_company_name as $key => $company) {
          StaffWorkInfoModel::create([
            'staff_id' => $add_staff->sno,
            'staff_type' => $work_exp_type,
            'position' => $work_position[$key],
            'year_of_experience' => $work_exp_yrs[$key] ?? 0,
            'company_name' => $company,
            'salary' => $work_salary[$key],
            'exit_reason' => $exit_reason[$key],
            'start_date' => $work_st_date[$key] ? date('Y-m-d', strtotime($work_st_date[$key])) : null,
            'end_date' => $work_end_date[$key] ? date('Y-m-d', strtotime($work_end_date[$key])) : null,
            'created_by' => $request->user()->user_id,
            'updated_by' => $request->user()->user_id,
          ]);
        }
      }


      // Handle staff credentials
      if ($credential_check == 1 && $request->has('credential')) {
          foreach ($request->credential as $credential_id => $data) {
              // Skip if username is empty
              if (!empty($data['username'])) {
                  StaffCredentialModel::create([
                      'staff_id'      => $add_staff->sno,
                      'credential_id' => $credential_id,
                      'user_name'     => $data['username'],
                      'password'      => $data['password'] ?? null,
                      'url_link'      => $data['url'] ?? null,
                      'description'   => $data['description'] ?? null,
                      'created_by'    => $request->user()->user_id,
                      'updated_by'    => $request->user()->user_id,
                  ]);
              }
          }
      }
        
      if($company_type == 2){
           $contact_person_name_first=$request->contact_person_name[0];
           $contact_person_no_first=$request->contact_person_no[0];
           if($add_staff->staff_image){
              $staff_image_url=url("staff_images/Buisness/{$staff->company_id}/{$staff->entity_id}/{$add_staff->staff_image}");
           }else{
                $staff_image_url=NULL;
           }

          $payload=[
            'sno' => $add_staff->sno,
            'entity_id' => $add_staff->entity_id,
            'staff_id' => $staff_id,
            'branch_id' => 1,
            'shift_time_id' => 1,
            'multi_branch_access'    => '',
            'sub_department_id' => $erp_division_id ?? 0,
            'department_id' => $erp_department_id ?? 0,
            'role_id' => $erp_role_id,
            'under_role_id' => $erp_under_role_id,
            'exp_type' => $work_exp_type,
            'staff_name' => $add_staff->staff_name,
            'mobile_no' => $add_staff->mobile_no,
            'alternative_no' => NULL,
            'email_id' => $add_staff->email_id,
            'gender' => $add_staff->gender,
            'dob' => $add_staff->dob,
            'date_of_joining' => $add_staff->date_of_joinig,
            'contact_person_name' => $contact_person_name_first,
            'contact_person_no' => $contact_person_no_first,
            'martial_status' => $martial_status ?? null,
            'address' => $add_staff->address ?? null,
            'staff_image' => $staff_image_url ?? null,
            'attachment' =>  $attachments_url,
            'nick_name' => $add_staff->nick_name ?? null,
            'position_role' => $add_staff->erp_role_id ?? null,
            'description' => $add_staff->description ?? null,
            'basic_salary' => $add_staff->basic_salary ?? null,
            'per_hour_cost' => $add_staff->per_hour_cost ?? null,
            'login_access' => 1,
            'employee_skill_id' => 0,
            'user_name' => $add_staff->user_name,
            'password'  => $add_staff->password,
            'work_company_name'  => $work_company_name,
            'work_position'  => $work_position,
            'work_exp_yrs'  => $work_exp_yrs,
            'work_salary'  => $work_salary,
            'exit_reason'  => $exit_reason,
            'work_st_date'  => $work_st_date,
            'work_end_date'  => $work_end_date,
            'credentials'  => $request->credential,
            'qualification_type'  => $qualification_type,
            'degree'  => $degree,
            'major'  => $major,
            'univ_name'  => $univ_name,
            
          ];
            $this->dispatchWebhooks($payload, 1);
      }

      session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Staff added Successfully!'
      ]);
    } else {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Could not add the Staff !'
      ]);
    }
    return redirect('hr_enroll/manage_staff');
  }
  // unq Check add
  public function checkunique_user_name()
  {
    $username = request()->input('value');
    $staff = StaffModel::where('user_name', $username)
      ->where('status', '!=', 2)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff username already assigned!',
        'data' => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Username available!',
        'data' => 0,
      ], 200);
    }
  }

  public function checkStaffMobileExists(Request $request)
  {
    $staff_mobile = $request->input('mobile');

    // Assuming you have a Lead model with a mobile field
    // $exists = StaffModel::where('mobile_no', $staff_mobile)->exists();
    $staff = StaffModel::where('mobile_no', $staff_mobile)
      ->where('status', '!=', 2)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff Mobile Number already assigned!',
        'data'    => 1,
      ], 200);
    } else {
      return response()->json([
        'message' => 'mobile no available!',
        'data'    => 0,
      ], 200);
    }
  }


  public function edit()
  {
    return view('content.hr_management.hr_enroll.manage_staff.edit_staff');
  }

    // unq esit chk username
  public function checkunique_user_name_edit()
  {
    $username = request()->input('value');
    $id = request()->input('id');
    // return $id;
    $staff = StaffModel::where('user_name', $username)
      ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff username already assigned!',
        'data' => $staff,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Username available!',
        'data' => 0,
      ], 200);
    }
  }
  // unq esit chk username
  public function checkStaffMobileExists_edit()
  {
    $staff_mobile = request()->input('mobile');
    $id           = request()->input('id');
    // return $id;
    $staff = StaffModel::where('mobile_no', $staff_mobile)
      ->where('status', '!=', 2)
      ->where('sno', '!=', $id)
      ->first();

    if ($staff) {
      return response()->json([
        'message' => 'Staff Mobile Number already assigned!',
        'data'    => $staff,
      ], 200);
    } else {
      return response()->json([
        'message' => 'Mobile Number available!',
        'data'    => 0,
      ], 200);
    }
  }

  public function exit_staff()
  {
    return view('content.hr_management.hr_enroll.manage_staff.exit_staff_list');
  }

  protected function dispatchWebhooks(StaffModel $broadcast, $userId = 1)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module','Staff_Add_Hook')->where('entity_id',$broadcast->entity_id)->first();

          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => get_class($broadcast),
              'dispatchable_id' => $broadcast->sno,
              'message_uuid' => $broadcast->sno,
              'payload' => $broadcast->toArray(),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

          // broadcast creation once
          broadcast(new WebhookDispatchedEvent($dispatch));

          // enqueue the job
          SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');

       
     
  }
}
