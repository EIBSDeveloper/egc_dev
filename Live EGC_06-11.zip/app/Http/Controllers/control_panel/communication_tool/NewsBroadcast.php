<?php

namespace App\Http\Controllers\control_panel\communication_tool;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\NewsBroadcastModel;
use App\Models\BroadcastThemeModel;
use Illuminate\Support\Facades\Validator;
use App\Models\BranchModel;
use App\Models\UserRolePermissionModel;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\DB;
use Smalot\PdfParser\Parser;
use PhpOffice\PhpWord\IOFactory;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use Illuminate\Support\Str;
use Carbon\Carbon;

class NewsBroadcast extends Controller
{
  protected static $branch_id = 1;

   public function index(Request $request)
{
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 10);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    date_default_timezone_set('Asia/Kolkata');
    // Now, run your query to check the current time in the set timezone
   $now = Carbon::now()->format('Y-m-d H:i:s');
    

    $country = NewsBroadcastModel::where('status', '!=', 2);
    if ($search_filter != '') {
        $country->where(function ($subquery) use ($search_filter) {
            $subquery->where('template_name', 'LIKE', "%{$search_filter}%");
        });
    }
           $country = $country->select('*', \DB::raw('
            CASE
                WHEN start_date <= "' . $now . '" AND end_date >= "' . $now . '" THEN 1
                WHEN start_date > "' . $now . '" THEN 2
                ELSE 3
            END AS phase_order
        '))
        ->orderByRaw('phase_order ASC') // Order by phase_order first
        ->orderBy('start_date', 'asc')
    ->paginate($perpage);



    $helper = new \App\Helpers\Helpers();
    // If AJAX request → return JSON only
    if ($request->ajax()) {
        $data = $country->map(function ($item) use ($helper) {
            return [
                'sno' => $item->sno,
                'status' => $item->status,
                'branch_ids' => json_decode($item->branch_id,true),
                'role_ids' => json_decode($item->role_ids,true),
                'template_name' => $item->template_name,
                'broadcast_message' => $item->broadcast_message,
                'start_date' => \Carbon\Carbon::parse($item->start_date)->format('d-M-Y h:i A'),
                'end_date' => \Carbon\Carbon::parse($item->end_date)->format('d-M-Y h:i A'),
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $country->currentPage(),
            'last_page' => $country->lastPage(),
            'total' => $country->total(),
        ]);
    }

    return view('content.control_panel.communication_tool.news_broadcast.news_broadcast_list', [
        'country' => $country,
        'perpage' => $perpage,
        'search_filter' => $search_filter
    ]);
}

  public function List()
  {
      $city = NewsBroadcastModel::where('status', 0)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
    
    public function List_for_edit()
  {
    $sms_template = NewsBroadcastModel::orderBy('name', 'ASC')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  
 public function Add(Request $request)
  {
      
      $branch_list = BranchModel::where('status', 0)->get();
      $theme_list = BroadcastThemeModel::where('status', 0)->get();

        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();
            $default_theme = BroadcastThemeModel::where('status',0)->first();
        $theme_id =$default_theme ? $default_theme->sno : 0 ;
    return view('content.control_panel.communication_tool.news_broadcast.add_news_broadcast',[
        'branch_list'=>$branch_list,
        'roleList'=>$roleList,
        'theme_list'=>$theme_list,
        'theme_id'=>$theme_id,
        ]);
  }
  
    public function Edit($id,Request $request)
  {
      
          $branch_list = BranchModel::where('status', 0)->get();
          $theme_list = BroadcastThemeModel::where('status', 0)->get();
        $helper = new \App\Helpers\Helpers();
        $decryptedValue = $helper->encrypt_decrypt($id, 'decrypt');
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $roleList = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();
            $editData = NewsBroadcastModel::where('status', '!=', 2) ->where('sno',$decryptedValue)
                    ->first();
                    $editData->branch_id=json_decode($editData->branch_id, true);
                    $editData->role_ids=json_decode($editData->role_ids, true);
                    $editData->information = json_decode($editData->information, true); 
                    $editData->firstData = $editData->information[0]; 
                 
                    
        $default_theme = BroadcastThemeModel::where('status',0)->first();
        $theme_id =$default_theme ? $default_theme->sno : 0 ;
    return view('content.control_panel.communication_tool.news_broadcast.edit_news_broadcast',[
            'branch_list'=>$branch_list,
            'roleList'=>$roleList,
            'theme_list'=>$theme_list,
            'editData'=>$editData,
            'theme_id'=>$theme_id,
        ]);
  }
  
    public function saveTemplate(Request $request)
{
    $branch_ids = $request->branch_id;
    $user_id = $request->user()->user_id ?? 1;
    if ($branch_ids === "all") {
        $branch_ids = DB::table("egc_branch")->where("status", 0)->pluck("sno")->toArray();
        $branch_ids = array_map('strval', $branch_ids);
    }

    $role_ids = $request->role_ids;
    if ($role_ids === "all") {
        $role_ids = DB::table("egc_user_role")->where("status", 0)->pluck("sno")->toArray();
         $role_ids = array_map('strval', $role_ids);
    }
    
    $themeData = DB::table('egc_broadcast_theme')
        ->where('egc_broadcast_theme.status', 0)
        ->where('egc_broadcast_theme.sno',$request->theme_id)
        ->first();
        
       
    $theme = $themeData ? json_decode($themeData->theme_style, true) : null;

    if ($theme) {
        $theme['position'] = 'sticky';
    }
    $uuid = (string) \Illuminate\Support\Str::uuid();

       
   $broadcast=NewsBroadcastModel::create([
        "uuid"          => $uuid,
        "branch_id"    => json_encode($branch_ids),
        "role_ids"     => json_encode($role_ids),
        "start_date"   => date('Y-m-d H:i:s', strtotime($request->start_date)),
        "end_date"     => date('Y-m-d H:i:s', strtotime($request->end_date)),
        "information"  => $request->information, // already json
        "theme_id"     => $request->theme_id,
        "broadcast_message"     => $request->broadcast_message,
        "theme_style"  => json_encode($theme), // Save the updated theme here
        "created_by"   => $user_id,
        "template_name"=> $request->template_name,
        "updated_by"   => $user_id,
    ]);
      $this->dispatchWebhooks($broadcast, $user_id);

    return response()->json(["status" => "success"]);
}

  public function Update(Request $request)
  {

    $broadcast_id = $request->broadcast_id;
    $branch_ids = $request->branch_id;
    $user_id = $request->user()->user_id ?? 1;
    if ($branch_ids === "all") {
        $branch_ids = DB::table("egc_branch")->where("status", 0)->pluck("sno")->toArray();
        $branch_ids = array_map('strval', $branch_ids);
    }

    $role_ids = $request->role_ids;
    if ($role_ids === "all") {
        $role_ids = DB::table("egc_user_role")->where("status", 0)->pluck("sno")->toArray();
         $role_ids = array_map('strval', $role_ids);
    }
    
    $themeData = DB::table('egc_broadcast_theme')
        ->where('egc_broadcast_theme.status', 0)
        ->where('egc_broadcast_theme.sno',$request->theme_id)
        ->first();
        
       
    $theme = $themeData ? json_decode($themeData->theme_style, true) : null;

    if ($theme) {
        $theme['position'] = 'sticky';
    }
    $UpdateBroadcast=NewsBroadcastModel::where('sno', $broadcast_id)->first();
    if($UpdateBroadcast){
        $UpdateBroadcast->branch_id    = json_encode($branch_ids);
        $UpdateBroadcast->role_ids    = json_encode($role_ids);
           $UpdateBroadcast->start_date  = date('Y-m-d H:i:s', strtotime($request->start_date));
           $UpdateBroadcast->end_date   = date('Y-m-d H:i:s', strtotime($request->end_date));
           $UpdateBroadcast->information  = $request->information; // already json
           $UpdateBroadcast->theme_id    = $request->theme_id;
           $UpdateBroadcast->broadcast_message     =$request->broadcast_message;
           $UpdateBroadcast->theme_style  =json_encode($theme); 
           $UpdateBroadcast->template_name =$request->template_name;
           $UpdateBroadcast->updated_by   = $user_id;
           $UpdateBroadcast->update();
        
    }else{
        return response()->json(["status" => "failed"]);
    }
   

    return response()->json(["status" => "success"]);
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  NewsBroadcastModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  NewsBroadcastModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  
  public function checkDates(Request $request) {
      
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('egc_news_broadcast')
        ->where('status', '!=',2)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}

public function checkDatesEdit(Request $request) {
      
      $broadcast_id=$request->broadcast_id;
      $start_date=date('Y-m-d H:i:s', strtotime($request->start_date));
      $end_date=date('Y-m-d H:i:s', strtotime($request->end_date));
        $start =  \Carbon\Carbon::parse($start_date);
        $end   =  \Carbon\Carbon::parse($end_date);

    $conflict = DB::table('egc_news_broadcast')
        ->where('status', '!=',2)
        ->where('sno', '!=',$broadcast_id)
        ->where(function ($q) use ($start, $end) {
            $q->whereBetween('start_date', [$start, $end])
              ->orWhereBetween('end_date', [$start, $end])
              ->orWhere(function ($q2) use ($start, $end) {
                  $q2->where('start_date', '<=', $start)
                     ->where('end_date', '>=', $end);
              });
        })
        ->first();

    if ($conflict) {
        return response()->json([
            'conflict' => true,
            'message' => "Start & End Date already used between {$conflict->start_date} and {$conflict->end_date}"
        ]);
    }

    return response()->json(['conflict' => false]);
}
  public function broadcastThemeById(Request $request) {
      
    $theme_id=$request->theme_id;

    $theme = DB::table('egc_broadcast_theme')
        ->where('egc_broadcast_theme.status','!=',2)
        ->where('egc_broadcast_theme.sno',$theme_id)
        ->first();

    if ($theme) {
        return response()->json([
            'status' => '200',
            'data' => json_decode($theme->theme_style)
        ]);
    }

    return response()->json(['status' => '500','data'=>null]);
}


public function newsBroadcastById(Request $request) {
      
    $template_id=$request->theme_id;

    $theme = DB::table('egc_news_broadcast')
        ->where('egc_news_broadcast.status', '!=',2)
        ->where('egc_news_broadcast.sno',$template_id)
        ->first();
        $data = json_decode($theme->theme_style, true); // decode as array
        $data['position'] = 'fixed'; 
    if ($theme) {
        return response()->json([
            'status' => '200',
            'allData' => $theme,
            'data' => $data,
            'content' => json_decode($theme->information),
        ]);
    }

    return response()->json(['status' => '500','data'=>null]);
}

   public function role_list_broadcast($id)
  {
    $data = NewsBroadcastModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('role_ids')
      ->first();

    $roleIds = json_decode($data->role_ids, true);
    $roles = [];
    foreach ($roleIds as $roleId) {
      $role = UserRoleModel::where('status', 0)->where('sno', $roleId)->first(); 
      $roles[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['roles' => $roles]
    ], 200);
  }


  public function Update_role(Request $request)
  {
    // return $request;
    $request->validate([
      'edit_role_sno' => 'required|integer',
      'Add_role_table' => 'required|array',
    ]);

   $user_id = $request->user()->user_id ?? 1;
    $broadcast = NewsBroadcastModel::where('sno', $request->edit_role_sno)
      ->first();

    if (!$broadcast) {
      return response()->json([
        'status' => 'error',
        'message' => 'Training document not found.',
      ], 404);
    }

    $roleIds = is_string($broadcast->role_ids) ? json_decode($broadcast->role_ids, true) : $broadcast->role_ids;
    $roleIds = is_array($roleIds) ? $roleIds : [];

    $newRoles = [];
    foreach ($request->Add_role_table as $roles) {
      if (is_array($roles)) {
        $newRoles = array_merge($newRoles, $roles);
      } else {
        $newRoles[] = $roles;
      }
    }

    $mergedRoles = array_unique(array_merge($roleIds, $newRoles));
    
    if($broadcast){
        $broadcast->role_ids=json_encode(array_values($mergedRoles));
        $broadcast->updated_by=$user_id;
        $broadcast->update();
    }
    // Fetch all roles at once to reduce DB queries
    $roles = UserRoleModel::where('status', 0)
      ->whereIn('sno', $mergedRoles)
      ->get()
      ->keyBy('sno');

    $rolesData = [];
    foreach ($mergedRoles as $roleId) {
      $role = $roles->get($roleId);
      $rolesData[] = [
        'id' => $roleId,
        'role_name' => $role->role_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Roles updated successfully!',
      'roles'   => $rolesData,
    ]);
  }
  
  
  public function removeRole(Request $request)
  {
      $request->validate([
          'sno' => 'required|integer',
          'role_id' => 'required'
      ]);
    $user_id = $request->user()->user_id ?? 1;
      $broadcast = NewsBroadcastModel::where('sno', $request->sno)->first();
  
      if(!$broadcast){
          return response()->json(['success' => false, 'message' => 'Record not found']);
      }
  
      // Decode role_ids
      $roleIds = is_string($broadcast->role_ids) ? json_decode($broadcast->role_ids, true) : $broadcast->role_ids;
  
      // Remove the role_id
      $roleIds = array_filter($roleIds, function($id) use ($request){
          return $id != $request->role_id;
      });
  
      if($broadcast){
          $broadcast->role_ids = json_encode(array_values($roleIds));
          $broadcast->updated_by=$user_id;
          $broadcast->update();
      }
    
  
      return response()->json(['success' => true]);
  }
    
  public function branch_list_broadcast($id)
  {
    $data = NewsBroadcastModel::where('sno', $id)
      ->where('status', '!=', 2)
      ->select('branch_id')
      ->first();

    $branchIds = json_decode($data->branch_id, true);
    $branches = [];
    foreach ($branchIds as $branchId) {
      $branch = BranchModel::where('status', 0)->where('sno', $branchId)->first(); 
      $branches[] = [
        'id' => $branchId,
        'branch_name' => $branch->branch_name ?? '-'
      ];
    }

    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' => ['branches' => $branches]
    ], 200);
  }
  
   public function branch_list(Request $request)
  {
     $user_id = $request->user()->user_id ?? 1;
     $entity_id = $request->user()->entity_id;
    $data = BranchModel::where('status', '!=', 2)
      ->where('entity_id', $entity_id)
      ->get();
      
    return response([
      'status' => 200,
      'message' => 'Data Fetched Successfully!',
      'error_msg' => null,
      'data' =>  $data
    ], 200);
  }


public function Update_branch(Request $request)
  {
   
    $request->validate([
      'edit_branch_sno' => 'required|integer',
      'Add_branch_table' => 'required|array',
    ]);

    $user_id = $request->user()->user_id ?? 1;
    $broadcast = NewsBroadcastModel::where('sno', $request->edit_branch_sno)
      ->first();

    if (!$broadcast) {
      return response()->json([
        'status' => 'error',
        'message' => 'Broadcast not found.',
      ], 404);
    }

    $branchIds = is_string($broadcast->branch_id) ? json_decode($broadcast->branch_id, true) : $broadcast->branch_id;
    $branchIds = is_array($branchIds) ? $branchIds : [];

    $newBranches = [];
    foreach ($request->Add_branch_table as $branches) {
      if (is_array($branches)) {
        $newBranches = array_merge($newBranches, $branches);
      } else {
        $newBranches[] = $branches;
      }
    }

    $mergedBranches= array_unique(array_merge($branchIds, $newBranches));

    if($broadcast){
        $broadcast->branch_id=json_encode(array_values($mergedBranches));
        $broadcast->updated_by=$user_id;
        $broadcast->update();
    }
    // Fetch all roles at once to reduce DB queries
    $branches = BranchModel::where('status', 0)
      ->whereIn('sno', $mergedBranches)
      ->get()
      ->keyBy('sno');

    $branchesData = [];
    foreach ($mergedBranches as $branchId) {
      $branch = $branches->get($branchId);
      $branchesData[] = [
        'id' => $branchId,
        'branch_name' => $branch->branch_name ?? '-',
      ];
    }

    return response()->json([
      'status'  => 'success',
      'message' => 'Branch updated successfully!',
      'branches'   => $branchesData,
    ]);
  }
  
  
  public function removeBranch(Request $request)
  {
      $request->validate([
          'sno' => 'required|integer',
          'branch_id' => 'required'
      ]);
     $user_id = $request->user()->user_id ?? 1;
      $broadcast = NewsBroadcastModel::where('sno', $request->sno)->first();
  
      if(!$broadcast){
          return response()->json(['success' => false, 'message' => 'Record not found']);
      }
  
      // Decode role_ids
      $branchIds = is_string($broadcast->branch_id) ? json_decode($broadcast->branch_id, true) : $broadcast->branch_id;
  
      // Remove the role_id
      $branchIds = array_filter($branchIds, function($id) use ($request){
          return $id != $request->branch_id;
      });
  
      if($broadcast){
          $broadcast->branch_id = json_encode(array_values($branchIds));
          $broadcast->updated_by=$user_id;
          $broadcast->update();
      }
    
  
      return response()->json(['success' => true]);
  }

  protected function dispatchWebhooks(NewsBroadcastModel $broadcast, $userId = 0)
  {
      $webhooks = SubErpWebhookModel::where('status', 0)->get();

      foreach ($webhooks as $hook) {
          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $hook->sno,
              'dispatchable_type' => get_class($broadcast),
              'dispatchable_id' => $broadcast->sno,
              'message_uuid' => $broadcast->uuid,
              'payload' => $broadcast->toArray(),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

          // enqueue the job
          SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
      }
  }

}
