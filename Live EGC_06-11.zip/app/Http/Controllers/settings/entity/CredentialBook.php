<?php

namespace App\Http\Controllers\settings\entity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\CredentialModel;
use App\Models\StateModel;


class CredentialBook extends Controller
{
  

public function index(Request $request)
    {
        $helper = new \App\Helpers\Helpers();
        $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 10);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $level = CredentialModel::where('status', '!=', 2);
        if ($search_filter != '') {
              $level->where(function ($subquery) use ($search_filter) {
                  $subquery->where('credential_name', 'LIKE', "%{$search_filter}%");
                      
              });
          }
        $level=$level->orderBy('sno', 'desc')
         ->paginate($perpage);

          

        if ($request->ajax()) {
            $data = $level->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'credential_name' => $item->credential_name,
                    'credential_desc' => $item->credential_des,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $level->currentPage(),
                'last_page' => $level->lastPage(),
                'total' => $level->total(),
            ]);
        }
      
        return view('content.settings.entity.credential_book.credential_book', [
          'level' => $level,
          'perpage' => $perpage,
            'search_filter' => $search_filter
        ]);
    }

    public function list()
    {
        $knowledge_level = CredentialModel::where('status', 0)->orderBy('sno', 'desc')->get();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $knowledge_level,
        ], 200);
    }

    public function Add(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'credential_name' => 'required|max:255',
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $credential_name = $request->credential_name;
            $credential_desc = $request->credential_desc;

            $user_id = $request->user()->user_id ?? 1;
            $chk = CredentialModel::where('credential_name', ucwords($credential_name))->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Name has been  already created!',
                ]);
            } else {
                $category_check = CredentialModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {
                    $year = substr(date("y"), -2);
                    $credential_id = "CL-0001/" . $year;
                } else {

                    $data = $category_check->credential_id;
                    $slice = explode("/", $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);

                    $next_number = (int) $result + 1;
                    $request = sprintf("CL-%04d", $next_number);

                    $year = substr(date("y"), -2);
                    $credential_id = $request . '/' . $year;
                }

                $add_category = new CredentialModel();
                $add_category->credential_id = $credential_id;
                $add_category->credential_name = Ucfirst($credential_name);
                $add_category->credential_desc = $credential_desc;
                $add_category->created_by = $user_id;
                $add_category->updated_by = $user_id;

                $add_category->save();

                if ($add_category) {
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Credential added Successfully!',
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Credential!',
                    ]);
                }
            }
            // return $result;
            return redirect()->back()->with('success', 'knowledge Created successfully!');
        }
    }

    public function Edit($id)
    {
        $credential = CredentialModel::where('sno', $id)->first();

        return response([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $credential,
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'credential_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $credential_name = $request->credential_name;
            $bg_color = $request->bg_color;
            $credential_desc = $request->credential_desc;

            $upd_CourseCategoryModel = CredentialModel::where('sno', $id)->first();

            $chk = CredentialModel::where('credential_name', ucwords($credential_name))->where('status', '!=', 2)->where('sno', '!=', $id)->first();

            if ($chk) {
                if ($chk->sno != $id) {
                    $result = response([
                        'status' => 401,
                        'message' => 'Error',
                        'error_msg' => 'Name has been  already assigned!',
                        'data' => null,

                    ], 200);
                } else {
                }
            }
            $upd_CourseCategoryModel->credential_name = Ucfirst($credential_name);
            $upd_CourseCategoryModel->credential_desc = $credential_desc;
            $upd_CourseCategoryModel->update();

            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status' => 200,
                    'message' => 'Successfully Updated!',
                    'error_msg' => null,
                    'data' => null,
                ], 200);
            } else {
                $result = response([
                    'status' => 401,
                    'message' => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data' => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel = CredentialModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status = 2;
        $upd_CourseCategoryModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel = CredentialModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

}
