<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\CurrencyFormatModel;
use Illuminate\Support\Facades\Validator;

class CurrencyFormat extends Controller
{
  
  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $currency_format = CurrencyFormatModel::where('status', '!=', 2);
    if ($search_filter != '') {
        $currency_format->where(function ($subquery) use ($search_filter) {
            $subquery->where('country_name', 'LIKE', "%{$search_filter}%")
                ->orWhere('currency_code', 'LIKE', "%{$search_filter}%")
                ->orWhere('currency_symbol', 'LIKE', "%{$search_filter}%")
                ->orWhere('currency_name', 'LIKE', "%{$search_filter}%");
                
        });
    }
    $currency_format=$currency_format->orderBy('sno', 'desc')
    ->paginate($perpage);

    return view('content.settings.common.currency_format.currency_format', [
      'currency_format' => $currency_format,
       'perpage' => $perpage,
       'search_filter' => $search_filter
    ]);
  }
  
  public function List()
  {
    $sms_template = CurrencyFormatModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'currencycode_name' => 'required|max:255',
      'currency_name' => 'required|max:255',
      'currencysymbol_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {


      $country_name = $request->country_name;
      $currency_code = $request->currencycode_name;
      $currency_name = $request->currency_name;
      $currency_symbol = $request->currencysymbol_name;
    
      $user_id = $request->user()->user_id ?? 1;
      $chk = CurrencyFormatModel::where('country_name', ucwords($country_name))->where('currency_code', ucwords($currency_code))->where('currency_name', ucwords($currency_name))->where('currency_symbol', ucwords($currency_symbol))->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Currency Format is exist!'
        ]);
        return redirect()->back();
      }

      $add_currencyformat = new CurrencyFormatModel();
      $add_currencyformat->country_name = $country_name;
      $add_currencyformat->currency_code = $currency_code;
      $add_currencyformat->currency_name = $currency_name;
      $add_currencyformat->currency_symbol = $currency_symbol;

      $add_currencyformat->save();

      if ($add_currencyformat) {

        session()->flash('toastr', [
          'type' => 'success',
          'message' => 'Currency Format added Successfully!'
        ]);
      } else {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Could not add the Currency Format!'
        ]);
      }
      return redirect()->back();
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'country_name' => 'required|max:255',
      'currencycode_name' => 'required|max:255',
      'currency_name' => 'required|max:255',
      'currencysymbol_name' => 'required|max:255'

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $country_name = $request->country_name;
      $currency_code = $request->currencycode_name;
      $currency_name = $request->currency_name;
      $currency_symbol = $request->currencysymbol_name;
      $edit_id = $request->edit_id;
      $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $edit_id)->first();
      $chk = CurrencyFormatModel::where('country_name', ucwords($country_name))->where('currency_code', ucwords($currency_code))->where('currency_name', ucwords($currency_name))->where('currency_symbol', ucwords($currency_symbol))->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Currency Format is exist!'
        ]);
        return redirect()->back();
      } else {
        $upd_CurrencyFormatModel->country_name = $country_name;
        $upd_CurrencyFormatModel->currency_code = $currency_code;
        $upd_CurrencyFormatModel->currency_name = $currency_name;
        $upd_CurrencyFormatModel->currency_symbol = $currency_symbol;

        $upd_CurrencyFormatModel->update();

        if ($upd_CurrencyFormatModel) {

          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Currency Format Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Currency Format!'
          ]);
        }
      }
    }
    return redirect()->back();
  }
  public function Delete($id)
  {
    $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $id)->first();
    $upd_CurrencyFormatModel->status = 2;
    $upd_CurrencyFormatModel->Update();


    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Status($id, Request $request)
  {

    $upd_CurrencyFormatModel = CurrencyFormatModel::where('sno', $id)->first();
    $upd_CurrencyFormatModel->status = $request->input('status', 0);
    $upd_CurrencyFormatModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}
