<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SocialMediaModel extends Model
{
    use HasFactory;
    public $table      = "egc_social_media";
    public $primaryKey = 'sno';


    protected $fillable = [
        'social_media_name',
        'social_media_desc',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}