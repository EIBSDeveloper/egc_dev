<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CompanyTypeModel extends Model
{
    use HasFactory;
    public $table      = "egc_company_type";
    public $primaryKey = 'sno';

    protected $fillable = [
        'sno',
        'branch_id',
        'company_type_id',
        'company_type_name',
        'slug_name',
        'company_type_desc',
        'created_by',
        'updated_by',
        'updated_at',
        'status',
    ];
}