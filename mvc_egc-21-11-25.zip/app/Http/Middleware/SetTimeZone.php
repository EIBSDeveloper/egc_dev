<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class SetTimeZone
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */

    public function handle($request, Closure $next)
    {

        // Check if user is authenticated
        if (!Auth::guard('web')->check()) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $user = $request->user();
        // dd($user);
        if (!$user) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $branchId = $user->branch_id;
        // dd($branchId);
        $branch = DB::table('egc_general_settings')
            ->join('egc_countrytimezones', 'egc_general_settings.time_zone', '=', 'egc_countrytimezones.sno')
            ->select('egc_countrytimezones.time_zone')
            ->first();

        // dd($branch);
        if ($branch && $branch->time_zone) {
            Config::set('app.timezone', $branch->time_zone);
            date_default_timezone_set($branch->time_zone);
        }
        // dd(config('app.timezone'));

        return $next($request);
    }
    // public function handle($request, Closure $next)
    // {
    //     if (Auth::check()) {
    //         $branchId = Auth::user()->branch_id;

    //         $generalSetting = DB::table('za_general_settings')
    //             ->join('za_countrytimezones', 'za_general_settings.time_zone', '=', 'za_countrytimezones.sno')
    //             ->where('za_general_settings.branch_id', $branchId)
    //             ->select('za_countrytimezones.time_zone')
    //             ->first();

    //         if ($generalSetting) {
    //             $timeZone = $generalSetting->time_zone;

    //             if ($timeZone) {
    //                 Config::set('app.timezone', $timeZone);
    //                 date_default_timezone_set($timeZone);
    //             }
    //         }
    //     } else {
    //         return redirect()->route('login');
    //     }

    //     return $next($request);
    // }
}