<?php

namespace App\Jobs;

use App\Events\WebhookDispatchedEvent;
use Illuminate\Support\Facades\Http;
use App\Models\WebhookDispatchModel;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class SendWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $dispatchSno;
    public $tries = 5;

    public function __construct(int $dispatchSno)
    {
        $this->dispatchSno = $dispatchSno;
        $this->onQueue('webhooks');
    }

    public function backoff(): array
    {
        return [60, 120, 300, 900, 3600];
    }

    public function handle()
    {
        $dispatch = WebhookDispatchModel::find($this->dispatchSno);
        if (!$dispatch || $dispatch->status === 2) return;

        $hook = $dispatch->webhook;
        if (!$hook) {
            $dispatch->update(['status' => 3, 'last_response' => 'No webhook configured']);
            broadcast(new WebhookDispatchedEvent($dispatch));
            return;
        }

        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);

        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);
        broadcast(new WebhookDispatchedEvent($dispatch));

        $timestamp = now()->getTimestamp();
        $signature = $hook->secret ? hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret) : null;

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : json_decode($hook->headers ?? '[]', true),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

       try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update([
                    'status' => 2,
                    'http_status' => $response->status(),
                    'last_response' => $response->body(),
                    'next_attempt_at' => null
                ]);
               broadcast(new WebhookDispatchedEvent($dispatch)); // broadcast success
            } else {
                // Don't broadcast raw 500s to frontend
                $dispatch->update([
                    'status' => 3,
                    'last_response' => 'Webhook failed. Will retry automatically.'
                ]);
                broadcast(new WebhookDispatchedEvent($dispatch)); // broadcast failed
            }

        } catch (\Throwable $e) {
            // Log the error for debugging but don't broadcast raw errors
            \Log::error("Webhook failed [{$dispatch->sno}]: ".$e->getMessage());

            $dispatch->update([
                'status' => 3,
                'last_response' => 'Webhook failed. Will retry automatically.'
            ]);
        }

        broadcast(new WebhookDispatchedEvent($dispatch));
    }

    public function failed(\Throwable $exception) // ← prefix with backslash
    {
        $dispatch = WebhookDispatchModel::find($this->dispatchSno);
        if ($dispatch) {
            $dispatch->update(['status' => 3, 'last_response' => $exception->getMessage()]);
            broadcast(new WebhookDispatchedEvent($dispatch));
        }
    }
}
