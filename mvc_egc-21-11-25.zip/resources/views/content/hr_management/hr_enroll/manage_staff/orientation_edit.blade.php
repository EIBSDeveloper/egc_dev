@extends('layouts/layoutMaster')

@section('title', 'Add Staff')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/sortablejs/sortable.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])

@endsection

@section('content')



    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action mb-2">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Update Orientation</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                HR Enroll
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Manage Staff
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="bs-stepper wizard-icons wizard-icons-example mt-2">
        <div class="bs-stepper-header">
            <div class="step active" data-target="#orientation">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/calender.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Orientation</span>
                        </span>
                    </span>
                </button>
            </div>
        </div>
        <div class="bs-stepper-content">
             <div id="orientation" class="content active">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="accordion" id="pending-tasks">
                      <div class="accordion-item mb-3">
                        <h2 class="accordion-header" id="headingOne">
                          <button
                            type="button"
                            class="accordion-button bg-label-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordionOne"
                            aria-expanded="true"
                            aria-controls="accordionOne">
                            <label class="text-black fs-5 fw-semibold"> Staff Introduction</label>
                          </button>
                        </h2>

                        <div id="accordionOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black fs-6 fw-semibold mt-2">Report</label>
                                    <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                                        <div class="dz-message needsclick fs-6">
                                            <div class="text-center text-black me-3 text">Drop files here or click to upload
                                            </div>
                                        </div>
                                        <div class="fallback">
                                            <input type="file" name="attachment[]" multiple>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 mb-3">
                                    <label class="text-black fs-6 mb-1 fw-semibold">Score<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="staff_name" name='staff_name'
                                        placeholder="Enter Score" value="-"/>
                                </div>



                                <div class="col-lg-4 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                  <select name="department" class="select3 form-select">
                                    <option value="">Select Department</option>
                                    <option value="1" selected>HR</option>
                                    <option value="2">Sales</option>
                                  </select>
                                </div>


                                <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                                  <select name="jobrole" class="select3 form-select">
                                    <option value="">Select Job Role</option>
                                    <option value="1" selected>HR Management</option>
                                    <option value="2">Sales</option>
                                  </select>
                                </div>


                                <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                                  <select name="position" class="select3 form-select">
                                    <option value="">Select Staff Name</option>
                                    <option value="1" >Sesha</option>
                                    <option value="2"selected>Ram Kumar</option>
                                    <option value="3">Sibi Raj</option>
                                  </select>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-item mb-3">
                        <h2 class="accordion-header " id="headingTwo">
                          <button
                            type="button"
                            class="accordion-button collapsed bg-label-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordionTwo"
                            aria-expanded="false"
                            aria-controls="accordionTwo">
                            <label class="text-black fs-5 fw-semibold"> Company Introduction</label>
                          </button>
                        </h2>
                        <div
                          id="accordionTwo"
                          class="accordion-collapse collapse show"
                          aria-labelledby="headingTwo"
                          data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                          <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black fs-6 mb-1 fw-semibold">Score<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="staff_name" name='staff_name'
                                        placeholder="Enter Score"  value="-"/>
                                </div>


                                <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                  <select name="department1" class="select3 form-select">
                                    <option value="">Select Department</option>
                                    <option value="1">HR</option>
                                    <option value="2"selected>Sales</option>
                                  </select>
                                </div>


                                 <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                                  <select name="jobrole1" class="select3 form-select">
                                    <option value="">Select Job Role</option>
                                    <option value="1">HR Management</option>
                                    <option value="2"selected>Sales Manager</option>
                                  </select>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-item mb-3">
                        <h2 class="accordion-header" id="headingThree">
                          <button
                            type="button"
                            class="accordion-button collapsed bg-label-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordionThree"
                            aria-expanded="false"
                            aria-controls="accordionThree">
                            <label class="text-black fs-5 fw-semibold"> Department Introduction</label>
                          </button>
                        </h2>
                        <div
                          id="accordionThree"
                          class="accordion-collapse collapse show"
                          aria-labelledby="headingThree"
                          data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                           <div class="row">
                              <div class="col-lg-12 mb-3">
                                  <label class="text-black fs-6 fw-semibold mt-2">Report</label>
                                  <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                                      <div class="dz-message needsclick fs-6">
                                          <div class="text-center text-black me-3 text">Drop files here or click to upload
                                          </div>
                                      </div>
                                      <div class="fallback">
                                          <input type="file" name="attachment[]" multiple>
                                      </div>
                                  </div>
                              </div>

                            <div class="col-lg-4 mb-3 ">
                              <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                              <select name="department2" class="select3 form-select">
                                <option value="">Select Department</option>
                                <option value="1"selected>HR</option>
                                <option value="2">Sales</option>
                              </select>
                            </div>




                            <div class="col-lg-4 mb-3 ">
                              <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                              <select name="position2" class="select3 form-select">
                                <option value="">Select Staff Name</option>
                                <option value="1">Nithish</option>
                                <option value="2"selected>Sarvesh</option>
                              </select>
                            </div>
                          </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-12 d-flex justify-content-between mt-4">
                      <button class="btn btn-outline-secondary btn-prev"> <i
                              class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                          <span class="align-middle d-sm-inline-block d-none">Cancel</span>
                      </button>
                      <button class="btn btn-primary btn-next"> <span
                              class="align-middle d-sm-inline-block d-none me-sm-1">Update Staff</span> <i
                              class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                  </div>

                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - Other Credentials-->
    <div class="modal fade" id="kt_modal_other_credentials" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Other Credentials</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded border border-black"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="row mt-2">
                        <div class="col-lg-12 mb-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="skype_id"
                                    data-cred="skype" />
                                <label class="text-black mb-1 fs-6 fw-semibold">Teams</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="spark_id"
                                    data-cred="spark" />
                                <label class="text-black mb-1 fs-6 fw-semibold">Spark</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="firewall_id"
                                    data-cred="firewall" />
                                <label class="text-black mb-1 fs-6 fw-semibold">Firewall</label>
                            </div>
                        </div>
                        <div class="mb-2" id="skype_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Teams Credentials</h5>
                            <div class="row mt-2">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2" id="spark_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Spark Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2" id="firewall_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Firewall Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <button type="reset" class="btn btn-outline-danger me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Give Access</button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
    </div>
    <!--end::Modal - Other Credentials-->

    <!--begin::Modal - Confirmation Staff-->
    <div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content"><i class="mdi mdi-check fs-1"></i></div>
                </div>
                <div class="swal2-html-container mb-2" id="swal2-html-container" style="display: block;">Are you sure
                    you
                    want to
                    Create Staff ?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label class="text-black">Mahesh</label>
                        <span class="ms-2 me-2">-</span>
                        <label class="text-black">EGCS-0001/24</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8 mb-4">
                    <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-success me-3">Yes</a>
                    <a href="#" class="btn btn-outline-danger" data-bs-dismiss="modal">No</a>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Confirmation Staff-->



    {{-- <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script> --}}
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>

    <!--Staff Add Credentials Accordion Start-->
    <script>
        'use strict';

        (function() {
            // Accordion toggle
            const credentials_acrd = document.querySelectorAll('.credentials_acrd');
            credentials_acrd.forEach(el => {
                el.addEventListener('click', event => {
                    event.preventDefault();
                    const card = el.closest('.card');
                    const collapseEl = card.querySelector('.collapse.credentials_acrd_body');

                    new bootstrap.Collapse(collapseEl);
                    card.querySelector('.card-header').classList.toggle('collapsed');
                    Helpers._toggleClass(el.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });

            // Generic credential toggle
            function toggleCredential(id, show) {
                const section = document.getElementById(id + '_cred');
                if (section) section.style.display = show ? 'block' : 'none';
            }

            // Select All
            document.getElementById('credential_check_all')?.addEventListener('change', function() {
                const checked = this.checked;
                document.querySelectorAll('.cred_check').forEach(cb => {
                    cb.checked = checked;
                    toggleCredential(cb.dataset.cred, checked);
                });
            });

            // Individual checkbox handling
            document.querySelectorAll('.cred_check').forEach(cb => {
                cb.addEventListener('change', function() {
                    toggleCredential(this.dataset.cred, this.checked);
                });
            });

            // Dropdown-based create credential
            document.getElementById('create_cred')?.addEventListener('change', function() {
                const value = this.value;
                ['skype', 'spark', 'firewall'].forEach(id => {
                    toggleCredential(id, id === value);
                });
            });
        })();
    </script>

<script>
    // Using document.querySelector to select the elements
    var pendingtasks = document.querySelector('#pending-tasks');
    var completedtasks = document.querySelector('#completed-tasks');

    // Initialize sortable lists using the selected elements
    new Sortable(pendingtasks, {
      animation: 150,
      group: 'tasklist'
    });

    new Sortable(completedtasks, {
      animation: 150,
      group: 'tasklist'
    });
  </script>


<script>
    // Select/Deselect All functionality
    document.getElementById('selectAll').addEventListener('change', function() {
        const checked = this.checked;
        document.querySelectorAll('.checklist-item').forEach(item => {
            item.checked = checked;
        });
    });
</script>



    <script>
        $(document).ready(function() {
            // Run once on load
            toggleDivs();

            // Change event on radio buttons
            $("input[name='company']").on("change", function() {
                toggleDivs();
            });

            function toggleDivs() {
                if ($("#management").is(":checked")) {
                    $(".management_div").show();
                    $(".business_div").hide();
                } else if ($("#business").is(":checked")) {
                    $(".business_div").show();
                    $(".management_div").hide();
                }
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            let eduIndex = 1; // unique IDs for selects

            // Initialize the first select3
            $(".select3").select2();

            // Add More Education
            $("#add-edu-btn").click(function() {
                let clone = $(".education-row:first").clone(false, false); // clone without events

                // reset values
                clone.find("input").val("");
                clone.find("select").val("");

                // find select
                let newSelect = clone.find("select.select3");

                // remove any cloned select2 container if present
                clone.find(".select2").remove();
                newSelect.show(); // make sure <select> is visible

                // assign unique id
                newSelect.attr("id", "qualification_type_" + eduIndex);
                eduIndex++;

                // re-init select2
                newSelect.select2();

                // show delete button
                clone.find(".staff_edu_del").show();

                // append to wrapper
                $("#education-wrapper").append(clone);
            });

            // Delete Education Row
            $(document).on("click", ".staff_edu_del", function() {
                $(this).closest(".education-row").remove();
            });
        });
    </script>

    <script>
        login_func()

        function login_func() {

            var login_access = document.getElementById("login_access");
            if (login_access.checked) {
                $('#user_name_label').html('Username');
                $('.login_fields').show();
            } else {
                $('#user_name_label').html('Login Credentials');
                $('.login_fields').hide();
            }
        }
    </script>

    <script>
        $(document).ready(function() {
            // Hide wrapper by default
            $("#work-exp-wrapper").hide();
            $("#add-work-btn").hide();
            $(".work-exp-div").hide();

            // Handle type change
            $("#work_type").change(function() {
                if ($(this).val() === "2") {
                    // Experience selected
                    $("#work-exp-wrapper").show();
                    $("#add-work-btn").show();
                    $(".work-exp-div").show();
                } else {
                    // Fresher selected
                    $("#work-exp-wrapper").hide();
                    $("#add-work-btn").hide();
                    $(".work-exp-div").hide();

                    // Reset rows to only the first one (clean form)
                    $("#work-exp-wrapper .work-exp-row:not(:first)").remove();
                    $("#work-exp-wrapper")
                        .find("input")
                        .val(""); // clear inputs
                    $("#work-exp-wrapper .staff_work_del").hide(); // hide delete button in first row
                }
            });

            // Add More Work Experience
            $("#add-work-btn").click(function() {
                let clone = $(".work-exp-row:first").clone(false, false);

                // clear values
                clone.find("input").val("");

                // show delete button
                clone.find(".staff_work_del").show();

                // append
                $("#work-exp-wrapper").append(clone);

                // re-init datepicker if needed
                clone.find(".common_datepicker").datepicker({
                    format: "yyyy-mm-dd",
                    autoclose: true,
                    todayHighlight: true
                });
            });

            // Delete Work Row
            $(document).on("click", ".staff_work_del", function() {
                $(this).closest(".work-exp-row").remove();
            });

            // Initialize first datepickers
            $(".common_datepicker").datepicker({
                format: "yyyy-mm-dd",
                autoclose: true,
                todayHighlight: true
            });
        });
    </script>

  <script>
   $(document).ready(function() {
    let eduIndex = 1; // unique IDs for selects

    // Initialize Select2 for the first row only
    $("#doc_type_0").select2();

    // Add More Education
    $("#add-doc-btn").click(function() {
        let clone = $(".document-row:first").clone(); // clone without events

        // Reset input/select values
        clone.find("input").val("");
        clone.find("select").val("");

        // Remove old Select2 container from clone only
        clone.find(".select2").remove();
        let newSelect = clone.find("select.select3");

        // Assign unique ID to cloned select
        newSelect.attr("id", "doc_type_" + eduIndex);

        // Re-initialize Select2 for cloned select
        newSelect.select2();

        // Show delete button for clone
        clone.find(".staff_doc_del").show();

        // Append clone to wrapper
        $("#document-wrapper").append(clone);

        eduIndex++;
    });

    // Delete Education Row
    $(document).on("click", ".staff_doc_del", function() {
        $(this).closest(".document-row").remove();
    });
});

  </script>


<script>
  $(document).ready(function() {
    let courseIndex = 1;

    // Initialize Select2 for first dropdown
    $(".course-select").select2();

    // Toggle visibility based on Yes/No selection
    $('input[name="is_Course"]').on('change', function () {
      if ($(this).val() === 'yes') {
        $('#courseAttachmentHeader, #courseDocumentWrapper, #addCourseBtnWrapper').removeClass('d-none');
      } else {
        $('#courseAttachmentHeader, #courseDocumentWrapper, #addCourseBtnWrapper').addClass('d-none');
      }
    });

    // Add new course row
    $("#add-course-btn").click(function() {
      let clone = $(".course-document-row:first").clone(false, false);
      clone.find("input, select").val("");

      // remove any existing Select2 DOM
      clone.find(".select2").remove();
      let newSelect = clone.find("select.course-select");
      newSelect.attr("id", "course_doc_type_" + courseIndex);
      newSelect.show();
      newSelect.select2();
      courseIndex++;

      // show delete button
      clone.find(".course_doc_del").show();

      // append to wrapper
      $("#courseDocumentWrapper").append(clone);
    });

    // Delete course row
    $(document).on("click", ".course_doc_del", function() {
      $(this).closest(".course-document-row").remove();
    });
  });
</script>




    {{-- Married  --}}
    <script>
        $(document).ready(function() {
            $('#marital_status').on('change', function() {
                if ($(this).val() === '1') {
                    $('.spouse-field').removeClass('d-none');
                } else {
                    $('.spouse-field').addClass('d-none');
                }
            });
        });
    </script>

    <script>
  document.addEventListener("DOMContentLoaded", function () {
    const yesRadio = document.getElementById("childrenYes");
    const noRadio = document.getElementById("childrenNo");
    const childrenSections = document.querySelectorAll(".children-section");

    function toggleChildrenFields() {
      childrenSections.forEach(section => {
        if (yesRadio.checked) {
          section.classList.remove("d-none");
        } else {
          section.classList.add("d-none");
        }
      });
    }

    yesRadio.addEventListener("change", toggleChildrenFields);
    noRadio.addEventListener("change", toggleChildrenFields);
  });
</script>

    <script>
        $(document).ready(function() {
            $('input[name="is_working"]').on('change', function() {
                if ($(this).val() === 'yes') {
                    $('.working-fields').removeClass('d-none');
                } else {
                    $('.working-fields').addClass('d-none');
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            $('input[name="has_Siblings"]').on('change', function() {
                if ($(this).val() === 'yes') {
                    $('#siblingsDescription').removeClass('d-none');
                } else {
                    $('#siblingsDescription').addClass('d-none');
                }
            });
        });
    </script>

   <script>
    $(document).ready(function() {
        $('#work_type').on('change', function() {
            if ($(this).val() === '2') {
                $('.shiftedCompanyField').removeClass('d-none');
            } else {
                $('.shiftedCompanyField').addClass('d-none');
            }
        });
    });
    </script>


    <script>
      $(document).ready(function() {
        $('#Know_about_us').on('change', function() {
          const val = $(this).val();
          if (val === '5' || val === '6' || val === '7') {
            $('#knowDetails').removeClass('d-none');
          } else {
            $('#knowDetails').addClass('d-none');
          }
        });
      });
    </script>

    <script>
      $(document).ready(function() {
      $('input[name="is_MinimumWork"]').on('change', function() {
        if ($('#MinimumWorkNo').is(':checked')) {
          $('#minimumWorkReason').removeClass('d-none');
        } else {
          $('#minimumWorkReason').addClass('d-none');
        }
      });
    });

    </script>


<script>
  $(document).ready(function() {
  $('input[name="is_OriginalCertificate"]').on('change', function() {
    if ($('#OriginalCertificateNo').is(':checked')) {
      $('#originalCertificateReason').removeClass('d-none');
    } else {
      $('#originalCertificateReason').addClass('d-none');
    }
  });
});

</script>

<script>
  $(document).ready(function() {
  $('input[name="is_Travel"]').on('change', function() {
    if ($('#TravelNo').is(':checked')) {
      $('#travelReason').removeClass('d-none');
    } else {
      $('#travelReason').addClass('d-none');
    }
  });
});

</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
  function updateDuration() {
    const yes = document.getElementById('attendedElysiumYes');
    const dur = document.getElementById('attendedElysiumDuration');
    if (yes && yes.checked) dur.classList.remove('d-none'); else dur.classList.add('d-none');
  }

  // listen for changes (works even if radios are added later)
  document.addEventListener('change', function (e) {
    if (e.target && e.target.name === 'attended_elysium') updateDuration();
  });

  // initial
  updateDuration();
});
</script>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const joiningImmediate = document.getElementById("joiningImmediate");
    const joiningNotice = document.getElementById("joiningNotice");
    const noticeField = document.querySelector(".notice-field");
    const immediateField = document.querySelector(".immediate-field");

    function toggleJoiningFields() {
      if (joiningImmediate.checked) {
        immediateField.classList.remove("d-none");
        noticeField.classList.add("d-none");
      } else if (joiningNotice.checked) {
        noticeField.classList.remove("d-none");
        immediateField.classList.add("d-none");
      } else {
        // Hide both by default
        noticeField.classList.add("d-none");
        immediateField.classList.add("d-none");
      }
    }

    // Add listeners
    joiningImmediate.addEventListener("change", toggleJoiningFields);
    joiningNotice.addEventListener("change", toggleJoiningFields);
  });
</script>

<script>
$(document).ready(function() {
    let altMobileIndex = 0; // start from 0 for default

    function updateAltMobileLabels() {
        $("#altmobile-wrapper .altmobile-row").each(function(index) {
            let label = $(this).find("label");
            if(index === 0){
                label.text("Alternate Mobile Number"); // default
            } else {
                label.text("Alternate Mobile Number " + index);
            }
        });
    }

    // Add More Alternate Mobile
    $("#add-altmobile-btn").click(function() {
        let clone = $(".altmobile-row:first").clone(); // clone first row

        // Reset input value
        clone.find("input").val("");

        // Show delete button for clone
        clone.find(".altmobile_del").show();

        // Append clone to wrapper
        $("#altmobile-wrapper").append(clone);

        // Update all labels
        updateAltMobileLabels();
    });

    // Delete Alternate Mobile Row
    $(document).on("click", ".altmobile_del", function() {
        $(this).closest(".altmobile-row").remove();

        // Update labels after deletion
        updateAltMobileLabels();
    });
});


</script>




@endsection
