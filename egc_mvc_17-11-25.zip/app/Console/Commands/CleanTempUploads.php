<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;

class CleanTempUploads extends Command
{
    /**
     * The name and signature of the console command.
     *
     * You can run it with: php artisan clean:temp-uploads
     */
    protected $signature = 'clean:temp-uploads';

    /**
     * The console command description.
     */
    protected $description = 'Deletes temporary uploaded files older than 24 hours from /public/staff_attachments/temp/';

    /**
     * Execute the console command.
     */
    // public function handle()
    // {
    //     $tempPath = public_path('staff_attachments/temp');

    //     if (!File::exists($tempPath)) {
    //         $this->info('No temp folder found.');
    //         return Command::SUCCESS;
    //     }

    //     $files = File::allFiles($tempPath);
    //     $deletedCount = 0;

    //     foreach ($files as $file) {
    //         $lastModified = $file->getMTime();
    //         $ageInHours = (time() - $lastModified) / 3600;

    //         // Delete files older than 24 hours
    //         if ($ageInHours > 0.05) {
    //             File::delete($file->getRealPath());
    //             $deletedCount++;
    //         }
    //     }

    //     $this->info("✅ Deleted {$deletedCount} old temporary file(s).");
    //     return Command::SUCCESS;
    // }

    public function handle()
    {
        $tempPath = public_path('staff_attachments/temp');

        if (!File::exists($tempPath)) {
            $this->info('No temp folder found.');
            return Command::SUCCESS;
        }

        $files = File::allFiles($tempPath);
        $deletedCount = 0;

        foreach ($files as $file) {
            $lastModified = $file->getMTime();
            $ageInMinutes = (time() - $lastModified) / 60;

            // Delete files older than 1 minute
            if ($ageInMinutes > 1) {
                File::delete($file->getRealPath());
                $deletedCount++;
            }
        }

        $this->info("✅ Deleted {$deletedCount} old temporary file(s).");
        return Command::SUCCESS;
    }
}
