@php
  $currentRouteName = Route::currentRouteName();
  $configData = \App\Helpers\Helpers::appClasses();
  $activeClass = '';

  // Default active class depending on layout type
  $active = $configData['layout'] === 'vertical' ? 'active open' : 'active';

  // Determine active menu based on slug
  if ($currentRouteName === ($menu->slug ?? '')) {
      $activeClass = 'active';
  } elseif (isset($menu->submenu)) {
      // Recursively check submenus for match
      foreach ($menu->submenu as $submenu) {
          if (isset($submenu->slug) && str_starts_with($currentRouteName, $submenu->slug)) {
              $activeClass = $active;
              break;
          }
      }
  }
  
  $hasSubmenu = isset($menu->submenu);
@endphp

<li class="menu-item {{ $activeClass }}">
  <a href="{{ isset($menu->url) ? url($menu->url) : 'javascript:void(0);' }}"
     class="{{ $hasSubmenu ? 'menu-link menu-toggle' : 'menu-link' }}"
     @if(isset($menu->target) && !empty($menu->target)) target="_blank" @endif>
    
    {{-- ICON --}}
    @isset($menu->icon)
      <i class="{{ $menu->icon }}"></i>
    @endisset

    {{-- MENU NAME --}}
    <div class="fs-7 fw-medium d-flex align-items-center">
      {{ __($menu->name ?? '') }}
    </div>

    {{-- BADGE --}}
    @isset($menu->badge)
      <div class="badge bg-{{ $menu->badge[0] }} rounded-pill ms-auto">
        {{ $menu->badge[1] }}
      </div>
    @endisset
  </a>

  {{-- SUBMENU --}}
  @if ($hasSubmenu)
    <ul class="menu-sub">
      @foreach ($menu->submenu as $submenu)
        @include('layouts.sections.menu.menu_item', ['menu' => $submenu])
      @endforeach
    </ul>
  @endif
</li>
