<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

class Authenticate extends Middleware
{
    /**
     * Get the path the user should be redirected to when they are not authenticated.
     */
    // protected function redirectTo(Request $request): ?string
    // {
    //     // return $request->expectsJson() ? null : route('auth-login-basic');
    //     if (!Auth::check()) {
    //         return '/auth/login-basic'; // Redirect to the login page if the user is not authenticated
    //     } else {
    //         return '/settings-general_settings'; // Redirect to the settings page if the user is authenticated
    //     }
    // }
     protected function redirectTo(Request $request): ?string
    {

        // return $request;
        if (!$request->expectsJson()) {
            // Default redirect for regular users
            return route('login');
        }
        // return null;
    }
}