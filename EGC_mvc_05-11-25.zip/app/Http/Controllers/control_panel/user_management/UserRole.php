<?php

namespace App\Http\Controllers\control_panel\user_management;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserRoleModel;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\UserRoleExport;
use App\Models\CompanyModel;
use App\Models\ManageEntityModel;
use Illuminate\Support\Facades\Http;
use Maatwebsite\Excel\Facades\Excel;

class UserRole extends Controller
{

  public function index()
  {
      $userRole = UserRoleModel::where('egc_user_role.status', '!=', 2)
        ->leftJoin('egc_user_role as parent_role', 'egc_user_role.user_role_id', '=', 'parent_role.sno')
        ->select(
          'egc_user_role.sno',
          'egc_user_role.role_id',
          'egc_user_role.role_name',
          'egc_user_role.map_under',
          'egc_user_role.user_role_id',
          'egc_user_role.status',
          'parent_role.role_name as parent_role_name'
        )
        ->orderBy('egc_user_role.sno', 'desc')
        ->get();
      $pageConfigs = ['myLayout' => 'default'];
      return view('content.control_panel.user_management.user_role.user_role_list', compact('userRole', 'pageConfigs'));
      // return view('content.user_management.user_role.list');
  }


  public function ExportExcel()
  {
    return Excel::download(new UserRoleExport, 'user-role-export.xlsx'); // Adjust filename and extension as needed
  }
  public function List()
  {
    $user = UserRoleModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'role_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {


      $role_name          = $request->role_name;
      $map_under = $request->has('map_under') ? 1 : 0;
      $user_role_id       = $request->user_role_id;
      // $user_id            = $request->user()->id;
      $entity_id            = 0;
      $user_id            = $request->user()->user_id;
      $chk = UserRoleModel::where('role_name', ucwords($role_name))->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been  already created!'
        ]);
        return redirect()->back();
      } else {
        $category_check = UserRoleModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();


        if (!$category_check) {

          $year = substr(date("y"), -2);
          $role_id = "UR-0001/" . $year;
        } else {

          $data = $category_check->role_id;
          $slice = explode("/", $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf("UR-%04d", $next_number);

          $year = substr(date("y"), -2);
          $role_id = $request . '/' . $year;
        }


        $add_user = new UserRoleModel();
        $add_user->role_id           = $role_id;
        $add_user->role_name         = Ucfirst($role_name);
        $add_user->map_under         = $map_under;
        $add_user->user_role_id      = $user_role_id;
        $add_user->created_by        = $user_id;
        $add_user->updated_by        = $user_id;

        $add_user->save();

        if ($add_user) {
            // Flash a success message
            session()->flash('toastr', [
                'type' => 'success',
                'message' => 'User Role added Successfully!'
            ]);
        
            // Store role_id and current time in the session
            session([
                'role_id' => $add_user->sno,
                'role_id_segc_time' => now(),
            ]);
        
            // Redirect to the users manage add page
            return redirect()->back();
        } else {
            // Flash an error message
            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Could not add the User Role!'
            ]);
        
            // Redirect back to the previous page
            return redirect()->back();
        }

      }
      
    }
  }

  public function Edit($id)
  {
    $role = UserRoleModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }



public function Update($id, Request $request)
{
    $validator = Validator::make($request->all(), [
        'role_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $role_name    = $request->role_name;
    $map_under    = $request->map_under;
    $user_role_id = $request->user_role_id;

    $upd_user = UserRoleModel::where('sno', $id)->first();

    if (!$upd_user) {
        return response()->json([
            'status'    => 404,
            'message'   => 'User role not found',
            'error_msg' => null,
            'data'      => null,
        ], 404);
    }

    $chk = UserRoleModel::where('role_name', ucwords($role_name))
                        ->where('status', '!=', 2)
                        ->first();

    if ($chk && $chk->sno != $id) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has already been assigned!',
            'data'      => null,
        ], 200);
    }

    $upd_user->role_name    = ucwords($role_name);
    $upd_user->map_under    = $map_under;
    $upd_user->user_role_id = $user_role_id;
    
    if ($upd_user->save()) {
        return response()->json([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    } else {
        return response()->json([
            'status'    => 500,
            'message'   => 'Failed to update user role',
            'error_msg' => 'Something went wrong, please try again',
            'data'      => null,
        ], 500);
    }
}

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }


  public function businessIndex()
  {
      $userRole = UserRoleModel::where('egc_user_role.status', '!=', 2)
        ->leftJoin('egc_user_role as parent_role', 'egc_user_role.user_role_id', '=', 'parent_role.sno')
        ->select(
          'egc_user_role.sno',
          'egc_user_role.role_id',
          'egc_user_role.role_name',
          'egc_user_role.map_under',
          'egc_user_role.user_role_id',
          'egc_user_role.status',
          'parent_role.role_name as parent_role_name'
        )
        ->orderBy('egc_user_role.sno', 'desc')
        ->get();
      $pageConfigs = ['myLayout' => 'default'];
      $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
      return view('content.control_panel.user_management.user_role.business_user_role', compact('userRole','company_list', 'pageConfigs'));
      // return view('content.user_management.user_role.list');
  }


  public function businessList()
  {
    $user = UserRoleModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $user
    ], 200);
  }

 public function businessAdd(Request $request)
{
    // 🧩 Step 1: Validate input
    $validator = Validator::make($request->all(), [
        'company_id' => 'required|integer',
        'entity_id'  => 'required|integer'
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $company_id = $request->company_id;
    $entity_id  = $request->entity_id;

    // 🧩 Step 2: Get entity base URL
    $entity_url = ManageEntityModel::where('sno', $entity_id)->value('entity_base_url');

    if (!$entity_url) {
        return response()->json([
            'status'  => 404,
            'message' => 'Entity URL not found for the given entity ID.',
        ], 200);
    }

    // 🧩 Step 3: Call external API using Http facade
    $verify_key = 'egcsecret2030datagetapierp';
    $api_url = rtrim($entity_url, '/') . '/api/get_user_role_egc';

    try {
        $response = Http::get($api_url, ['auth_key' => $verify_key]);

        if (!$response->successful()) {
            return response()->json([
                'status'  => 500,
                'message' => 'Failed to fetch user roles from entity API.',
                'error'   => $response->body(),
            ], 200);
        }

        $userRoleData = $response->json()['data'] ?? [];

        if (empty($userRoleData)) {
            return response()->json([
                'status'  => 404,
                'message' => 'No user roles found in API response.',
            ], 200);
        }

        // 🧩 Step 4: Loop and insert roles
        foreach ($userRoleData as $userRole) {
            $role_name = ucfirst($userRole['role_name'] ?? null);
            if (!$role_name) continue;

            $company_type = 2;
            $map_under = 0;
            $erp_role_id = $userRole['sno'] ?? 0;
            $erp_under_role_id = $userRole['user_role_id'] ?? 0;
            $user_id = $request->user()->user_id ?? null;

            // 🔍 Check if role already exists
            $chk = UserRoleModel::where('role_name', $role_name)
                ->where('entity_id', $entity_id)
                ->where('status', '!=', 2)
                ->first();

            if ($chk) continue; // skip duplicates

            // 🧩 Step 5: Generate next role_id
            $last = UserRoleModel::where('status', '!=', 2)
                ->orderBy('sno', 'desc')
                ->first();

            if (!$last) {
                $year = substr(date("y"), -2);
                $role_id = "UR-0001/{$year}";
            } else {
                $data = $last->role_id;
                $slice = explode("/", $data);
                $result = preg_replace('/[^0-9]/', '', $slice[0]);
                $next_number = (int)$result + 1;
                $prefix = sprintf("UR-%04d", $next_number);
                $year = substr(date("y"), -2);
                $role_id = "{$prefix}/{$year}";
            }

            // 🧩 Step 6: Save to DB
            $add_user = new UserRoleModel();
            $add_user->role_id          = $role_id;
            $add_user->company_type     = $company_type;
            $add_user->company_id       = $company_id;
            $add_user->entity_id        = $entity_id;
            $add_user->erp_role_id      = $erp_role_id;
            $add_user->erp_under_role_id = $erp_under_role_id;
            $add_user->role_name        = $role_name;
            $add_user->map_under        = $map_under;
            $add_user->user_role_id     = 0;
            $add_user->created_by       = 1;
            $add_user->updated_by       = 1;
            $add_user->save();
        }

        return response()->json([
            'status'  => 200,
            'message' => 'Business roles imported successfully.',
        ]);

    } catch (\Throwable $e) {
        // \Log::error('BusinessAdd API Error: ' . $e->getMessage());
        return response()->json([
            'status'  => 500,
            'message' => 'Something went wrong while fetching user roles.',
            'error'   => $e->getMessage(),
        ], 200);
    }
}


  public function businessEdit($id)
  {
    $role = UserRoleModel::where('sno', $id)->first();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $role
    ], 200);
  }



public function businessUpdate($id, Request $request)
{
    $validator = Validator::make($request->all(), [
        'role_name' => 'required|max:255',
    ]);

    if ($validator->fails()) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Incorrect format input fields',
            'error_msg' => $validator->messages()->get('*'),
            'data'      => null,
        ], 200);
    }

    $role_name    = $request->role_name;
    $map_under    = $request->map_under;
    $user_role_id = $request->user_role_id;

    $upd_user = UserRoleModel::where('sno', $id)->first();

    if (!$upd_user) {
        return response()->json([
            'status'    => 404,
            'message'   => 'User role not found',
            'error_msg' => null,
            'data'      => null,
        ], 404);
    }

    $chk = UserRoleModel::where('role_name', ucwords($role_name))
                        ->where('status', '!=', 2)
                        ->first();

    if ($chk && $chk->sno != $id) {
        return response()->json([
            'status'    => 401,
            'message'   => 'Error',
            'error_msg' => 'Name has already been assigned!',
            'data'      => null,
        ], 200);
    }

    $upd_user->role_name    = ucwords($role_name);
    $upd_user->map_under    = $map_under;
    $upd_user->user_role_id = $user_role_id;
    
    if ($upd_user->save()) {
        return response()->json([
            'status'    => 200,
            'message'   => 'Successfully Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    } else {
        return response()->json([
            'status'    => 500,
            'message'   => 'Failed to update user role',
            'error_msg' => 'Something went wrong, please try again',
            'data'      => null,
        ], 500);
    }
}

  public function businessDelete($id)
  {
    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function businessStatus($id, Request $request)
  {

    $upd_CourseCategoryModel =  UserRoleModel::where('sno', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();


    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
  

}
