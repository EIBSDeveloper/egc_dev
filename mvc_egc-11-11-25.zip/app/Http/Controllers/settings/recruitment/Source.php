<?php

namespace App\Http\Controllers\settings\recruitment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class Source extends Controller
{
    public function index()
    {
        return view(
            'content.settings.recruitment.source.source_list');
    }

}
