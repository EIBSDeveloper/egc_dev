<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class FinancialYear extends Controller
{
    protected static $branch_id = 1;

    public function index()
    {
        return view(
            'content.settings.common.financial_year.financial_year_list');
    }



    public function Add(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'financial_name' => 'required|max:255'
        ]);
        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $financial_name = $request->financial_name;
            $financial_months = $request->month_dropdown;
            $financial_desc = $request->financial_desc;
            $branch_id = $request->user()->branch_id;
            $user_id = auth()->user()->user_id;
            $chk = FinancialYearModel::where('financial_year_name', ucwords($financial_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

            if ($chk) {

                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Financial Year Name is exist!'
                ]);
                return redirect()->back();
            } else {
                $category_check = FinancialYearModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

                if (!$category_check) {

                    $year = substr(date('y'), -2);
                    $financial_year_id = 'FY-0001/' . $year;
                } else {
                    $data = $category_check->financial_year_id;
                    $slice = explode('/', $data);
                    $result = preg_replace('/[^0-9]/', '', $slice[0]);
                    $next_number = (int) $result + 1;
                    $request = sprintf('FY-%04d', $next_number);
                    $year = substr(date('y'), -2);
                    $financial_year_id = $request . '/' . $year;
                }

                $add_department = new FinancialYearModel();
                $add_department->financial_year_id = $financial_year_id;
                $add_department->financial_year_name = Ucfirst($financial_name);
                $add_department->financial_month = json_encode($financial_months);
                $add_department->financial_year_desc = $financial_desc;

                $add_department->updated_by = $user_id;
                // $add_department->branch_id = $branch_id;
                $add_department->branch_id         = self::$branch_id;
                $add_department->created_by        = $user_id;
                $add_department->updated_by        = $user_id;
                // dd($add_department);
                $add_department->save();

                if ($add_department) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Financial Year added Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not add the Financial Year!'
                    ]);
                }
            }
            return redirect()->back();
        }
    }



    public function Update(Request $request)
    {
        // return $request;
        $validator = Validator::make($request->all(), [
            'edit_financial_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {
            return response([
                'status' => 401,
                'message' => 'Incorrect format input feilds',
                'error_msg' => $validator->messages()->get('*'),
                'data' => null,
            ], 200);
        } else {

            $edit_financial_name = $request->edit_financial_name;
            $edit_month_dropdown = $request->edit_month_dropdown;
            $edit_financial_desc = $request->edit_financial_desc;
            $financial_year_sno = $request->financial_year_sno;
            $branch_id = $request->user()->branch_id;
            $user_id = auth()->user()->user_id;

            $upd_ReferralModel = FinancialYearModel::where('sno', $financial_year_sno)->first();

            $chk = FinancialYearModel::where('financial_year_name', ucwords($edit_financial_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $financial_year_sno)->where('status', '!=', 2)->first();

            if ($chk) {
                session()->flash('toastr', [
                    'type' => 'error',
                    'message' => 'Already Referral is exist!'
                ]);
                return redirect()->back();
            } else {

                $upd_ReferralModel->financial_year_name = Ucfirst($edit_financial_name);
                $upd_ReferralModel->financial_month = json_encode($edit_month_dropdown);
                $upd_ReferralModel->financial_year_desc = $edit_financial_desc;

                // $upd_ReferralModel->updated_by = $user_id;
                // $upd_ReferralModel->branch_id = $branch_id;
                $upd_ReferralModel->branch_id = self::$branch_id;
                $upd_ReferralModel->updated_by                 = $user_id;
                $upd_ReferralModel->update();
                // dd($upd_ReferralModel);

                if ($upd_ReferralModel) {
                    // If category added successfully, return success response and display Toastr message
                    session()->flash('toastr', [
                        'type' => 'success',
                        'message' => 'Financial Year Update Successfully!'
                    ]);
                } else {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Could not Update the Financial Year!'
                    ]);
                }
            }
        }
        return redirect()->back();
    }

    public function Delete($id)
    {
        $upd_DepartmentModel = FinancialYearModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = 2;
        $upd_DepartmentModel->Update();

        return response([
            'status' => 200,
            'message' => 'Successfully Deleted!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {
        // return $id;
        $upd_DepartmentModel = FinancialYearModel::where('sno', $id)->first();
        $upd_DepartmentModel->status = $request->input('status', 0);
        $upd_DepartmentModel->update();

        return response([
            'status' => 200,
            'message' => 'Successfully Status Updated!',
            'error_msg' => null,
            'data' => null,
        ], 200);
    }
}