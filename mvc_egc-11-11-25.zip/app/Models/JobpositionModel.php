<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobpositionModel extends Model
{
  use HasFactory;
  public $table = "egc_job_position";
  public $primaryKey = 'sno';

  protected $fillable = [
    'job_position_id',
    'job_position_name',
    'job_position_desc',
    'created_by',
    'created_at',
    'status',
  ];
}
