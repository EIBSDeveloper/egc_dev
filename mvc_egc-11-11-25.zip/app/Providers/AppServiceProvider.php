<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Vite;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\Auth;
use App\Models\GeneralSettingsModel;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Date;

class AppServiceProvider extends ServiceProvider
{
  /**
   * Register any application services.
   */
  public function register(): void
  {
    //
  }

  /**
   * Bootstrap any application services.
   */
  public function boot(): void
  {

            if (Schema::hasTable('egc_general_settings')) {
                $setting = GeneralSettingsModel::select('egc_countrytimezones.time_zone')
                    ->join('egc_countrytimezones', 'egc_countrytimezones.sno', '=', 'egc_general_settings.time_zone')
                    ->first();

                if ($setting && $setting->time_zone) {
                    Config::set('app.timezone', $setting->time_zone);
                    date_default_timezone_set($setting->time_zone);
                }
            }


    Vite::useStyleTagAttributes(function (?string $src, string $url, ?array $chunk, ?array $manifest) {
      if ($src !== null) {
        return [
          'class' => preg_match("/(resources\/assets\/vendor\/scss\/(rtl\/)?core)-?.*/i", $src) ? 'template-customizer-core-css' :
                    (preg_match("/(resources\/assets\/vendor\/scss\/(rtl\/)?theme)-?.*/i", $src) ? 'template-customizer-theme-css' : '')
        ];
      }
      return [];
    });
     
    Paginator::useBootstrapFive();
  }
}