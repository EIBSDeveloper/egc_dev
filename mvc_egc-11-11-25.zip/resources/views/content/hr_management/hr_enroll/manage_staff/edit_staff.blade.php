@extends('layouts/layoutMaster')

@section('title', 'Add Staff')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
    'resources/assets/vendor/libs/sortablejs/sortable.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
    @vite(['resources/assets/js/form_wizard_icons.js'])

@endsection

@section('content')



    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action mb-2">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Update Staff</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-account-group"></i> HR Management
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                HR Enroll
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Manage Staff
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div class="bs-stepper wizard-icons wizard-icons-example mt-2">
        <div class="bs-stepper-header">
            <div class="step" data-target="#staff_add">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/information.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Base Details</span>
                        </span>
                    </span>
                </button>
            </div>

            <div class="line"></div>
            <div class="step" data-target="#contact_add">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/phone-book.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Contact Details</span>
                        </span>
                    </span>
                </button>
            </div>

            <div class="line"></div>
            <div class="step" data-target="#work_add">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/online-chat.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Work Type</span>
                        </span>
                    </span>
                </button>
            </div>

            <div class="line"></div>
            <div class="step" data-target="#edu_add">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/education.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Education Details</span>
                        </span>
                    </span>
                </button>
            </div>
            <div class="line"></div>
            <div class="step" data-target="#Application_add">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/cv.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Application Details</span>
                        </span>
                    </span>
                </button>
            </div>

            <div class="line"></div>
            <div class="step" data-target="#checklist_add">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/checklist.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Staff Checklist</span>
                        </span>
                    </span>
                </button>
            </div>
            <div class="line"></div>
            <div class="step active" data-target="#orientation">
                <button type="button" class="step-trigger">
                    <img src="{{ asset('assets/egc_images/wizard_icon/calender.svg') }}"
                        style="width:50px; height:50px;" />
                    <span class="bs-stepper-label mt-2">
                        <span class="d-flex flex-column gap-1 ms-2">
                            <span class="bs-stepper-title">Orientation</span>
                        </span>
                    </span>
                </button>
            </div>
        </div>
        <div class="bs-stepper-content">
            <div id="staff_add" class="content ">
                <div class="row">
                    <div class="col-lg-12 mb-3 d-flex justify-content-end align-items-center">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_staff" id="staffYes" value="yes" checked/>
                          <label class="form-check-label" for="stafflYes">New Staff</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_staff" id="stafflNo" value="no" />
                          <label class="form-check-label" for="stafflNo">Existing Staff</label>
                        </div>
                    </div>


                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Personal Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <label class="text-black fs-6 fw-semibold mb-2">Staff Image</label>
                        <div class="d-flex align-items-sm-center justify-content-start">
                            <div class="d-flex align-items-start justify-content-center flex-column gap-2">
                                <img src="{{ asset('assets/egc_images/auth/user_3.png') }}" alt="Attachment"
                                    class="d-block w-px-120 h-px-120 rounded" id="staff_add"
                                    style="border: 2px solid #ab2b22;" />
                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                            </div>
                            <div class="button-wrapper">
                                <div class="d-flex align-items-start justify-content-start mt-2 mb-2">
                                    <label class="btn btn-sm btn-primary me-2" tabindex="0">
                                        <span class="fw-semibold text-white fs-6">Upload</span>
                                        <input type="file" name='staff_add_icon' id="staff_add_icon"
                                            class="staff_add_cls" hidden accept="image/png, image/jpeg" />
                                    </label>
                                    <button type="button" class="btn btn-sm btn-outline-danger staff-add-reset">
                                        <span class="fw-semibold text-primary fs-6">Reset</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="staff_name" name='staff_name' value="Sesha"
                            placeholder="Enter Staff Name"
                            oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Staff Mobile No<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="mobile_no" name="mobile_no" maxlength="10"
                            oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                            placeholder="Enter Mobile No" onkeyup="mobile_chk(this.value)" />
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Gender<span class="text-danger">*</span></label>
                        <div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label" for="gender_male">
                                    <input class="form-check-input" type="radio" name="gender" id="gender_male"
                                        value="1" checked />
                                    Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label" for="gender_female">
                                    <input class="form-check-input" type="radio" name="gender" id="gender_female"
                                        value="2" />
                                    Female</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <label class="form-check-label" for="gender_others">
                                    <input class="form-check-input" type="radio" name="gender" id="gender_others"
                                        value="3" />
                                    Others</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Date of Birth<span
                                class="text-danger">*</span></label>
                        <div class="input-group input-group-merge">
                            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
                            <input type="text" id="staff_dob" name="dob" placeholder="Select Date"
                                class="form-control common_datepicker" value="04-Jan-2003" />
                        </div>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="email_id" name="email_id"
                            placeholder="Enter E-Mail ID" title="Please enter a valid email address"
                            oninput=" this.value = this.value.toLowerCase();"  value="sesha123@gmail.com"/>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Father Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Father Name" value="Saravanen"/>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Father Occupation<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Father Occupation" value="Bank Manger"/>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Mother Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Mother Name" value="Nila"/>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Mother Occupation<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Mother Occupation" value="House Wife"/>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black fs-6 fw-semibold">Mother Tongue<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Mother Tongue" value="Tamil"/>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Languages Known<span
                                class="text-danger">*</span></label>
                        <select id="Languages" name="Languages" class="select3 form-select" multiple>
                            <option value="">Select Languages</option>
                            <option value="1" selected>Tamil</option>
                            <option value="2" selected>English</option>
                            <option value="3">Japanese</option>
                        </select>
                    </div>



                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Marital Status<span
                                class="text-danger">*</span></label>
                        <select id="marital_status" name="marital_status" class="select3 form-select">
                            <option value="">Select Marital Status</option>
                            <option value="1"selected>Married</option>
                            <option value="2">Unmarried</option>
                        </select>
                    </div>

                    <div class="col-lg-4 mb-3 spouse-field">
                        <label class="text-black fs-6 fw-semibold">Spouse Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Name"  value="Riya"/>
                    </div>


                    <div class="col-lg-4 mb-3 spouse-field">
                        <label class="text-black mb-1 fs-6 fw-semibold">Spouse Working ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_working" id="workingYes"
                                    value="yes" checked/>
                                <label class="form-check-label" for="workingYes" >Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="is_working" id="workingNo"
                                    value="no" />
                                <label class="form-check-label" for="workingNo" >No</label>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-4 mb-3 working-fields">
                        <label class="text-black fs-6 fw-semibold">Spouse Designation<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Designation" value="Developer"/>
                    </div>

                    <div class="col-lg-4 mb-3 working-fields">
                        <label class="text-black fs-6 fw-semibold">Spouse Company Name<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Company Name" value="TCS"/>
                    </div>

                    <div class="col-lg-4 mb-3 working-fields ">
                        <label class="text-black fs-6 fw-semibold">Spouse Salary<span class="text-danger">*</span></label>
                        <input type="text" class="form-control" placeholder="Enter Spouse Salary" value="30,000"/>
                    </div>


                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Children ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_children" id="childrenYes"
                                    value="yes" checked/>
                                <label class="form-check-label" for="childrenYes">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_children"id="childrenNo"
                                    value="no" checked/>
                                <label class="form-check-label" for="childrenNo">No</label>
                            </div>
                        </div>
                    </div>

                   <div class="col-lg-4 mb-3 children-section ">
                    <label class="text-black mb-1 fs-6 fw-semibold">Children Count<span class="text-danger">*</span></label>
                    <input type="text" class="form-control" placeholder="Enter Children Count" value="1">
                  </div>

                  <div class="col-lg-4 mb-3 children-section d-none">
                    <label class="text-black mb-1 fs-6 fw-semibold">Children Details</label>
                    <textarea class="form-control" rows="1" name="children_description"
                      placeholder="Enter Children Details">Studying 5th Standard</textarea>
                  </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Siblings ?<span
                                class="text-danger">*</span></label>
                        <div class="d-block">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_Siblings" id="SiblingsYes"
                                    value="yes" />
                                <label class="form-check-label" for="SiblingsYes">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="has_Siblings" id="SiblingsNo"
                                    value="no" checked/>
                                <label class="form-check-label" for="SiblingsNo" >No</label>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-4 mb-3 d-none" id="siblingsDescription">
                        <label class="text-black mb-1 fs-6 fw-semibold">Siblings Details<span class="text-danger">*</span></label>
                        <textarea class="form-control" rows="1" id="description" name="description" placeholder="Enter Siblings Details"></textarea>
                    </div>


                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Hobby </label>
                        <textarea class="form-control" rows="1" id="description" name="description" placeholder="Enter Hobby">-</textarea>
                    </div>



                    <div class="col-lg-8 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                        <textarea class="form-control" rows="1" id="description" name="description" placeholder="Enter Description">-</textarea>
                    </div>


                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Company Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="form-check form-check-inline mb-3">
                            <label class="form-check-label" for="management">
                                <input class="form-check-input" type="radio" name="company" id="management"
                                    value="1" checked />
                                Management
                            </label>
                        </div>
                        <div class="form-check form-check-inline mb-3">
                            <label class="form-check-label" for="business">
                                <input class="form-check-input" type="radio" name="company" id="business"
                                    value="2" />
                                Business
                            </label>
                        </div>
                        <div class="row">
                            <div class="col-lg-4 mb-3 business_div" style="display: none;">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                        class="text-danger">*</span></label>
                                <select id="company_name" name="company_name" class="select3 form-select">
                                    <option value="">Select Company Name</option>
                                    <option value="1" >Elysium Academy</option>
                                    <option value="2"selected>Elysium Technologies Pvt Ltd</option>
                                    <option value="3">Elysian Intelligence Business Solution</option>
                                    <option value="4">Elysian Embbed School</option>
                                    <option value="5">Elysium Communication</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3 business_div" style="display: none;">
                                <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                        class="text-danger">*</span></label>
                                <select id="entity_name" name="entity_name" class="select3 form-select">
                                    <option value="">Select Entity Name</option>
                                    <option value="1" >Elysium Academy</option>
                                    <option value="2">E-Pro</option>
                                    <option value="3">Click My Project</option>
                                    <option value="4">Elysian Intelligence Business Solution</option>
                                    <option value="5">SEO Business</option>
                                    <option value="6" selected>PhD iZone</option>
                                </select>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Department<span
                                        class="text-danger">*</span></label>
                                <div class="management_div" style="display: none;">
                                    <select id="" name="department" class="select3 form-select">
                                        <option value="">Select Department</option>
                                        <option value="1">HR Management</option>
                                        <option value="2"selected>Accounts & Finance</option>
                                        <option value="3">Corporate Admin</option>
                                        <option value="4">IT Support</option>
                                    </select>
                                </div>
                                <div class="business_div" style="display: none;">
                                    <select id="" name="department" class="select3 form-select">
                                        <option value="">Select Department</option>
                                        <option value="1">Management</option>
                                        <option value="2">Sales</option>
                                        <option value="3">Production</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Division<span
                                        class="text-danger">*</span></label>
                                <div class="management_div" style="display: none;">
                                    <select id="" name="division" class="select3 form-select">
                                        <option value="">Select Division</option>
                                        <option value="1">HR Recruitment</option>
                                        <option value="2">HR Operation</option>
                                        <option value="3"selected>HR Assessment</option>
                                        <option value="4">HR Training</option>
                                    </select>
                                </div>
                                <div class="business_div" style="display: none;">
                                    <select id="" name="division" class="select3 form-select">
                                        <option value="">Select Division</option>
                                        <option value="1">Internal Managment</option>
                                        <option value="2">Business Management</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span
                                        class="text-danger">*</span></label>
                                <div class="management_div" style="display: none;">
                                    <select id="" name="job_role" class="select3 form-select">
                                        <option value="">Select Job Role</option>
                                        <option value="1">HR Assistant</option>
                                        <option value="2">Recruitor</option>
                                        <option value="3">HR Executive</option>
                                        <option value="4"selected>HR Manager</option>
                                    </select>
                                </div>
                                <div class="business_div" style="display: none;">
                                    <select id="" name="job_role" class="select3 form-select">
                                        <option value="">Select Job Role</option>
                                        <option value="1">Sales Executives</option>
                                        <option value="2">Developer</option>
                                        <option value="3">CRE</option>
                                        <option value="4">Business Development Executives</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Designation Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pseudo Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="pseudo_name" name="pseudo_name"
                                    placeholder="Enter Pseudo Name"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" value="Ron"/>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Date of Joining<span
                                        class="text-danger">*</span></label>
                                <div class="input-group input-group-merge">
                                    <span class="input-group-text"><i
                                            class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                    <input type="text" id="staff_doj" name="doj" autocomplete="off"
                                        placeholder="Select Date" class="form-control common_datepicker"
                                        value="01-Nov-2025" />
                                </div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Basic Salary<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="basic_salary" name="basic_salary"
                                    placeholder="Enter Basic Salary" value="20,000"/>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Per Hour Cost<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="per_hr_cost" name="per_hr_cost"
                                    placeholder="Enter Per Hour Cost" value="500"/>
                            </div>
                            <div class="col-lg-8 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Skill Tag<span
                                        class="text-danger">*</span></label>
                                <div class="form-floating form-floating-outline">
                                    <input id="skill_tag" name="skill_tag" class="form-control h-auto skill_tag"
                                        row="1" placeholder="Select Product Tags" value="" value="Managing">
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" id="login_access"
                                        name="login_access" onclick="login_func();" value="1" checked/><span
                                        id="user_name_label" >Login
                                        Credentials
                                    </span><span class="text-danger login_fields">*</span>
                                </label>
                                <input type="text" class="form-control login_fields" id="loginuser_name"
                                    name="loginuser_name" placeholder="Enter User Name"
                                    onkeyup="user_name_chk(this.value)"  value="sesha"/>
                            </div>
                            <div class="col-lg-4 mb-3 login_fields">
                                <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                        class="text-danger">*</span></label>
                                <div class="form-password-toggle">
                                    <div class="input-group input-group-merge">
                                        <input type="password" class="form-control" id="loginpassword"
                                            name="loginpassword" placeholder="Enter Password"
                                            aria-describedby="password" value="seshas123" />
                                        <span class="input-group-text cursor-pointer"><i
                                                class="mdi mdi-eye-off-outline fs-4"></i></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" id="other_access"
                                        name="other_access" data-bs-toggle="modal"
                                        data-bs-target="#kt_modal_other_credentials" />Other Credentials
                                </label>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-12 d-flex justify-content-between mt-4">
                    <button class="btn btn-outline-secondary btn-prev" disabled> <i
                            class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button class="btn btn-primary btn-next"> <span
                            class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                            class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                </div>
            </div>
            <div id="contact_add" class="content">
                <div class="row">
                  <div class="col-lg-7 border-end">
                      <div class="row">
                        <div class="col-lg-6 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Contact Person<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="contact_person_name" name="contact_person_name"
                            placeholder="Enter Contact  Person Name"
                            oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" value="Sibi"/>
                      </div>
                      <div class="col-lg-6 mb-3">
                          <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile Number<span
                                  class="text-danger">*</span></label>
                          <input type="text" class="form-control me-2" maxlength="10"
                              oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                              id="contact_person_no" name="contact_person_no"
                              placeholder="Enter Contact  Person Mobile Number" value="8788519658"/>
                      </div>
                      <div class="col-lg-6 mb-3">
                          <label class="text-black mb-1 fs-6 fw-semibold">Permanent Address </label>
                          <textarea class="form-control" rows="1" id="address" name="Paddress" placeholder="Enter Permanent Address">18I KK Nagar Happy Street Madurai</textarea>
                      </div>
                      <div class="col-lg-6 mb-3">
                          <label class="text-black mb-1 fs-6 fw-semibold">Residential Address</label>
                          <textarea class="form-control" rows="1" id="address" name="Raddress" placeholder="Enter Residential Address">221I Gandhi Nagar Gandhi Street Madurai</textarea>
                      </div>
                      </div>
                  </div>
                  <div class="col-lg-5">
                    <div class="row">
                      <div class="col-lg-12">
                      <div id="altmobile-wrapper" class="scroll-y" style="max-height:300px;overflow-x:hidden;">
                            <div class="altmobile-row">
                                <div class="row">
                                    <div class="col-lg-9 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold altmobile-label">Alternate Mobile Number </label>
                                        <input type="text" name="alt_mobile[]" class="form-control altmobile_input" placeholder="Enter alternate mobile number" value="9978428631">
                                    </div>
                                    <div class="col-lg-3 d-flex align-items-end mb-3">
                                        <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 altmobile_del" style="display: none !important;">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-9 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold altmobile-label">Alternate Mobile Number 1</label>
                                        <input type="text" name="alt_mobile[]" class="form-control altmobile_input" placeholder="Enter alternate mobile number" value="7784592687">
                                    </div>
                                    <div class="col-lg-3 d-flex align-items-end mb-3">
                                        <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 altmobile_del">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-1 d-flex align-items-center justify-content-end">
                                <button type="button" class="btn btn-primary" id="add-altmobile-btn">
                                    <i class="mdi mdi-plus me-1"></i>Add More
                                </button>
                            </div>
                        </div>
                    </div>
                    </div>
                  </div>
                  <div class="col-12 d-flex justify-content-between mt-4">
                      <button class="btn btn-outline-secondary btn-prev"> <i
                              class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                          <span class="align-middle d-sm-inline-block d-none">Previous</span>
                      </button>
                      <button class="btn btn-primary btn-next"> <span
                              class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                              class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                  </div>
                </div>
            </div>
            <div id="work_add" class="content">
                <div class="row">
                  <div class="col-lg-12 mb-3">
                      <label class="fs-5 text-primary fw-bold">Work Type</label>
                  </div>
                  <div class="col-lg-12 mb-3">
                      <div class="row">
                           <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Type<span class="text-danger">*</span></label>
                                <select id="work_type" name="work_type" class="select3 form-select">
                                    <option value="">Select Type</option>
                                    <option value="1" selected>Fresher</option>
                                    <option value="2">Experience</option>
                                </select>
                            </div>

                            <div class="col-lg-4 mb-3 d-none shiftedCompanyField">
                                <label class="text-black fs-6 mb-1 fw-semibold">Shifted Company Count<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Shifted Company Count"/>
                            </div>

                            <div class="col-lg-4 mb-3 d-none shiftedCompanyField">
                                <label class="text-black fs-6 mb-1 fw-semibold">Total Years Of Experience<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Total Years Of Experience"/>
                            </div>
                      </div>
                      <div id="work-exp-wrapper" class="scroll-y" style="max-height:300px;overflow-x:hidden;">
                          <div class="work-exp-row">
                              <div class="row">
                                  <div class="col-lg-12">
                                      <div class="row">
                                          <div class="col-lg-3 mb-3">
                                              <label class="text-black mb-1 fs-6 fw-semibold">Position<span
                                                      class="text-danger">*</span></label>
                                              <input type="text" class="form-control" name="position[]"
                                                  placeholder="Enter Position" />
                                          </div>
                                          <div class="col-lg-3 mb-3">
                                              <label class="text-black mb-1 fs-6 fw-semibold">Experience Years<span
                                                      class="text-danger">*</span></label>
                                              <input type="text" class="form-control" name="exp_yrs[]"
                                                  placeholder="Enter Experience Years" />
                                          </div>
                                          <div class="col-lg-3 mb-3">
                                              <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                                      class="text-danger">*</span></label>
                                              <input type="text" class="form-control" name="company_name[]"
                                                  placeholder="Enter Company Name" />
                                          </div>
                                          <div class="col-lg-3 mb-3">
                                              <label class="text-black mb-1 fs-6 fw-semibold">Salary<span
                                                      class="text-danger">*</span></label>
                                              <input type="text" class="form-control" name="salary[]"
                                                  placeholder="Enter Salary" />
                                          </div>
                                          <div class="col-lg-3 mb-3">
                                              <label class="text-black mb-1 fs-6 fw-semibold">Start Date<span
                                                      class="text-danger">*</span></label>
                                              <div class="input-group input-group-merge">
                                                  <span class="input-group-text"><i
                                                          class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                  <input type="text" id="work_st_date" name="work_st_date[]"
                                                      placeholder="Select Date" class="form-control common_datepicker"
                                                      value="" />
                                              </div>
                                          </div>
                                          <div class="col-lg-3 mb-3">
                                              <label class="text-black mb-1 fs-6 fw-semibold">End Date<span
                                                      class="text-danger">*</span></label>
                                              <div class="input-group input-group-merge">
                                                  <span class="input-group-text"><i
                                                          class="mdi mdi-calendar-month-outline fs-4"></i></span>
                                                  <input type="text" id="work_end_date" name="work_end_date[]"
                                                      placeholder="Select Date" class="form-control common_datepicker"
                                                      value="" />
                                              </div>
                                          </div>
                                          <div class="col-lg-1 d-flex align-items-end mb-3">
                                              <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 staff_work_del"
                                                  style="display: none !important;">
                                                  <i class="mdi mdi-delete fs-4"></i>
                                              </a>
                                          </div>
                                      </div>
                                  </div>
                              </div>
                              <hr>
                          </div>
                      </div>
                      <div class="row work-exp-div">
                          <div class="mb-1 d-flex align-items-center justify-content-end">
                              <button type="button" class="btn btn-primary" id="add-work-btn">
                                  <i class="mdi mdi-plus me-1"></i>Add More
                              </button>
                          </div>
                      </div>
                  </div>

                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Attachment Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                      <div id="document-wrapper" class=" scroll-y" style="max-height:300px;overflow-x:hidden;">
                          <div class="document-row">
                              <div class="row">
                                  <div class="col-lg-4">
                                      <label class="text-black mb-1 fs-6 fw-semibold">Document Type</label>
                                      <select id="doc_type_0" name="doc_type[]" class="select3 form-select">
                                          <option value="">Select Document Type</option>
                                          <option value="1">Aadhaar Card</option>
                                          <option value="2">Ration Card</option>
                                          <option value="2"selected>Resume</option>
                                      </select>
                                  </div>
                                  <div class="col-lg-6 mb-3">
                                      <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                                      <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                                          <div class="dz-message needsclick fs-6">
                                              <div class="text-center text-black me-3">Drop files here or click to upload
                                              </div>
                                          </div>
                                          <div class="fallback">
                                              <input type="file" name="attachment[]" multiple>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-lg-1 d-flex align-items-end mb-3">
                                      <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 staff_doc_del"
                                          style="display: none !important;">
                                          <i class="mdi mdi-delete fs-4"></i>
                                      </a>
                                  </div>
                              </div>

                              <div class="row">
                                  <div class="col-lg-4">
                                      <label class="text-black mb-1 fs-6 fw-semibold">Document Type</label>
                                      <select id="doc_type_0" name="doc_type[]" class="select3 form-select">
                                          <option value="">Select Document Type</option>
                                          <option value="1"selected>Aadhaar Card</option>
                                          <option value="2">Ration Card</option>
                                          <option value="2">Resume</option>
                                      </select>
                                  </div>
                                  <div class="col-lg-6 mb-3">
                                      <label class="text-black fs-6 fw-semibold mt-2">Attachment</label>
                                      <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                                          <div class="dz-message needsclick fs-6">
                                              <div class="text-center text-black me-3">Drop files here or click to upload
                                              </div>
                                          </div>
                                          <div class="fallback">
                                              <input type="file" name="attachment[]" multiple>
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-lg-1 d-flex align-items-end mb-3">
                                      <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 staff_doc_del"
                                         >
                                          <i class="mdi mdi-delete fs-4"></i>
                                      </a>
                                  </div>
                              </div>
                          </div>
                      </div>

                      <div class="row">
                          <div class="mb-1 d-flex align-items-center justify-content-end">
                              <button type="button" class="btn btn-primary"id="add-doc-btn">
                                  <i class="mdi mdi-plus me-1"></i>Add More
                              </button>
                          </div>
                      </div>
                   </div>

                  <div class="col-12 d-flex justify-content-between mt-4">
                      <button class="btn btn-outline-secondary btn-prev"> <i
                              class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                          <span class="align-middle d-sm-inline-block d-none">Previous</span>
                      </button>
                      <button class="btn btn-primary btn-next"> <span
                              class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                              class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                  </div>

                </div>
            </div>
            <div id="edu_add" class="content">
                <div class="row">

                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Any Course Completed ?<span class="text-danger">*</span></label>
                        <div class="d-block">
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="is_Course" id="CourseYes" value="yes" />
                            <label class="form-check-label" for="CourseYes">Yes</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="is_Course" id="CourseNo" value="no" checked/>
                            <label class="form-check-label" for="CourseNo">No</label>
                          </div>
                        </div>
                    </div>

                    <div class="col-lg-8 mb-3 d-none" id="courseAttachmentHeader">
                        <label class="text-black mb-1 fs-6 fw-semibold">Enter Course<span
                                class="text-danger">*</span></label>
                        <div class="form-floating form-floating-outline">
                            <input id="skill_tag" name="skill_tag" class="form-control h-auto skill_tag"
                                row="1" placeholder="Select Course Tags" value="">
                        </div>
                    </div>

                    <div class="col-lg-12 mb-3">
                        <label class="fs-5 text-primary fw-bold">Educational Details</label>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div id="education-wrapper" class=" scroll-y" style="max-height:300px;overflow-x:hidden;">
                            <div class="education-row">
                                <div class="row">
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Qualification Type<span
                                                class="text-danger">*</span></label>
                                        <select id="qualification_type_0" name="qualification_type[]"
                                            class="select3 form-select">
                                            <option value="">Select Qualification Type</option>
                                            <option value="1">Doctrate</option>
                                            <option value="2">M.Phil</option>
                                            <option value="3">Post Graduate</option>
                                            <option value="4" selected>Under Graduate</option>
                                            <option value="5">Diploma</option>
                                            <option value="6">HSC</option>
                                            <option value="7">SSLC</option>
                                        </select>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Degree<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="degree[]"
                                            placeholder="Enter Degree" value="Computer Science And Engineering"/>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Major<span
                                                class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="major[]"
                                            placeholder="Enter Major" value="B.E"/>
                                    </div>
                                    <div class="col-lg-4 mb-3">
                                        <label class="text-black mb-1 fs-6 fw-semibold">Institute / University
                                            Name<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="univ_name[]"
                                            placeholder="Enter Institute / University Name" value="SRM"/>
                                    </div>
                                    <div class="col-lg-1 d-flex align-items-end mb-3">
                                        <a href="javascript:;" class="btn btn-outline-danger px-1 py-2 staff_edu_del"
                                            style="display: none !important;">
                                            <i class="mdi mdi-delete fs-4"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="mb-1 d-flex align-items-center justify-content-end">
                                <button type="button" class="btn btn-primary" id="add-edu-btn">
                                    <i class="mdi mdi-plus me-1"></i>Add More
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 d-flex justify-content-between mt-4">
                    <button class="btn btn-outline-secondary btn-prev"> <i
                            class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button class="btn btn-primary btn-next"> <span
                            class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                            class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                </div>
            </div>
            <div id="Application_add" class="content">
                <div class="row">
                  <div class="col-lg-12 mb-3">
                     <label class="fs-5 text-primary fw-bold">Applied For </label>
                  </div>

                   <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Technical Position<span
                                class="text-danger">*</span></label>
                        <select id="Technical" name="Technical" class="select3 form-select" multiple>
                            <option value="">Select Technical Position</option>
                            <option value="1" selected>Java</option>
                            <option value="2">.Net</option>
                            <option value="3">Android</option>
                        </select>
                    </div>
                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Non Technical Position<span
                                class="text-danger">*</span></label>
                        <select id="NonTech" name="NonTech" class="select3 form-select" multiple>
                            <option value="">Select Non Technical Position</option>
                            <option value="1"selected>Marketing</option>
                            <option value="2">Sales</option>
                            <option value="3">Management</option>
                        </select>
                    </div>


                  <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Staff Source<span class="text-danger">*</span></label>
                    <select id="Know_about_us" name="Know_about_us" class="select3 form-select">
                      <option value="">Select </option>
                      <option value="1">Indeed</option>
                      <option value="2">Quikr</option>
                      <option value="3">Naukri</option>
                      <option value="4"selected>Linkedin</option>
                      <option value="5">Reference</option>
                      <option value="6">Occupation</option>
                      <option value="7">Consultancy</option>
                    </select>
                  </div>

                  <div class="col-lg-4 mb-3 d-none" id="knowDetails">
                    <label class="text-black mb-1 fs-6 fw-semibold">Details</label>
                    <textarea class="form-control" rows="1" placeholder="Enter Details"></textarea>
                  </div>

                  <div class="col-lg-4 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Interview Attened Company<span
                              class="text-danger">*</span></label>
                      <select id="Interviewed" name="Interviewed" class="select3 form-select">
                          <option value="">Select Interview Attened Company</option>
                          <option value="1">EGC</option>
                          <option value="2"selected>ETPL</option>
                          <option value="3">E-PRO</option>
                          <option value="4">PHDIZONE</option>
                          <option value="5">EAPL</option>
                          <option value="6">ECPL</option>
                          <option value="7">CMP</option>
                      </select>
                  </div>

                    <div class="col-lg-4 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">
                        Already Attended Interview In Elysium Group ?<span class="text-danger">*</span>
                      </label>
                      <div class="d-block">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio"  name="attended_elysium"   id="attendedElysiumYes"  value="yes" />
                          <label class="form-check-label" for="attendedElysiumYes">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="attended_elysium" id="attendedElysiumNo"  value="no" checked/>
                          <label class="form-check-label" for="attendedElysiumNo">No</label>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-4 mb-3  d-flex flex-column " id="attendedElysiumDuration">
                      <label class="text-black mb-1 fs-6 fw-semibold">Select Dates<span class="text-danger">*</span></label>
                      <input type="text" class="form-control multidates" placeholder="Select Dates & Time" />
                    </div>

                    <div class="col-lg-4 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Accepted To Work Minimum Of 2 years ?<span class="text-danger">*</span></label>
                      <div class="d-block">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_MinimumWork" id="MinimumWorkYes" value="yes" checked/>
                          <label class="form-check-label" for="MinimumWorkYes">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_MinimumWork" id="MinimumWorkNo" value="no" />
                          <label class="form-check-label" for="MinimumWorkNo">No</label>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-4 mb-3 d-none" id="minimumWorkReason">
                      <label class="text-black mb-1 fs-6 fw-semibold">Reason</label>
                      <textarea class="form-control" rows="1" placeholder="Enter Reason for less than 2 Yrs of Work"></textarea>
                    </div>

                   <div class="col-lg-4 mb-3">
                    <label class="text-black mb-1 fs-6 fw-semibold">Accepted To Submit Original Certificate ?<span class="text-danger">*</span></label>
                    <div class="d-block">
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="is_OriginalCertificate" id="OriginalCertificateYes" value="yes" checked/>
                        <label class="form-check-label" for="OriginalCertificateYes">Yes</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="is_OriginalCertificate" id="OriginalCertificateNo" value="no" />
                        <label class="form-check-label" for="OriginalCertificateNo">No</label>
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-4 mb-3 d-none" id="originalCertificateReason">
                    <label class="text-black mb-1 fs-6 fw-semibold">Reason</label>
                    <textarea class="form-control" rows="1" placeholder="Enter Reason for Not Submitting Certificate"></textarea>
                  </div>

                    <div class="col-lg-4 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Accepted To Travel For Official Purpose ?<span class="text-danger">*</span></label>
                      <div class="d-block">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_Travel" id="TravelYes" value="yes" checked/>
                          <label class="form-check-label" for="TravelYes">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_Travel" id="TravelNo" value="no" />
                          <label class="form-check-label" for="TravelNo">No</label>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-4 mb-3 d-none" id="travelReason">
                      <label class="text-black mb-1 fs-6 fw-semibold">Reason</label>
                      <textarea class="form-control" rows="1" placeholder="Enter Reason for Not Travelling"></textarea>
                    </div>


                    <div class="col-lg-4 mb-3">
                      <label class="text-black mb-1 fs-6 fw-semibold">Joining Status<span class="text-danger">*</span></label>
                      <div class="d-block">
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_joining" id="joiningImmediate" value="immediate" checked/>
                          <label class="form-check-label" for="joiningImmediate">Immediate Joining</label>
                        </div>
                        <div class="form-check form-check-inline">
                          <input class="form-check-input" type="radio" name="is_joining" id="joiningNotice" value="notice" />
                          <label class="form-check-label" for="joiningNotice">Notice Period</label>
                        </div>
                      </div>
                    </div>

                    <div class="col-lg-4 mb-3 joining-field notice-field d-none">
                      <label class="text-black mb-1 fs-6 fw-semibold">Notice Period<span class="text-danger">*</span></label>
                      <input type="text" id="notice" placeholder="Select Date" class="form-control common_datepicker" />
                    </div>

                    <div class="col-lg-4 mb-3 joining-field immediate-field ">
                      <label class="text-black mb-1 fs-6 fw-semibold">Immediate Joining<span class="text-danger">*</span></label>
                      <input type="text" id="immediate" placeholder="Select Date" class="form-control common_datepicker" value="18-Oct-2025"/>
                    </div>

                    <div class="col-lg-4 mb-3">
                        <label class="text-black mb-1 fs-6 fw-semibold">Expected Salary<span
                                class="text-danger">*</span></label>
                        <input type="text" class="form-control"  placeholder="Enter Expected Salary ( In Rupees )" value="13,000"/>
                    </div>

                </div>
                <div class="col-12 d-flex justify-content-between mt-4">
                    <button class="btn btn-outline-secondary btn-prev"> <i
                            class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                        <span class="align-middle d-sm-inline-block d-none">Previous</span>
                    </button>
                    <button class="btn btn-primary btn-next"> <span
                            class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                            class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                </div>
            </div>
            <div id="checklist_add" class="content">
                <div class="row">
                  <div class="col-lg-12 d-flex align-items-center justify-content-end">
                     <div class="form-check mb-2">
                        <input class="form-check-input" type="checkbox" id="selectAll" checked>
                        <label class="form-check-label fw-semibold" for="selectAll">
                            Select All
                        </label>
                    </div>
                  </div>
                  <div class="col-lg-12">
                      <div style="max-height: 300px; overflow-y: auto;">
                          <div class="form-check mb-3">
                              <input class="form-check-input checklist-item" type="checkbox" id="check1" checked>
                              <label class="form-check-label" for="check1">Educational certificates verified (Degree, Diploma, Transcripts), experience/resume checked (previous employment verification)</label>
                          </div>
                          <div class="form-check mb-3">
                              <input class="form-check-input checklist-item" type="checkbox" id="check2" checked>
                              <label class="form-check-label" for="check2">Identity proof verified (Aadhaar, Passport, Driving License), address proof verified (Ration Card, Utility Bill),</label>
                          </div>
                          <div class="form-check mb-3">
                              <input class="form-check-input checklist-item" type="checkbox" id="check3" checked>
                              <label class="form-check-label" for="check3">Official documents submitted (Joining Letter, Form 16)</label>
                          </div>
                          <div class="form-check mb-3">
                              <input class="form-check-input checklist-item" type="checkbox" id="check4" checked>
                              <label class="form-check-label" for="check4">and alternate contact/emergency details provided (alternate mobile number, emergency contact).</label>
                          </div>
                          <div class="form-check mb-3">
                              <input class="form-check-input checklist-item" type="checkbox" id="check5" checked>
                              <label class="form-check-label" for="check5">Verify identity proof, address proof, and educational certificates.</label>
                          </div>
                          <div class="form-check mb-3">
                              <input class="form-check-input checklist-item" type="checkbox" id="check6" checked>
                              <label class="form-check-label" for="check6">Check previous experience/resume, submission of official documents, and provide alternate/emergency contact details.</label>
                          </div>
                      </div>
                  </div>

                  <div class="col-12 d-flex justify-content-between mt-4">
                      <button class="btn btn-outline-secondary btn-prev"> <i
                              class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                          <span class="align-middle d-sm-inline-block d-none">Previous</span>
                      </button>
                      <button class="btn btn-primary btn-next"> <span
                              class="align-middle d-sm-inline-block d-none me-sm-1">Next</span> <i
                              class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                  </div>

                </div>
            </div>
             <div id="orientation" class="content active">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="accordion" id="pending-tasks">
                      <div class="accordion-item mb-3">
                        <h2 class="accordion-header" id="headingOne">
                          <button
                            type="button"
                            class="accordion-button bg-label-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordionOne"
                            aria-expanded="true"
                            aria-controls="accordionOne">
                            <label class="text-black fs-5 fw-semibold"> Staff Introduction</label>
                          </button>
                        </h2>

                        <div id="accordionOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                            <div class="row">
                                <div class="col-lg-12 mb-3">
                                    <label class="text-black fs-6 fw-semibold mt-2">Report</label>
                                    <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                                        <div class="dz-message needsclick fs-6">
                                            <div class="text-center text-black me-3 text">Drop files here or click to upload
                                            </div>
                                        </div>
                                        <div class="fallback">
                                            <input type="file" name="attachment[]" multiple>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-4 mb-3">
                                    <label class="text-black fs-6 mb-1 fw-semibold">Score<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="staff_name" name='staff_name'
                                        placeholder="Enter Score" value="-"/>
                                </div>



                                <div class="col-lg-4 mb-3">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                  <select name="department" class="select3 form-select">
                                    <option value="">Select Department</option>
                                    <option value="1" selected>HR</option>
                                    <option value="2">Sales</option>
                                  </select>
                                </div>


                                <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                                  <select name="jobrole" class="select3 form-select">
                                    <option value="">Select Job Role</option>
                                    <option value="1" selected>HR Management</option>
                                    <option value="2">Sales</option>
                                  </select>
                                </div>


                                <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                                  <select name="position" class="select3 form-select">
                                    <option value="">Select Staff Name</option>
                                    <option value="1" >Sesha</option>
                                    <option value="2"selected>Ram Kumar</option>
                                    <option value="3">Sibi Raj</option>
                                  </select>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-item mb-3">
                        <h2 class="accordion-header " id="headingTwo">
                          <button
                            type="button"
                            class="accordion-button collapsed bg-label-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordionTwo"
                            aria-expanded="false"
                            aria-controls="accordionTwo">
                            <label class="text-black fs-5 fw-semibold"> Company Introduction</label>
                          </button>
                        </h2>
                        <div
                          id="accordionTwo"
                          class="accordion-collapse collapse show"
                          aria-labelledby="headingTwo"
                          data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                          <div class="row">
                                <div class="col-lg-4 mb-3">
                                    <label class="text-black fs-6 mb-1 fw-semibold">Score<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="staff_name" name='staff_name'
                                        placeholder="Enter Score" value="-"/>
                                </div>


                                <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                                  <select name="department1" class="select3 form-select">
                                    <option value="">Select Department</option>
                                    <option value="1">HR</option>
                                    <option value="2"selected>Sales</option>
                                  </select>
                                </div>


                                 <div class="col-lg-4 mb-3 ">
                                  <label class="text-black mb-1 fs-6 fw-semibold">Job Role<span class="text-danger">*</span></label>
                                  <select name="jobrole1" class="select3 form-select">
                                    <option value="">Select Job Role</option>
                                    <option value="1">HR Management</option>
                                    <option value="2"selected>Sales Manager</option>
                                  </select>
                                </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="accordion-item mb-3">
                        <h2 class="accordion-header" id="headingThree">
                          <button
                            type="button"
                            class="accordion-button collapsed bg-label-warning"
                            data-bs-toggle="collapse"
                            data-bs-target="#accordionThree"
                            aria-expanded="false"
                            aria-controls="accordionThree">
                            <label class="text-black fs-5 fw-semibold"> Department Introduction</label>
                          </button>
                        </h2>
                        <div
                          id="accordionThree"
                          class="accordion-collapse collapse show"
                          aria-labelledby="headingThree"
                          data-bs-parent="#accordionExample">
                          <div class="accordion-body">
                           <div class="row">
                              <div class="col-lg-12 mb-3">
                                  <label class="text-black fs-6 fw-semibold mt-2">Report</label>
                                  <div class="dropzone needsclick dz-clickable" id="dropzone-multi_staff">
                                      <div class="dz-message needsclick fs-6">
                                          <div class="text-center text-black me-3 text">Drop files here or click to upload
                                          </div>
                                      </div>
                                      <div class="fallback">
                                          <input type="file" name="attachment[]" multiple>
                                      </div>
                                  </div>
                              </div>

                            <div class="col-lg-4 mb-3 ">
                              <label class="text-black mb-1 fs-6 fw-semibold">Department<span class="text-danger">*</span></label>
                              <select name="department2" class="select3 form-select">
                                <option value="">Select Department</option>
                                <option value="1"selected>HR</option>
                                <option value="2">Sales</option>
                              </select>
                            </div>




                            <div class="col-lg-4 mb-3 ">
                              <label class="text-black mb-1 fs-6 fw-semibold">Staff Name<span class="text-danger">*</span></label>
                              <select name="position2" class="select3 form-select">
                                <option value="">Select Staff Name</option>
                                <option value="1">Nithish</option>
                                <option value="2"selected>Sarvesh</option>
                              </select>
                            </div>
                          </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="col-12 d-flex justify-content-between mt-4">
                      <button class="btn btn-outline-secondary btn-prev"> <i
                              class="icon-base ri ri-arrow-left-line icon-sm scaleX-n1-rtl me-sm-1 me-0"></i>
                          <span class="align-middle d-sm-inline-block d-none">Previous</span>
                      </button>
                      <button class="btn btn-primary btn-next"> <span
                              class="align-middle d-sm-inline-block d-none me-sm-1">Update Staff</span> <i
                              class="icon-base ri ri-arrow-right-line icon-sm"></i></button>
                  </div>

                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - Other Credentials-->
    <div class="modal fade" id="kt_modal_other_credentials" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Other Credentials</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded border border-black"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <div class="row mt-2">
                        <div class="col-lg-12 mb-3">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="skype_id"
                                    data-cred="skype" />
                                <label class="text-black mb-1 fs-6 fw-semibold">Teams</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="spark_id"
                                    data-cred="spark" />
                                <label class="text-black mb-1 fs-6 fw-semibold">Spark</label>
                            </div>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input cred_check" type="checkbox" id="firewall_id"
                                    data-cred="firewall" />
                                <label class="text-black mb-1 fs-6 fw-semibold">Firewall</label>
                            </div>
                        </div>
                        <div class="mb-2" id="skype_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Teams Credentials</h5>
                            <div class="row mt-2">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2" id="spark_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Spark Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                        <div class="mb-2" id="firewall_cred" style="display: none;">
                            <h5 class="title fw-bold mt-2">Firewall Credentials</h5>
                            <div class="row">
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">User Name<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter User Name" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Password<span
                                            class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter password" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">URL</label>
                                    <input type="text" class="form-control" id=""
                                        placeholder="Enter URL" />
                                </div>
                                <div class="col-lg-3 mb-3">
                                    <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                    <textarea class="form-control" rows="1" id="" placeholder="Enter Description">-</textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center pb-4">
                        <button type="reset" class="btn btn-outline-danger me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Give Access</button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
    </div>
    <!--end::Modal - Other Credentials-->

    <!--begin::Modal - Confirmation Staff-->
    <div class="modal fade" id="kt_modal_confirmation_staff" tabindex="-1" aria-hidden="true" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-success swal2-icon-show" style="display: flex;">
                    <div class="swal2-icon-content"><i class="mdi mdi-check fs-1"></i></div>
                </div>
                <div class="swal2-html-container mb-2" id="swal2-html-container" style="display: block;">Are you sure
                    you
                    want to
                    Create Staff ?
                    <div class="d-block fw-bold fs-5 py-2">
                        <label class="text-black">Mahesh</label>
                        <span class="ms-2 me-2">-</span>
                        <label class="text-black">EGCS-0001/24</label>
                    </div>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 pb-8 mb-4">
                    <a href="{{ url('/hr_enroll/manage_staff') }}" class="btn btn-success me-3">Yes</a>
                    <a href="#" class="btn btn-outline-danger" data-bs-dismiss="modal">No</a>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Confirmation Staff-->



    {{-- <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script> --}}
      <script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.14.0/Sortable.min.js"></script>

    <!--Staff Add Credentials Accordion Start-->
    <script>
        'use strict';

        (function() {
            // Accordion toggle
            const credentials_acrd = document.querySelectorAll('.credentials_acrd');
            credentials_acrd.forEach(el => {
                el.addEventListener('click', event => {
                    event.preventDefault();
                    const card = el.closest('.card');
                    const collapseEl = card.querySelector('.collapse.credentials_acrd_body');

                    new bootstrap.Collapse(collapseEl);
                    card.querySelector('.card-header').classList.toggle('collapsed');
                    Helpers._toggleClass(el.firstElementChild, 'mdi-chevron-down', 'mdi-chevron-up');
                });
            });

            // Generic credential toggle
            function toggleCredential(id, show) {
                const section = document.getElementById(id + '_cred');
                if (section) section.style.display = show ? 'block' : 'none';
            }

            // Select All
            document.getElementById('credential_check_all')?.addEventListener('change', function() {
                const checked = this.checked;
                document.querySelectorAll('.cred_check').forEach(cb => {
                    cb.checked = checked;
                    toggleCredential(cb.dataset.cred, checked);
                });
            });

            // Individual checkbox handling
            document.querySelectorAll('.cred_check').forEach(cb => {
                cb.addEventListener('change', function() {
                    toggleCredential(this.dataset.cred, this.checked);
                });
            });

            // Dropdown-based create credential
            document.getElementById('create_cred')?.addEventListener('change', function() {
                const value = this.value;
                ['skype', 'spark', 'firewall'].forEach(id => {
                    toggleCredential(id, id === value);
                });
            });
        })();
    </script>

<script>
    // Using document.querySelector to select the elements
    var pendingtasks = document.querySelector('#pending-tasks');
    var completedtasks = document.querySelector('#completed-tasks');

    // Initialize sortable lists using the selected elements
    new Sortable(pendingtasks, {
      animation: 150,
      group: 'tasklist'
    });

    new Sortable(completedtasks, {
      animation: 150,
      group: 'tasklist'
    });
  </script>


<script>
    // Select/Deselect All functionality
    document.getElementById('selectAll').addEventListener('change', function() {
        const checked = this.checked;
        document.querySelectorAll('.checklist-item').forEach(item => {
            item.checked = checked;
        });
    });
</script>



    <script>
        $(document).ready(function() {
            // Run once on load
            toggleDivs();

            // Change event on radio buttons
            $("input[name='company']").on("change", function() {
                toggleDivs();
            });

            function toggleDivs() {
                if ($("#management").is(":checked")) {
                    $(".management_div").show();
                    $(".business_div").hide();
                } else if ($("#business").is(":checked")) {
                    $(".business_div").show();
                    $(".management_div").hide();
                }
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            let eduIndex = 1; // unique IDs for selects

            // Initialize the first select3
            $(".select3").select2();

            // Add More Education
            $("#add-edu-btn").click(function() {
                let clone = $(".education-row:first").clone(false, false); // clone without events

                // reset values
                clone.find("input").val("");
                clone.find("select").val("");

                // find select
                let newSelect = clone.find("select.select3");

                // remove any cloned select2 container if present
                clone.find(".select2").remove();
                newSelect.show(); // make sure <select> is visible

                // assign unique id
                newSelect.attr("id", "qualification_type_" + eduIndex);
                eduIndex++;

                // re-init select2
                newSelect.select2();

                // show delete button
                clone.find(".staff_edu_del").show();

                // append to wrapper
                $("#education-wrapper").append(clone);
            });

            // Delete Education Row
            $(document).on("click", ".staff_edu_del", function() {
                $(this).closest(".education-row").remove();
            });
        });
    </script>

    <script>
        login_func()

        function login_func() {

            var login_access = document.getElementById("login_access");
            if (login_access.checked) {
                $('#user_name_label').html('Username');
                $('.login_fields').show();
            } else {
                $('#user_name_label').html('Login Credentials');
                $('.login_fields').hide();
            }
        }
    </script>

    <script>
        $(document).ready(function() {
            // Hide wrapper by default
            $("#work-exp-wrapper").hide();
            $("#add-work-btn").hide();
            $(".work-exp-div").hide();

            // Handle type change
            $("#work_type").change(function() {
                if ($(this).val() === "2") {
                    // Experience selected
                    $("#work-exp-wrapper").show();
                    $("#add-work-btn").show();
                    $(".work-exp-div").show();
                } else {
                    // Fresher selected
                    $("#work-exp-wrapper").hide();
                    $("#add-work-btn").hide();
                    $(".work-exp-div").hide();

                    // Reset rows to only the first one (clean form)
                    $("#work-exp-wrapper .work-exp-row:not(:first)").remove();
                    $("#work-exp-wrapper")
                        .find("input")
                        .val(""); // clear inputs
                    $("#work-exp-wrapper .staff_work_del").hide(); // hide delete button in first row
                }
            });

            // Add More Work Experience
            $("#add-work-btn").click(function() {
                let clone = $(".work-exp-row:first").clone(false, false);

                // clear values
                clone.find("input").val("");

                // show delete button
                clone.find(".staff_work_del").show();

                // append
                $("#work-exp-wrapper").append(clone);

                // re-init datepicker if needed
                clone.find(".common_datepicker").datepicker({
                    format: "yyyy-mm-dd",
                    autoclose: true,
                    todayHighlight: true
                });
            });

            // Delete Work Row
            $(document).on("click", ".staff_work_del", function() {
                $(this).closest(".work-exp-row").remove();
            });

            // Initialize first datepickers
            $(".common_datepicker").datepicker({
                format: "yyyy-mm-dd",
                autoclose: true,
                todayHighlight: true
            });
        });
    </script>

  <script>
   $(document).ready(function() {
    let eduIndex = 1; // unique IDs for selects

    // Initialize Select2 for the first row only
    $("#doc_type_0").select2();

    // Add More Education
    $("#add-doc-btn").click(function() {
        let clone = $(".document-row:first").clone(); // clone without events

        // Reset input/select values
        clone.find("input").val("");
        clone.find("select").val("");

        // Remove old Select2 container from clone only
        clone.find(".select2").remove();
        let newSelect = clone.find("select.select3");

        // Assign unique ID to cloned select
        newSelect.attr("id", "doc_type_" + eduIndex);

        // Re-initialize Select2 for cloned select
        newSelect.select2();

        // Show delete button for clone
        clone.find(".staff_doc_del").show();

        // Append clone to wrapper
        $("#document-wrapper").append(clone);

        eduIndex++;
    });

    // Delete Education Row
    $(document).on("click", ".staff_doc_del", function() {
        $(this).closest(".document-row").remove();
    });
});

  </script>


<script>
  $(document).ready(function() {
    let courseIndex = 1;

    // Initialize Select2 for first dropdown
    $(".course-select").select2();

    // Toggle visibility based on Yes/No selection
    $('input[name="is_Course"]').on('change', function () {
      if ($(this).val() === 'yes') {
        $('#courseAttachmentHeader, #courseDocumentWrapper, #addCourseBtnWrapper').removeClass('d-none');
      } else {
        $('#courseAttachmentHeader, #courseDocumentWrapper, #addCourseBtnWrapper').addClass('d-none');
      }
    });

    // Add new course row
    $("#add-course-btn").click(function() {
      let clone = $(".course-document-row:first").clone(false, false);
      clone.find("input, select").val("");

      // remove any existing Select2 DOM
      clone.find(".select2").remove();
      let newSelect = clone.find("select.course-select");
      newSelect.attr("id", "course_doc_type_" + courseIndex);
      newSelect.show();
      newSelect.select2();
      courseIndex++;

      // show delete button
      clone.find(".course_doc_del").show();

      // append to wrapper
      $("#courseDocumentWrapper").append(clone);
    });

    // Delete course row
    $(document).on("click", ".course_doc_del", function() {
      $(this).closest(".course-document-row").remove();
    });
  });
</script>




    {{-- Married  --}}
    <script>
        $(document).ready(function() {
            $('#marital_status').on('change', function() {
                if ($(this).val() === '1') {
                    $('.spouse-field').removeClass('d-none');
                } else {
                    $('.spouse-field').addClass('d-none');
                }
            });
        });
    </script>

    <script>
  document.addEventListener("DOMContentLoaded", function () {
    const yesRadio = document.getElementById("childrenYes");
    const noRadio = document.getElementById("childrenNo");
    const childrenSections = document.querySelectorAll(".children-section");

    function toggleChildrenFields() {
      childrenSections.forEach(section => {
        if (yesRadio.checked) {
          section.classList.remove("d-none");
        } else {
          section.classList.add("d-none");
        }
      });
    }

    yesRadio.addEventListener("change", toggleChildrenFields);
    noRadio.addEventListener("change", toggleChildrenFields);
  });
</script>

    <script>
        $(document).ready(function() {
            $('input[name="is_working"]').on('change', function() {
                if ($(this).val() === 'yes') {
                    $('.working-fields').removeClass('d-none');
                } else {
                    $('.working-fields').addClass('d-none');
                }
            });
        });
    </script>


    <script>
        $(document).ready(function() {
            $('input[name="has_Siblings"]').on('change', function() {
                if ($(this).val() === 'yes') {
                    $('#siblingsDescription').removeClass('d-none');
                } else {
                    $('#siblingsDescription').addClass('d-none');
                }
            });
        });
    </script>

   <script>
    $(document).ready(function() {
        $('#work_type').on('change', function() {
            if ($(this).val() === '2') {
                $('.shiftedCompanyField').removeClass('d-none');
            } else {
                $('.shiftedCompanyField').addClass('d-none');
            }
        });
    });
    </script>


    <script>
      $(document).ready(function() {
        $('#Know_about_us').on('change', function() {
          const val = $(this).val();
          if (val === '5' || val === '6' || val === '7') {
            $('#knowDetails').removeClass('d-none');
          } else {
            $('#knowDetails').addClass('d-none');
          }
        });
      });
    </script>

    <script>
      $(document).ready(function() {
      $('input[name="is_MinimumWork"]').on('change', function() {
        if ($('#MinimumWorkNo').is(':checked')) {
          $('#minimumWorkReason').removeClass('d-none');
        } else {
          $('#minimumWorkReason').addClass('d-none');
        }
      });
    });

    </script>


<script>
  $(document).ready(function() {
  $('input[name="is_OriginalCertificate"]').on('change', function() {
    if ($('#OriginalCertificateNo').is(':checked')) {
      $('#originalCertificateReason').removeClass('d-none');
    } else {
      $('#originalCertificateReason').addClass('d-none');
    }
  });
});

</script>

<script>
  $(document).ready(function() {
  $('input[name="is_Travel"]').on('change', function() {
    if ($('#TravelNo').is(':checked')) {
      $('#travelReason').removeClass('d-none');
    } else {
      $('#travelReason').addClass('d-none');
    }
  });
});

</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
  function updateDuration() {
    const yes = document.getElementById('attendedElysiumYes');
    const dur = document.getElementById('attendedElysiumDuration');
    if (yes && yes.checked) dur.classList.remove('d-none'); else dur.classList.add('d-none');
  }

  // listen for changes (works even if radios are added later)
  document.addEventListener('change', function (e) {
    if (e.target && e.target.name === 'attended_elysium') updateDuration();
  });

  // initial
  updateDuration();
});
</script>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    const joiningImmediate = document.getElementById("joiningImmediate");
    const joiningNotice = document.getElementById("joiningNotice");
    const noticeField = document.querySelector(".notice-field");
    const immediateField = document.querySelector(".immediate-field");

    function toggleJoiningFields() {
      if (joiningImmediate.checked) {
        immediateField.classList.remove("d-none");
        noticeField.classList.add("d-none");
      } else if (joiningNotice.checked) {
        noticeField.classList.remove("d-none");
        immediateField.classList.add("d-none");
      } else {
        // Hide both by default
        noticeField.classList.add("d-none");
        immediateField.classList.add("d-none");
      }
    }

    // Add listeners
    joiningImmediate.addEventListener("change", toggleJoiningFields);
    joiningNotice.addEventListener("change", toggleJoiningFields);
  });
</script>

<script>
$(document).ready(function() {
    let altMobileIndex = 0; // start from 0 for default

    function updateAltMobileLabels() {
        $("#altmobile-wrapper .altmobile-row").each(function(index) {
            let label = $(this).find("label");
            if(index === 0){
                label.text("Alternate Mobile Number"); // default
            } else {
                label.text("Alternate Mobile Number " + index);
            }
        });
    }

    // Add More Alternate Mobile
    $("#add-altmobile-btn").click(function() {
        let clone = $(".altmobile-row:first").clone(); // clone first row

        // Reset input value
        clone.find("input").val("");

        // Show delete button for clone
        clone.find(".altmobile_del").show();

        // Append clone to wrapper
        $("#altmobile-wrapper").append(clone);

        // Update all labels
        updateAltMobileLabels();
    });

    // Delete Alternate Mobile Row
    $(document).on("click", ".altmobile_del", function() {
        $(this).closest(".altmobile-row").remove();

        // Update labels after deletion
        updateAltMobileLabels();
    });
});


</script>




@endsection
