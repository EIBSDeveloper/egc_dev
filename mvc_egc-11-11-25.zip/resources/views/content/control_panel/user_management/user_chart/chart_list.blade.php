@extends('layouts/layoutMaster')

@section('title', 'Users Chart')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
        
        /*.small-dropdown {*/
        /*max-width: 300px;*/
        /*font-size: 0.7rem;*/
        /*padding: 0.35rem 0.75rem;*/
        /*display: inline-block;*/
        /*}*/

        .hierarchy-table {
            position: relative; /* establishes stacking context */
            z-index: 1;
        }

        .hierarchy-table,
        .hierarchy-table td {
            border-width: 2px; /* Increase thickness here */
            border-style: solid;
            border-color: #d5c2c2; /* Or any color you want */
        }

        /* Sticky header cells */
        .hierarchy-table thead th {
            position: sticky;
            top: 0;
            z-index: 3;
            white-space: nowrap;
        }
        
        .hierarchy-table thead th:first-child {
            left: 0;
            z-index: 5;
            color: #fff;
        }
        
        .hierarchy-table tbody td:first-child {
            position: sticky;
            left: 0;
            z-index: 2;
            background-color: #fff;
            text-align: left;
            white-space: nowrap;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.05);
        }

        .module-item {
            display: flex;
            align-items: center;
            cursor: pointer;
            position: relative;
            padding-left: 20px;
            border-left: 3px solid #0d6efd;
            margin-bottom: 8px;
            user-select: none;
            transition: background-color 0.3s ease;
            border-radius: 4px;
        }
        
        .module-item:hover,
        .module-item:focus {
            background-color: rgba(13, 110, 253, 0.1);
            outline: none;
        }
        
        .expand-icon {
            flex-shrink: 0;
            margin-right: 8px;
            transition: transform 0.3s ease;
        }
        
        .submodules-list {
            max-height: 0;
            overflow: hidden;
            padding-left: 30px;
            border-left: 3px solid #6c757d;
            margin-top: 4px;
            transition: max-height 0.4s ease;
        }
        
        .submodules-list.expanded {
            max-height: 500px; /* big enough to fit all submodules */
        }
        
        .submodule-item {
            display: inline-block;
            margin: 3px 8px 3px 0;
            padding: 5px 10px;
            font-size: 0.85rem;
            border-radius: 15px;
            border: 1px solid #0d6efd;
            background-color: #e7f1ff;
            color: #0d6efd;
            cursor: default;
            user-select: none;
            transition: background-color 0.3s ease;
        }
        
        .submodule-item:hover {
            background-color: #c6defb;
        }
        
        /* Rotate arrow when expanded */
        .module-item[aria-expanded="true"] .expand-icon {
            transform: rotate(180deg);
        }

        .submodule-row td:first-child {
            padding-left: 3rem; /* indent submodules */
            border-left: 3px solid #6c757d;
            background-color: #f9f9f9;
        }
        
        .module-row:hover {
            background-color: rgba(13, 110, 253, 0.1);
            cursor: pointer;
        }

        .status-icon {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 20px;
            font-weight: bold;
            color: white;
            position: relative;
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(8px);
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            animation: popIn 0.6s ease-out;
            overflow: hidden;
            cursor: default;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .status-icon::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            z-index: 0;
            animation: glow 3s infinite ease-in-out;
        }

        .status-icon i {
            z-index: 1;
            transform: scale(1);
            transition: transform 0.3s ease;
        }

        /* ✅ Success */
        .status-icon.success::before {
            background: conic-gradient(from 0deg, #00693fff, #00b85cff, #00693fff);
            box-shadow: 0 0 15px #00693fff;
        }

        /* ❌ Danger */
        .status-icon.danger::before {
            background: conic-gradient(from 0deg, #ff4d4d, #cc0000, #ff4d4d);
            box-shadow: 0 0 15px #ff4d4d;
        }

        .status-icon.success i {
            color: #ffffff;
            text-shadow: 0 0 5px #00693fff;
        }

        .status-icon.danger i {
            color: #ffffff;
            text-shadow: 0 0 5px #ff4d4d;
        }

        .status-icon:hover {
            transform: scale(1.1);
            box-shadow: 0 0 20px rgba(255,255,255,0.2), 0 0 30px rgba(0,0,0,0.2);
        }

        .status-icon:hover i {
            transform: scale(1.2);
        }

        /* Animations */
        @keyframes glow {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes popIn {
            0% {
                transform: scale(0.2);
                opacity: 0;
            }
            80% {
                transform: scale(1.1);
                opacity: 1;
            }
            100% {
                transform: scale(1);
            }
        }
</style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Users Chart</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                User Management
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12" bis_skin_checked="1">
                    <div class="table-responsive scrollable-table-wrapper" style="max-height: 500px; overflow-y: auto;" bis_skin_checked="1">
                        <table class="table table-bordered align-middle text-center hierarchy-table">
                            <thead class="bg-secondary text-black sticky-top">
                                <tr>
                                    <th class="text-start text-white" style="min-width: 200px;background-color: #ab2b22">Modules</th>
                                    <th class="text-center text-black">CEO</th>
                                    <th class="text-center text-black">Business Head</th>
                                    <th class="text-center text-black">Accounts Head</th>
                                </tr>
                            </thead>
                            <tbody>             
                                <tr class="module-row bg-label-warning" data-module="Dashboard">
                                    <td class="bg-label-warning text-black">
                                        <strong>Dashboard</strong>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="module-row bg-label-warning" data-module="SwitchPortal" onclick="toggleRows(this)">
                                    <td class="bg-label-warning text-black">
                                        <span class="expand-icon">▼</span>
                                        <strong>Switch Portal</strong>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="submodule-row " style="background-color: #EBEAEA;" data-parent="SwitchPortal" data-submodule="Business" style="display: table-row;" onclick="toggleRows(this)">
                                    <td style="padding-left: 30px;background-color: #EBEAEA;" class="text-black" >
                                        <span class="expand-icon">▼</span>Business
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon success" bis_skin_checked="1">
                                            <i class="fas fa-check"></i>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="action-row" data-parent="Business" style="display: table-row;">
                                    <td style="padding-left: 60px;">EAPL</td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                        <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="action-row" data-parent="Business" style="display: table-row;">
                                    <td style="padding-left: 60px;">EiBS</td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="action-row" data-parent="Business" style="display: table-row;">
                                    <td style="padding-left: 60px;">ETPL</td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                </tr>
                                <tr class="action-row" data-parent="Business" style="display: table-row;">
                                    <td style="padding-left: 60px;">APF</td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                    <td align="center">
                                        <div class="status-icon danger" bis_skin_checked="1">
                                            <i class="fas fa-times"></i>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<script>
    function toggleRows(el) {
    const icon = el.querySelector('.expand-icon');
    const isExpanded = icon.textContent.trim() === '▼';
    icon.textContent = isExpanded ? '▶' : '▼';

    if (el.classList.contains('module-row')) {
      const moduleName = el.getAttribute('data-module');
      // Toggle submodules visibility
      document.querySelectorAll(`.submodule-row[data-parent="${moduleName}"]`).forEach(row => {
        row.style.display = isExpanded ? 'none' : 'table-row';

        // When collapsing, also hide actions of these submodules
        if (isExpanded) {
          const submenuName = row.getAttribute('data-submodule');
          document.querySelectorAll(`.action-row[data-parent="${submenuName}"]`).forEach(actionRow => {
            actionRow.style.display = 'none';
          });
        }
      });
    } else if (el.classList.contains('submodule-row')) {
      const submenuName = el.getAttribute('data-submodule');
      document.querySelectorAll(`.action-row[data-parent="${submenuName}"]`).forEach(row => {
        row.style.display = isExpanded ? 'none' : 'table-row';
      });
    }
  }
</script>

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength": 25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
                //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>

@endsection
