@extends('layouts/layoutMaster')

@section('title', 'Manage Company')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'
])
@endsection

@section('content')
<style>
    .dataTables_scroll {
        max-height: 200px;
    }
</style>

<!-- Lead List Table -->
<div class="card card-action">
    <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-start justify-content-start flex-column">
            <h5 class="card-title mb-1 text-black">Manage Company</h5>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb custom-breadcrumb">
                    <!-- Home -->
                    <li class="breadcrumb-item">
                        <a href="{{ url('/dashboard') }}">
                            <i class="mdi mdi-home"></i> Home
                        </a>
                    </li>
                    <li class="breadcrumb-item" aria-current="page">
                        <a href="javascript:void(0);">
                            <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <a href="javascript:void(0);" class="active-link">
                            Entity Hub
                        </a>
                    </li>
                </ol>
            </nav>
        </div>
        <div>
            <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                <!-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" id="branch_filter" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Filter">
                    <span><i class="mdi mdi-filter-outline"></i></span>
                </a> -->
                <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal" data-bs-target="#kt_modal_create_company">
                    <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Company
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex align-items-center justify-content-between mb-4 gap-2">
                    <div>
                        <span>Show</span>
                        <br>
                        <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                            <option value="10">10</option>
                            <option value="25" selected>25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                        </select>
                    </div>
                    <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                        <label  class="d-flex align-items-center gap-2 ">
                            <input type="text" class="form-control" id="lead_fill" name="lead_fill" value="" placeholder="Enter Company - Name/ Mob. No/ Email Id" />
                            <button type="submit" class="btn btn-sm btn-primary fw-semibold ">Search</button>
                        </label>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                    <thead>
                        <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                            <th class="min-w-150px">Company</th>
                            <th class="min-w-100px">Email ID</th>
                            <th class="min-w-100px">Contact Person / Mobile</th>
                            <th class="min-w-50px">Status</th>
                            <th class="min-w-100px text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-black fw-semibold fs-7">
                        <tr>
                            <td>
                                <div class="d-flex allign-items-center gap-2">
                                    <div>
                                        <div class="d-flex align-items-center">
                                            <div class="text-truncate max-w-175px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Elysian Intelligence Business Solution">Elysian Intelligence Business Solution</div>
                                            <a href="https://eibsglobal.com/" target="_blank" class="ms-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL">
                                                <i class="mdi mdi-web fs-4 text-dark" ></i>
                                            </a>
                                        </div>
                                        <div class="d-block">
                                            <label class="badge bg-warning fs-8 text-black fw-bold">Private Limited Company (Pvt Ltd)</label>
                                        </div>
                                    </div>
                                    <label data-bs-toggle="modal" data-bs-target="#kt_modal_location_map">
                                        <i class="mdi mdi-map-marker-radius fs-4 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Ground Floor, A Block, Elysium Campus, 229, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020"></i>
                                    </label>
                                </div>
                            </td>
                            <td>
                                <label>info@eibsglobal.com</label>
                            </td>
                            <td>
                                <label>Sankar Ganesh</label>
                                <div class="d-block">
                                    <label class="fs-8 text-black fw-semibold">9894444710</label>
                                </div>
                            </td>
                            <td>
                                <label class="switch switch-square">
                                    <input type="checkbox" class="switch-input" checked />
                                    <span class="switch-toggle-slider">
                                        <span class="switch-on"></span>
                                        <span class="switch-off"></span>
                                    </span>
                                </label>
                            </td>
                            <td>
                                <div class="text-center">
                                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_create_entity">
                                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Entity"> <i class="mdi mdi-source-branch-plus fs-3 text-black me-1"></i></span></a>
                                    <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_company">
                                            <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_update_company">
                                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                        </a>
                                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company">
                                            <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                        </a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



<!--begin::Modal - Create Company-->
<div class="modal fade" id="kt_modal_create_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <button type="button"
                        class="btn btn-sm btn-icon rounded-pill btn-white position-absolute modal_close"
                        style="top: 2px; right: 2px; z-index: 10;"
                        data-bs-dismiss="modal" aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                            transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1"
                            transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                    </span>
                </button>
                <div class="shadow-sm rounded border-1 px-5 pt-5"
                    style="background: linear-gradient(to bottom, #e8e1f7 0%, #ffffff 15%, #ffffff 100%);">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Create Company</h3>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Company Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Company Type</option>
                                <option value="1">Private Limited Company (Pvt Ltd)</option>
                                <option value="2">Public Limited Company (PLC)</option>
                                <option value="3">Limited Liability Partnership (LLP)</option>
                                <option value="4">Government Organization</option>
                                <option value="5">Non-Profit Organization (NGO/NPO)</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">USA</option>
                                <option value="2">UAE</option>
                                <option value="3">India</option>
                                <option value="4">South Africa</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1">Tamilnadu</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Kerala</option>
                                <option value="4">Karnataka</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1">Madurai</option>
                                <option value="2">Virudhunagar</option>
                                <option value="3">Thirunelveli</option>
                                <option value="4">Coimbatore</option>
                                <option value="5">Chennai</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter GST No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CIN No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Tax No" />
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center pb-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Company</button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Create Company-->


<!--begin::Modal - Update Company-->
<div class="modal fade" id="kt_modal_update_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <button type="button"
                        class="btn btn-sm btn-icon rounded-pill btn-white position-absolute modal_close"
                        style="top: 2px; right: 2px; z-index: 10;"
                        data-bs-dismiss="modal" aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                            transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1"
                            transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                    </span>
                </button>
                <div class="shadow-sm rounded border-1 px-5 pt-5"
                    style="background: linear-gradient(to bottom, #e8e1f7 0%, #ffffff 15%, #ffffff 100%);">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Update Company</h3>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Company Name" value="Elysian Intelligence Business Solution" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Company Type</option>
                                <option value="1" selected>Private Limited Company (Pvt Ltd)</option>
                                <option value="2">Public Limited Company (PLC)</option>
                                <option value="3">Limited Liability Partnership (LLP)</option>
                                <option value="4">Government Organization</option>
                                <option value="5">Non-Profit Organization (NGO/NPO)</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID" value="info@eibsglobal.com" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL" value="https://eibsglobal.com/" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" value="Sankar Ganesh" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" value="9894444710" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">USA</option>
                                <option value="2">UAE</option>
                                <option value="3" selected>India</option>
                                <option value="4">South Africa</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1" selected>Tamilnadu</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Kerala</option>
                                <option value="4">Karnataka</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1" selected>Madurai</option>
                                <option value="2">Virudhunagar</option>
                                <option value="3">Thirunelveli</option>
                                <option value="4">Coimbatore</option>
                                <option value="5">Chennai</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" value="Ground Floor, C Block, Elysium Campus, 229, Church Rd, Anna Nagar" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" value="229" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" value="625020" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter GST No" value="27AABCU9603R1ZV" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CIN No" value="U12345MH2005PTC123456" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" value="AABCU9603R" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Tax No" value="1234567890" />
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description">-</textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" value="HDFC" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" value="Anna Nagar" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder" value="Elysian Intelligence Business Solution
                                " />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No" value="8574854578452" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code" value="HDFC0002027" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center pb-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Update Company</button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Update Company-->


<!--begin::Modal - View Company-->
<div class="modal fade" id="kt_modal_view_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <button type="button"
                        class="btn btn-sm btn-icon rounded-pill btn-white position-absolute modal_close"
                        style="top: 2px; right: 2px; z-index: 10;"
                        data-bs-dismiss="modal" aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                            transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1"
                            transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                    </span>
                </button>
                <div class="shadow-sm rounded border-1 px-5 pt-5"
                    style="background: linear-gradient(to bottom, #e8e1f7 0%, #ffffff 15%, #ffffff 100%);">
                    <!--begin::Heading-->
                    <div class="mb-8">
                        <h3 class="mb-4 text-black text-center">View Company</h3>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Company</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Elysian Intelligence Business Solution
                                    ">Elysian Intelligence Business Solution
                                    </div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Company Type</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Private Limited Company (Pvt Ltd)">Private Limited Company (Pvt Ltd)</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Email ID</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="info@eibsglobal.com">info@eibsglobal.com</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Website URL</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <a href="https://elysiumtechnologies.com/" target="_blank" data-bs-toggle="tooltip" data-bs-placement="bottom" title="https://eibsglobal.com/">
                                        <div class="text-truncate max-w-75 text-black fs-6 fw-bold">https://eibsglobal.com/</div>
                                    </a>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Contact Person</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Sankar Ganesh">Sankar Ganesh</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">C.P. Mobile No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">9894444710</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Address</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Ground Floor, C Block, Elysium Campus, 229, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">GST No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="27AABCU9603R1ZV">27AABCU9603R1ZV</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">CIN No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="U12345MH2005PTC123456">U12345MH2005PTC123456</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">PAN No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="AABCU9603R">AABCU9603R</div>
                                </div>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Tax No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <div class="col-7">
                                    <div class="text-truncate max-w-75 text-black fs-6 fw-bold" data-bs-toggle="tooltip" data-bs-placement="bottom" title="1234567890">1234567890</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-12 text-dark mb-2 fs-6 fw-semibold">Description</label>
                        <label class="col-12 text-black fs-6 fw-bold">&emsp;&emsp;&emsp; -</label>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row pb-4">
                        <div class="col-lg-6 mt-4">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Bank</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">HDFC</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Branch</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Anna Nagar</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">IFSC Code</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">HDFC0002027</label>
                            </div>
                        </div>
                        <div class="col-lg-6 mt-2">
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account Holder</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">Elysium Intelligence Business Solutions</label>
                            </div>
                            <div class="row mb-4">
                                <label class="col-4 text-dark fs-6 fw-semibold">Account No</label>
                                <label class="col-1 text-black fs-6 fw-bold">:</label>
                                <label class="col-7 text-black fs-6 fw-bold">8574854578452</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Company-->

<!--begin::Modal - View Location-->
<div class="modal fade" id="kt_modal_location_map" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
           <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <button type="button"
                        class="btn btn-sm btn-icon rounded-pill btn-white position-absolute modal_close"
                        style="top: 2px; right: 2px; z-index: 10;"
                        data-bs-dismiss="modal" aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                            transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1"
                            transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                    </span>
                </button>
                <div class="shadow-sm rounded border-1 px-5 pt-5"
                    style="background: linear-gradient(to bottom, #e8e1f7 0%, #ffffff 15%, #ffffff 100%);">
                    <!--begin::Heading-->
                    <div class="mb-8">
                        <h3 class="mb-4 text-black text-center">View Location</h3>
                        <div class="d-block text-center">
                            ( <label class="fs-4 text-primary fw-bold">Elysium Intelligence Business Solutions</label> )
                        </div>
                    </div>
                    <div class="row pb-4">
                        <div class="col-lg-12">
                            <iframe class="w-100 border border-solid rounded"
                                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3930.164298387349!2d78.14544841083799!3d9.920271074360143!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b00c5aed8fb1d3b%3A0xed72f5ca5f4eeac6!2sEiBS%20%7C%20Website%20Design%20Company%20%7C%20Web%20Development%20%7C%20Mobile%20App%20Development%20%7C%20Billing%20%7C%20CRM%20%7C%20ERP%20Software!5e0!3m2!1sen!2sin!4v1746786093556!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - View Location-->


<!--begin::Modal - Delete Company-->
<div class=" modal fade" id="kt_modal_delete_company" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-m">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                <div class="swal2-icon-content">?</div>
            </div>
            <div class="swal2-html-container" id="swal2-html-container" style="display: block;">Are you sure you want to delete Company?
                <div class="d-block fw-semibold text-black mt-4 fs-5 py-2">
                    <label>Elysium Technologies</label>
                    <span class="ms-2 me-2">-</span>
                    <label>CMY-0001/24</label>
                </div>
            </div>
            <div class="d-flex justify-content-center align-items-center pt-8">
                <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes</button>
                <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
            </div><br><br>
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Company-->

<!--begin::Modal - Create Entity-->
<div class="modal fade" id="kt_modal_create_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-xl">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal body-->
            <div class="modal-body px-2 py-2 position-relative">
                <button type="button"
                        class="btn btn-sm btn-icon rounded-pill btn-white position-absolute modal_close"
                        style="top: 2px; right: 2px; z-index: 10;"
                        data-bs-dismiss="modal" aria-label="Close">
                    <span class="svg-icon svg-icon-1">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                        xmlns="http://www.w3.org/2000/svg">
                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                            transform="rotate(-45 6 17.3137)" fill="currentColor" />
                        <rect x="7.41422" y="6" width="16" height="2" rx="1"
                            transform="rotate(45 7.41422 6)" fill="currentColor" />
                    </svg>
                    </span>
                </button>
                <div class="shadow-sm rounded border-1 px-5 pt-5"
                    style="background: linear-gradient(to bottom, #e8e1f7 0%, #ffffff 15%, #ffffff 100%);">
                    <!--begin::Heading-->
                    <div class="mb-8 text-center">
                        <h3 class="text-center mb-4 text-black">Create Entity</h3>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Company</option>
                                <option value="1">Elysium Technologies Pvt Ltd</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">USA</option>
                                <option value="2">UAE</option>
                                <option value="3">India</option>
                                <option value="4">South Africa</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1">Tamilnadu</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Kerala</option>
                                <option value="4">Karnataka</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1">Madurai</option>
                                <option value="2">Virudhunagar</option>
                                <option value="3">Thirunelveli</option>
                                <option value="4">Coimbatore</option>
                                <option value="5">Chennai</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                            <input type="text" class="form-control" placeholder="Enter GST No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                            <input type="text" class="form-control" placeholder="Enter CIN No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" />
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-end align-items-center pb-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" data-bs-dismiss="modal">Create Entity</button>
                    </div>
                </div>
            </div>
        </div>
        <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
</div>
<!--end::Modal - Create Entity-->

<script>
    $(".list_page").DataTable({
        "ordering": false,
        "pageLength":25,
        // "aaSorting":[],
        "language": {
            "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
            // "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
            // "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
            ">" +

            "<'table-responsive'tr>" +

            "<'row'" +
            // "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
            // "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
            ">"
    });
</script>
@endsection
