<?php

namespace App\Helpers;

use Config;
use Illuminate\Support\Str;
use App\Models\GeneralSettingsModel;
use App\Models\BatchHistoryModel;
use App\Models\JobRollModel;
use App\Models\PreSkillSetModel;
use App\Models\BrandModel;
use App\Models\GroupModel;
use App\Models\KnowledgeLevelModel;
use App\Models\DocumentTypeModel;
use App\Models\BranchTypeModel;
use App\Models\BranchModel;
use App\Models\DepartmentModel;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;
use App\Models\StaffModel;
use App\Models\UserRoleModel;
use App\Models\JobRoleModel;
use App\Models\TimeZoneModel;
use App\Models\CurrencyFormatModel;
use App\Models\FacilityModel;
use App\Models\HrDirectoryBranchModel;
use App\Models\InterviewTypeModel;
use App\Models\HrDirectoryModel;
use App\Models\JobDirectoryModel;
use App\Models\ManageQuestionModel;
use App\Models\UserRolePermissionModel;
use App\Models\FinancialYearModel;
use App\Models\StaffAttendanceModel;
use App\Models\AttendanceModel;
use App\Models\Schedule_message_model;
use App\Models\SmsTemplateModel;
use App\Models\WhatsappTemplateModel;
use App\Models\EmailTemplateModel;
use App\Models\Rules_guidelinesModel;
use App\Models\ShiftTimeModel;
use App\Models\NotificationTypeModel;
use App\Models\NotificationModel;
use App\Models\ExamModel;
use App\Models\MaterialTypeModel;
use App\Models\MarketingModel;
use App\Models\PointsModel;
use App\Models\CustomerPlacementModel;
use App\Models\ManageCouponHistoryModel;
use App\Models\ManageCouponModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

use App\Models\AppointmentModel;
use App\Models\LeadAppointmentModel;
use App\Models\GoalSetStaffModel;
use App\Models\CustomerModel;
use App\Models\CurrencyRateModel;

class Helpers
{
  public static function appClasses()
  {

    $data = config('custom.custom');


    // default data array
    $DefaultData = [
      'myLayout' => 'vertical',
      'myTheme' => 'theme-default',
      'myStyle' => 'light',
      'myRTLSupport' => true,
      'myRTLMode' => true,
      'hasCustomizer' => true,
      'showDropdownOnHover' => true,
      'displayCustomizer' => true,
      'contentLayout' => 'compact',
      'headerType' => 'fixed',
      'navbarType' => 'fixed',
      'menuFixed' => true,
      'menuCollapsed' => false,
      'footerFixed' => false,
      'menuFlipped' => false,
      // 'menuOffcanvas' => false,
      'customizerControls' => [
        'rtl',
      'style',
      'headerType',
      'contentLayout',
      'layoutCollapsed',
      'showDropdownOnHover',
      'layoutNavbarOptions',
      'themes',
      ],
      //   'defaultLanguage'=>'en',
    ];

    // if any key missing of array from custom.php file it will be merge and set a default value from dataDefault array and store in data variable
    $data = array_merge($DefaultData, $data);

    // All options available in the template
    $allOptions = [
      'myLayout' => ['vertical', 'horizontal', 'blank', 'front'],
      'menuCollapsed' => [true, false],
      'hasCustomizer' => [true, false],
      'showDropdownOnHover' => [true, false],
      'displayCustomizer' => [true, false],
      'contentLayout' => ['compact', 'wide'],
      'headerType' => ['fixed', 'static'],
      'navbarType' => ['fixed', 'static', 'hidden'],
      'myStyle' => ['light', 'dark', 'system'],
      'myTheme' => ['theme-default', 'theme-bordered', 'theme-semi-dark'],
      'myRTLSupport' => [true, false],
      'myRTLMode' => [true, false],
      'menuFixed' => [true, false],
      'footerFixed' => [true, false],
      'menuFlipped' => [true, false],
      // 'menuOffcanvas' => [true, false],
      'customizerControls' => [],
      // 'defaultLanguage'=>array('en'=>'en','fr'=>'fr','de'=>'de','ar'=>'ar'),
    ];

    //if myLayout value empty or not match with default options in custom.php config file then set a default value
    foreach ($allOptions as $key => $value) {
      if (array_key_exists($key, $DefaultData)) {
        if (gettype($DefaultData[$key]) === gettype($data[$key])) {
          // data key should be string
          if (is_string($data[$key])) {
            // data key should not be empty
            if (isset($data[$key]) && $data[$key] !== null) {
              // data key should not be exist inside allOptions array's sub array
              if (!array_key_exists($data[$key], $value)) {
                // ensure that passed value should be match with any of allOptions array value
                $result = array_search($data[$key], $value, 'strict');
                if (empty($result) && $result !== 0) {
                  $data[$key] = $DefaultData[$key];
                }
              }
            } else {
              // if data key not set or
              $data[$key] = $DefaultData[$key];
            }
          }
        } else {
          $data[$key] = $DefaultData[$key];
        }
      }
    }
    $styleVal = $data['myStyle'] == "dark" ? "dark" : "light";
    if(isset($_COOKIE['mode'])){
      if($_COOKIE['mode'] === "system"){
        if(isset($_COOKIE['colorPref'])) {
          $styleVal = Str::lower($_COOKIE['colorPref']);
        }
      }
      else {
        $styleVal = $_COOKIE['mode'];
      }
    }
    isset($_COOKIE['theme']) ? $themeVal = $_COOKIE['theme'] : $themeVal = $data['myTheme'];
    //layout classes
    $layoutClasses = [
      'layout' => $data['myLayout'],
      'theme' => $themeVal,
      'themeOpt' => $data['myTheme'],
      'style' => $styleVal,
      'styleOpt' => $data['myStyle'],
      'rtlSupport' => $data['myRTLSupport'],
      'rtlMode' => $data['myRTLMode'],
      'textDirection' => $data['myRTLMode'],
      'menuCollapsed' => $data['menuCollapsed'],
      'hasCustomizer' => $data['hasCustomizer'],
      'showDropdownOnHover' => $data['showDropdownOnHover'],
      'displayCustomizer' => $data['displayCustomizer'],
      'contentLayout' => $data['contentLayout'],
      'headerType' => $data['headerType'],
      'navbarType' => $data['navbarType'],
      'menuFixed' => $data['menuFixed'],
      'footerFixed' => $data['footerFixed'],
      'menuFlipped' => $data['menuFlipped'],
      'customizerControls' => $data['customizerControls'],
    ];

    // sidebar Collapsed
    if ($layoutClasses['menuCollapsed'] == true) {
      $layoutClasses['menuCollapsed'] = 'layout-menu-collapsed';
    }

    // Header Type
    if ($layoutClasses['headerType'] == 'fixed') {
      $layoutClasses['headerType'] = 'layout-menu-fixed';
    }
    // Navbar Type
    if ($layoutClasses['navbarType'] == 'fixed') {
      $layoutClasses['navbarType'] = 'layout-navbar-fixed';
    } elseif ($layoutClasses['navbarType'] == 'static') {
      $layoutClasses['navbarType'] = '';
    } else {
      $layoutClasses['navbarType'] = 'layout-navbar-hidden';
    }

    // Menu Fixed
    if ($layoutClasses['menuFixed'] == true) {
      $layoutClasses['menuFixed'] = 'layout-menu-fixed';
    }


    // Footer Fixed
    if ($layoutClasses['footerFixed'] == true) {
      $layoutClasses['footerFixed'] = 'layout-footer-fixed';
    }

    // Menu Flipped
    if ($layoutClasses['menuFlipped'] == true) {
      $layoutClasses['menuFlipped'] = 'layout-menu-flipped';
    }

    // Menu Offcanvas
    // if ($layoutClasses['menuOffcanvas'] == true) {
    //   $layoutClasses['menuOffcanvas'] = 'layout-menu-offcanvas';
    // }

    // RTL Supported template
    if ($layoutClasses['rtlSupport'] == true) {
      $layoutClasses['rtlSupport'] = '/rtl';
    }

    // RTL Layout/Mode
    if ($layoutClasses['rtlMode'] == true) {
      $layoutClasses['rtlMode'] = 'rtl';
      $layoutClasses['textDirection'] = 'rtl';
    } else {
      $layoutClasses['rtlMode'] = 'ltr';
      $layoutClasses['textDirection'] = 'ltr';
    }

    // Show DropdownOnHover for Horizontal Menu
    if ($layoutClasses['showDropdownOnHover'] == true) {
      $layoutClasses['showDropdownOnHover'] = true;
    } else {
      $layoutClasses['showDropdownOnHover'] = false;
    }

    // To hide/show display customizer UI, not js
    if ($layoutClasses['displayCustomizer'] == true) {
      $layoutClasses['displayCustomizer'] = true;
    } else {
      $layoutClasses['displayCustomizer'] = false;
    }

    return $layoutClasses;
  }

  public static function updatePageConfig($pageConfigs)
  {
    $demo = 'custom';
    if (isset($pageConfigs)) {
      if (count($pageConfigs) > 0) {
        foreach ($pageConfigs as $config => $val) {
          Config::set('custom.' . $demo . '.' . $config, $val);
        }
      }
    }
  }
  public static function isActiveMenu($menu, $currentRouteName)
  {
      // Direct match
      if (isset($menu->slug)) {
          if (is_array($menu->slug)) {
              foreach ($menu->slug as $slug) {
                  if (str_starts_with($currentRouteName, $slug)) {
                      return true;
                  }
              }
          } else {
              if (str_starts_with($currentRouteName, $menu->slug)) {
                  return true;
              }
          }
      }

      // Recursive check for children
      if (isset($menu->submenu)) {
          foreach ($menu->submenu as $submenu) {
              if (self::isActiveMenu($submenu, $currentRouteName)) {
                  return true;
              }
          }
      }

      return false;
  }

  public static function getMenuJson()
  {
      // Path to the JSON file (you can adjust it)
      $path = resource_path('menu/verticalMenu.json'); // e.g., resources/data/menu.json

      if (file_exists($path)) {
          $json = file_get_contents($path); // read file contents
          $data = json_decode($json, false); // decode JSON as object

          return $data->menu ?? []; // return menu array or empty array
      }

      return []; // fallback if file doesn't exist
  }

    function Logo_pic($pic)
    {
        if ($pic) {
            return url('logos/' . $pic);
        } else {
            return ""; // Return an empty string if no picture is provided
        }
    }

    function Fav_Icon_pic($pic)
    {
        if ($pic) {
            return url('fav_icons/' . $pic);
        } else {
            return ''; // Return an empty string if no picture is provided
        }
    }
    // ******************************** Vasanth ****************************
    //goalset
 

   
    //goalset

    function get_branch_staff_list_by_id($branch_id)
    {
        $result = StaffModel::select('egc_staff.sno', 'egc_staff.branch_id', 'egc_staff.status', 'egc_staff.staff_name', 'egc_job_role.job_position_name')
            ->leftJoin('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.position_role')
            ->where('egc_staff.status', 0)
            ->where('egc_staff.branch_id', $branch_id)


            ->orderBy('egc_staff.staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_points_by_id($id = '')
    {
        $result = PointsModel::where('status', 0)->where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Dashboard

    function get_atten_data_staff($staff_id = '', $date = '')
    {
        // Validate inputs
        if (empty($staff_id) || empty($date)) {
            return ''; // Return an empty string if required inputs are missing
        }

        // Format the date
        $atten_date = date('Y-m-d', strtotime($date));

        $result = StaffAttendanceModel::where('date', $atten_date)
            ->where('staff_id', $staff_id)
            ->first();

        // Return attendance if the record exists, otherwise return an empty string
        return $result ? $result->attendance : '';
    }
   
    function get_long_absent_customers($cus_sno)
    {
        // Fetch attendance records with 'A' (Absent) status and sort them in descending order
        $attendanceDates = AttendanceModel::where('customer_id', $cus_sno)
            ->where('attendance', 'A')
            ->orderBy('att_date', 'desc') // Latest dates first
            ->pluck('att_date')
            ->toArray();

        // If there are less than 3 absent records, return 0
        if (count($attendanceDates) < 3) {
            return 0;
        }

        // Check if the last 3 dates are consecutive
        $first = strtotime($attendanceDates[0]);
        $second = strtotime($attendanceDates[1]);
        $third = strtotime($attendanceDates[2]);

        if ($second == strtotime("-1 day", $first) && $third == strtotime("-2 days", $first)) {
            return 1; // Last 3 absent days are consecutive
        }

        return 0; // Not consecutively absent for the last 3 days
    }




   


    // schedule_messages
    public function scheduleMessages($sourceTypeId, $sourceId, $configId, $branchId, $userId)
    {
        try {
            $addMessage = new Schedule_message_model();
            $addMessage->config_id = $configId;
            $addMessage->source_type_id = $sourceTypeId;
            $addMessage->source_id  = $sourceId;
            $addMessage->branch_id  = $branchId;
            $addMessage->created_by = $userId;
            $addMessage->updated_by = $userId;
            $addMessage->save();
            return response()->json([
                'status' => 200,
                'message' => 'Successfully scheduled message!',
                'error_msg' => null,
                'data' => $addMessage,
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 500,
                'message' => 'Error scheduling message.',
                'error_msg' => $e->getMessage(),
                'data' => null,
            ], 500);
        }
    }


    function get_tracker_last_login_data($staff_mobile)
    {

        $other_db = DB::connection('mysql_secondary');
        $select_users = $other_db
            ->table('user as u')
            ->select('u.user_id', 'u.last_sync_date', 'u.last_sync_time')
            ->where('u.phone_no', $staff_mobile)
            ->first();
        return $select_users;
    }

    //   GET ROLE USRMANAGEMENT
    function get_roles_list()
    {
        // Fetch roles from the UserRoleModel
        $roles = UserRoleModel::where('status', 0)->get();

        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Filter roles to exclude those that are in userRolePermissions
        $filteredRoles = $roles->filter(function ($role) use ($userRolePermissions) {
            return !in_array($role->sno, $userRolePermissions); // Exclude roles with matching role_id
        });

        return $filteredRoles;
    }

    // Get SmS Tempalate
    function get_sms_template($id = '')
    {
        $result = SmsTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Whatsapp Template
    function get_whatsapp_template($id = '')
    {
        $result = WhatsappTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Email Template
    function get_email_template($id = '')
    {
        $result = EmailTemplateModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_roles_list_nav($user_id = null)
    {
        // Fetch the role IDs from UserRolePermissionModel
        $userRolePermissions = UserRolePermissionModel::pluck('role_id')->toArray();

        // Fetch only the roles that exist in userRolePermissions
        $matchingRoles = UserRoleModel::where('status', 0)
            ->whereIn('sno', $userRolePermissions) // Only roles that match
            ->get();

        return $matchingRoles;
    }
    // Get Branch and Franchise list based on user_id
    function get_branch_control_list($user_id)
    {
        // Fetch the user based on user_id
        $user = StaffModel::where('sno', $user_id)->first();

        if ($user && $user->sno == 1) {
            $branches = BranchModel::where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::where('status', 0)
                ->where('branch_type', 2)
                ->get();

            return ['branches' => $branches, 'franchises' => $franchises];
        } elseif ($user !== null) {
            // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
            $accessibleBranches = json_decode($user->multi_branch_access, true);

            if (!empty($accessibleBranches)) {
                // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
                $branches = BranchModel::whereIn('sno', $accessibleBranches)
                    ->where('status', 0)
                    ->where('branch_type', 1)
                    ->get();

                $franchises = BranchModel::whereIn('sno', $accessibleBranches)
                    ->where('status', 0)
                    ->where('branch_type', 2)
                    ->get();

                return ['branches' => $branches, 'franchises' => $franchises];
            }
        } else {
            // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
            $branches = BranchModel::where('status', 0)
                ->where('branch_type', 1)
                ->get();

            $franchises = BranchModel::where('status', 0)
                ->where('branch_type', 2)
                ->get();
            return ['branches' => $branches, 'franchises' => $franchises];
        }
    }



    // common Date Format
    function general_setting_data()
    {
        $sno = 1;
        $result = GeneralSettingsModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // encrypt_decrypt
    // function encrypt_decrypt($string, $action = 'encrypt')
    // {
    //     $encrypt_method = "AES-256-CBC";
    //     $secret_key = 'EAPL'; // Change this to your secret key
    //     $secret_iv = 'YourSecretIV'; // Change this to your secret IV

    //     $key = hash('sha256', $secret_key);
    //     $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

    //     if ($action == 'encrypt') {
    //         $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
    //         $output = base64_encode($output);
    //     } elseif ($action == 'decrypt') {
    //         $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    //     } else {
    //         $output = false;
    //     }

    //     return $output;
    // }
    function encrypt_decrypt($string, $action = 'encrypt')
    {
        $encrypt_method = "AES-256-CBC";
        $secret_key = 'EGC'; // Change this to your secret key
        $secret_iv = 'ABCDEFEGC46464566@#$%EGC'; // Change this to your secret IV
        $key = hash('sha256', $secret_key);
        $iv = substr(hash('sha256', $secret_iv), 0, 16); // Ensure IV is 16 bytes

        if ($action == 'encrypt') {
            $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
            $output = base64_encode($output);
        } elseif ($action == 'decrypt') {
            $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
        } else {
            $output = false;
        }

        return $output;
    }
    // Get Country Names by ID
    function get_country_data($id = '')
    {
        $result = CountryModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get State Names by ID
    function get_state_data($id = '')
    {
        $result = StateModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get City Names by ID
    function get_city_data($id = '')
    {
        $result = CityModel::where('id', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // Get Branch list
    function get_branch_list()
    {
        $result = BranchModel::where('status', 0)->where('branch_type', 1)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_branch_franchise_list()
    {
        $result = BranchModel::where('status', 0)->where('sno', '!=', 1)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get Franchise list
    function get_franchise_list()
    {
        $result = BranchModel::where('status', 0)->where('branch_type', 2)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get Branch id
    function get_branch_id($sno = "")
    {
        $result = BranchModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Get Franchise list
    function get_franchise_id($sno = "")
    {
        $result = BranchModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Role list
    function get_role_list()
    {
        $result = UserRoleModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Role id
    function get_role_id($sno = "")
    {
        $result = UserRoleModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Staff by id
    function get_staff_data($id = '')
    {
        $result = StaffModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Staff list
    function get_staff_list()
    {
        $result = StaffModel::where('status', 0)->orderBy('staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Name imgae user
    function name_image($ins = "A", $gender = 1)
    {
        // Array of all avatar divs
        if ($gender === 1) {
            $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-success'>" . $ins . "</span>
            </div>";
        } else if ($gender === 2) {
            $divs = "<div class='avatar  me-2'>
                <span class='avatar-initial rounded-circle bg-label-info'>" . $ins . "</span>
            </div>";
        } else {
            $divs = "<div class='avatar  me-2'>
              <span class='avatar-initial rounded-circle bg-label-warning'>" . $ins . "</span>
            </div>";
        }

        return $divs;
    }
  
   
    
    // Course Brand
    function get_course_brand_data($sno = '')
    {
        $result = BrandModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Course Group
    function get_course_group_data($sno = '')
    {
        $result = GroupModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Jobe Roll
    function get_course_job_role_data($sno = '')
    {
        $result = JobRollModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //pre skill set
    function get_course_pre_skill_data($sno = '')
    {
        $result = PreSkillSetModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //knowledge level list by id
    function get_knowledge_level_data($sno = '')
    {
        $result = KnowledgeLevelModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // knowledge level list
    function get_knowledge_level_list()
    {
        $result = KnowledgeLevelModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    
   
 
   
   

   
    function get_question_bank_count($id = '')
    {
        $result = ManageQuestionModel::where('question_bank_id', $id)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
   
    function exam_details($exam_id)
    {

        $results = ExamModel::select('*')->where('sno', $exam_id)->get();

        return $results;
    }
    // document type List
    function get_document_type_list()
    {
        $result = DocumentTypeModel::where('status', 0)->orderBy('documenttype_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // branch Category List
    function get_branch_category_list()
    {
        $result = BranchTypeModel::where('status', 0)->orderBy('branchtype_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Department List
    function get_department_list()
    {
        $result = DepartmentModel::where('status', 0)->orderBy('department_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch Category ID
    function get_branch_category_id($id = '')
    {
        $result = BranchTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch time zone ID
    function get_time_zone_id($id = '')
    {
        $result = TimeZoneModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    // branch currency format ID
    function get_currency_format_id($id = '')
    {
        $result = CurrencyFormatModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_department_id($id = '')
    {
        $result = DepartmentModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    //position
    function get_position_id($id = '')
    {
        $result = JobRoleModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Document By id
    function get_document_id($id = '')
    {
        $result = DocumentTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function absent_list_two_days()
    {

        $startDate = now()->subDays(2)->startOfDay();
        $endDate = now()->endOfDay();


        $attendance = StaffAttendanceModel::where('attendance', 'A')
            ->whereBetween('date', [$startDate, $endDate])
            ->pluck('staff_id');

        return $attendance;
    }

    function absent_list_seven_days()
    {

        $startDate = now()->subDays(7)->startOfDay();
        $endDate = now()->endOfDay();


        $attendance = StaffAttendanceModel::where('attendance', 'A')
            ->whereBetween('date', [$startDate, $endDate])
            ->pluck('staff_id');

        return $attendance;
    }


    // rosini
    function getFollowupCount($lead_id)
    {
        $lead =  AppointmentModel::select('*')->where('lead_id', $lead_id)->where('progressed', '=', 1)->count();

        return $lead ? $lead : 0;
    }
    function get_coupon_used_by_id($modal_id = "", $user_id = "")
    {

        if ($modal_id == 1) {
            $coupon_usage_history = ManageCouponHistoryModel::select(
                'egc_lead.lead_name as person_name',
                'egc_lead.lead_mobile as mobile_no'
            )
                ->leftJoin('egc_lead', 'egc_lead.sno', '=', 'egc_coupon_usage_history.used_by')
                ->where('egc_lead.sno', $user_id)
                ->first();
            if ($coupon_usage_history) {
                return '
            <label class="fw-semibold text-black fs-7">' . $coupon_usage_history->person_name . '</label>
            <div class="d-block">
                <label class="fw-semibold text-dark fs-8">' . $coupon_usage_history->mobile_no . '</label>
            </div>';
            }
        } elseif ($modal_id == 2) {

            $coupon_usage_history = ManageCouponHistoryModel::select(
                'egc_customer.cus_name as person_name',
                'egc_customer.cus_mobile as mobile_no'
            )
                ->leftJoin('egc_customer', 'egc_customer.sno', '=', 'egc_coupon_usage_history.used_by')
                ->where('egc_customer.sno', $user_id)
                ->first();
            if ($coupon_usage_history) {
                return '
              <label class="fw-semibold text-black fs-7">' . $coupon_usage_history->person_name . '</label>
              <div class="d-block">
                  <label class="fw-semibold text-dark fs-8">' . $coupon_usage_history->mobile_no . '</label>
              </div>';
            }
        }
    }
    function get_coupon()
    {

        $coupon_list = ManageCouponModel::select('*')
            ->where('egc_manage_coupon.public_check', 1)
            ->where('egc_manage_coupon.status', 0)
            ->get();


        return $coupon_list;
    }
    public function convertNumberToWords($number)
    {
        $words = [
            '0' => 'Zero',
            '1' => 'One',
            '2' => 'Two',
            '3' => 'Three',
            '4' => 'Four',
            '5' => 'Five',
            '6' => 'Six',
            '7' => 'Seven',
            '8' => 'Eight',
            '9' => 'Nine',
            '10' => 'Ten',
            '11' => 'Eleven',
            '12' => 'Twelve',
            '13' => 'Thirteen',
            '14' => 'Fourteen',
            '15' => 'Fifteen',
            '16' => 'Sixteen',
            '17' => 'Seventeen',
            '18' => 'Eighteen',
            '19' => 'Nineteen',
            '20' => 'Twenty',
            '30' => 'Thirty',
            '40' => 'Forty',
            '50' => 'Fifty',
            '60' => 'Sixty',
            '70' => 'Seventy',
            '80' => 'Eighty',
            '90' => 'Ninety'
        ];

        $suffixes = ['', 'Hundred', 'Thousand', 'Lakh', 'Crore'];

        // For numbers less than 21, we can directly return the word.
        if ($number < 21) {
            return $words[$number];
        }

        // Handle numbers less than 100
        elseif ($number < 100) {
            $tens = floor($number / 10) * 10;
            $ones = $number % 10;
            return $words[$tens] . ($ones ? ' ' . $words[$ones] : '');
        }

        // Handle numbers less than 1000
        elseif ($number < 1000) {
            $hundreds = floor($number / 100);
            $remainder = $number % 100;
            $wordsString = $words[$hundreds] . ' ' . $suffixes[1];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the thousands range
        elseif ($number < 100000) {
            $thousands = floor($number / 1000);
            $remainder = $number % 1000;
            $wordsString = $this->convertNumberToWords($thousands) . ' ' . $suffixes[2];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the lakhs range
        elseif ($number < 10000000) {
            $lakhs = floor($number / 100000);
            $remainder = $number % 100000;
            $wordsString = $this->convertNumberToWords($lakhs) . ' ' . $suffixes[3];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }

        // Handle numbers in the crores range
        elseif ($number < 1000000000) {
            $crores = floor($number / 10000000);
            $remainder = $number % 10000000;
            $wordsString = $this->convertNumberToWords($crores) . ' ' . $suffixes[4];
            if ($remainder) {
                $wordsString .= ' ' . $this->convertNumberToWords($remainder);
            }
            return $wordsString;
        }
    }
    public function batch_completed_days($id = '')
    {
        $customer_count = BatchHistoryModel::where('batch_id', $id)->where('attendance', 'P')->count();
        return $customer_count > 0 ? $customer_count : 0;
    }
    public function branch_franchise($id = '')
    {

        $branch_data = BranchModel::where('sno', $id)->first();

        if ($branch_data) {
            if ($branch_data->branch_type == 2) {
                return $branch_data->franchise_name;
            } else {
                return $branch_data->branch_name;
            }
        }
        return $branch_data;
    }
    function get_rules_data($id = '')
    {
        $user = StaffModel::select('egc_staff.*', 'egc_department.department_name', 'egc_sub_department.sub_department_name')
            ->leftJoin('egc_department', 'egc_staff.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_sub_department', 'egc_staff.sub_department_id', '=', 'egc_sub_department.sno')
            ->where('egc_staff.status', '!=', 2)
            ->where('egc_staff.sno', $id)
            ->first();


        $editcategory = Rules_guidelinesModel::select('egc_rules_guidelines.*', 'egc_department.department_name', 'egc_sub_department.sub_department_name')
            ->leftJoin('egc_department', 'egc_rules_guidelines.department_id', '=', 'egc_department.sno')
            ->leftJoin('egc_sub_department', 'egc_rules_guidelines.sub_dept_id', '=', 'egc_sub_department.sno')
            ->where('egc_rules_guidelines.status', '!=', 2)
            ->where('egc_department.sno', $user->department_id)
            ->where('egc_sub_department.sno', $user->sub_department_id)
            ->first();

        // return $editcategory;

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $editcategory
        ], 200);
    }
    

    // get financial year list
    function get_fin_yr()
    {
        $result = FinancialYearModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_fin_year_by_sno($id = '')
    {
        $result = FinancialYearModel::where('sno', $id)->where('status', 0)->first();

        // Check if a record was found
        if ($result !== null) {
            return $result; // Return the single instance
        } else {
            return null; // Return null if no results found
        }
    }
    // facility Roll
    function get_branch_staff_list($branch_id)
    {
        $result = StaffModel::where('status', 0)->where('branch_id', $branch_id)->orderBy('staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    function get_facility_data($sno = '')
    {
        $result = FacilityModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Shift time list
    function get_shift_time()
    {
        $result = ShiftTimeModel::where('status', 0)->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // get Shift time id
    function get_shift_time_id($sno = " ")
    {
        $result = ShiftTimeModel::where('sno', $sno)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }


    // ********************************* Rajkumar I Start **************************************
    // Get Hr Sub Branch 

    function get_hr_sub_branch($id = '')
    {
        $result = HrDirectoryBranchModel::where('company_id', $id)->where('status', 0)->get();
        return $result;
    }

    //interview type ID
    function get_interview_type_id($id = '')
    {
        $result = InterviewTypeModel::where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    // Company Hr Directory BY ID
    function get_company_hr_id($id = '')
    {
        $result = HrDirectoryModel::where('sno', $id)->first();
        // return $result;

        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    function get_total_vacancy_by_company_id($id = '')
    {
        // Retrieve all records for the given company ID
        $results = JobDirectoryModel::select('vacancy_count')->where('job_company_id', $id)->get();

        // Initialize total vacancy count
        $total_count_vacancy = 0;

        // Iterate through each result
        foreach ($results as $result) {
            // Decode JSON
            $vacancy_count = json_decode($result->vacancy_count, true);

            // Check if the decoded value is an array
            if (is_array($vacancy_count)) {
                // Sum the values
                $total_count_vacancy += array_sum($vacancy_count);
            }
        }

        return $total_count_vacancy; // Return the total count
    }


 

    function calculate_percentage($part, $total)
    {
        // dd($part, $total);
        if ($total == 0) {
            return 0; // Avoid division by zero
        }
        return ($part / $total) * 100;
    }
    function paymentnumberToWords($num)
    {
        $ones = [
            '',
            'First',
            'Second',
            'Third',
            'Fourth',
            'Fifth',
            'Sixth',
            'Seventh',
            'Eighth',
            'Ninth',
            'Tenth',
            'Eleventh',
            'Twelfth',
            'Thirteenth',
            'Fourteenth',
            'Fifteenth',
            'Sixteenth',
            'Seventeenth',
            'Eighteenth',
            'Nineteenth'
        ];

        $tens = [
            '',
            '',
            'Twentieth',
            'Thirtieth',
            'Fortieth',
            'Fiftieth',
            'Sixtieth',
            'Seventieth',
            'Eightieth',
            'Ninetieth'
        ];

        $thousands = ['', 'Thousand'];

        // Return "Initial" for zero payment
        if ($num == 0) {
            return 'Initial';
        }

        $words = '';

        if ($num >= 1000) {
            $words .= $ones[intval($num / 1000)] . ' ' . $thousands[1] . ' ';
            $num %= 1000;
        }

        if ($num >= 100) {
            $words .= $ones[intval($num / 100)] . ' Hundred ';
            $num %= 100;
        }

        if ($num >= 20) {
            $words .= $tens[intval($num / 10)] . ' ';
            $num %= 10;
        }

        if ($num > 0) {
            $words .= $ones[$num] . ' ';
        }

        return trim($words);
    }

    function get_verify_activity_count($id = '')
    {
        $count = MarketingModel::where('status', 0)
            ->where('sno', $id)
            ->first();

        if ($count !== null) {
            return $count;
        } else {
            return null;
        }
    }


    // ********************************* Rajkumar I End **************************************
    function get_total_interested_by_job_id($id = " ")
    {
        $results = CustomerPlacementModel::where('job_name_id', $id)->get(); // To get the records
        $results_count = $results->count(); // To get the count of records
        // dd($results_count);


        return $results_count;
    }


    function GRADE_LOGO_PIC_PATH($pic)
    {
        if ($pic) {
            return url('grade_logo/' . $pic);
        } else {
            return '';
        }
    }


    function get_profile_image_url($staff_image, $default = 'assets/eapl_images/Super-Admin.png')
    {
        $path = public_path($staff_image);
        return file_exists($path) ? asset($staff_image) : asset($default);
    }
    // material type name by id
    function get_material_typeName($sno = '')
    {
        // return $sno;
        $result = MaterialTypeModel::where('sno', $sno)->value('material_type_name');
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }

    //here need create helfer funtion for notification message from notification type based to fetch 

    public function createNotification(array $data, $notificationtype)
    {
        // Step 1: Find the Notification Type based on the name
        $notificationType = NotificationTypeModel::where('notification_type', $notificationtype)->first();

        // Check if notification type exists and proceed
        if ($notificationType) {
            // Decode the JSON string array of roles
            $rolesArray = json_decode($notificationType->notification_roles, true);

            // Step 2: Fetch staff based on branch, status, and roles array
            $staffMembers = StaffModel::where('branch_id', $data['branch_id'])
                ->where('status', 0) // Assuming 0 is the active status
                ->whereIn('role_id', $rolesArray)
                ->get();

            // Step 3: Prepare notifications for each staff member
            $notifications = [];
            foreach ($staffMembers as $staff) {
                $notificationData = [
                    'branch_id'            => $data['branch_id'] ?? 0,
                    'notification_type_id' => $notificationType->sno,
                    'notification_type'    => $data['notification_type'] ?? $notificationType->notification_type,
                    'notification_content' => $data['notification_content'],
                    'notification_date'    => now(),
                    'who'                  => $data['who'] ?? '0',
                    'whom'                 => $staff->sno,
                    'created_by'           => $data['created_by'] ?? 0,
                    'updated_by'           => $data['updated_by'] ?? 0,
                    'status'               => $data['status'] ?? 0
                ];

                // Insert the notification and store the result
                $notifications[] = NotificationModel::create($notificationData);
            }

            return $notifications; // Return all created notifications
        }

        // Return null if notification type was not found
        return null;
    }
    //   AK max
    // incoming call
    function incoming_call_count($staff_id)
    {
        $incoming_call_count = DB::table('egc_call_tracker')->select('egc_call_tracker.sno')
            ->where('egc_call_tracker.branch_staff_id', $staff_id)
            // ->where('a.call_date >=', $call_start_date)
            // ->where('a.call_date <=', $call_end_date)
            ->where('egc_call_tracker.call_status', 1)        // Status is 1
            ->count();

        return $incoming_call_count ? $incoming_call_count : 0;
    }

    // outcoming_call
    function outcoming_call_count($staff_id)
    {
        $outgoingcall_count = DB::table('egc_call_tracker')->select('egc_call_tracker.sno')
            ->where('egc_call_tracker.branch_staff_id', $staff_id)        // Filter by user ID
            // ->where('egc_call_tracker.call_date >=', $call_start_date)
            // ->where('egc_call_tracker.call_date <=', $call_end_date)

            ->where('egc_call_tracker.call_status', 0)                  // Status is 0
            ->where('egc_call_tracker.call_duration', '!=', '00:00:00') // Duration is not '00:00:00'
            ->count();

        return $outgoingcall_count ? $outgoingcall_count : 0;
    }

    // missed_call
    function missed_call_count($staff_id)
    {
        $missedcall_count = DB::table('egc_call_tracker')->select('egc_call_tracker.sno')
            ->where('egc_call_tracker.branch_staff_id', $staff_id) // Filter by user ID
            // ->where('egc_call_tracker.call_date >=', $call_start_date)
            // ->where('egc_call_tracker.call_date <=', $call_end_date)

            ->where('egc_call_tracker.call_status', 2)
            ->count();

        return $missedcall_count ? $missedcall_count : 0;
    }

    // rejected_call
    function rejected_call_count($staff_id)
    {
        $rejected_call = DB::table('egc_call_tracker')->select('egc_call_tracker.sno')
            ->where('egc_call_tracker.branch_staff_id', $staff_id) // Filter by user ID
            // ->where('egc_call_tracker.call_date >=', $call_start_date)
            // ->where('egc_call_tracker.call_date <=', $call_end_date)
            ->where('egc_call_tracker.call_status', 3)           // Status is 3 for rejected calls
            ->count();

        return $rejected_call ? $rejected_call : 0;
    }




    // incoming call lead
    function incoming_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('egc_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('egc_contact_book.contact_book_id', 'desc')->first();

        $contact_book_id     = $contact_book->contact_book_id ?? '0';
        $incoming_call_count = DB::table('egc_call_log')
            ->join('egc_contact_book', 'egc_call_log.contact_book_id', '=', 'egc_contact_book.contact_book_id')
            ->where('egc_call_log.contact_book_id', $contact_book_id)
            // ->where('a.call_date >=', $call_start_date)
            // ->where('a.call_date <=', $call_end_date)
            ->where('egc_call_log.redirected_to', 0) // Redirected to 0
            ->where('egc_call_log.status', 1)        // Status is 1
            ->count();

        return $incoming_call_count ? $incoming_call_count : 0;
    }

    // outcoming_call lead
    function outcoming_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('egc_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('egc_contact_book.contact_book_id', 'desc')->first();
        $contact_book_id    = $contact_book->contact_book_id ?? '0';
        $outgoingcall_count = DB::table('egc_call_log')
            ->join('egc_contact_book', 'egc_call_log.contact_book_id', '=', 'egc_contact_book.contact_book_id')
            ->where('egc_call_log.contact_book_id', $contact_book_id) // Filter by user ID
            // ->where('egc_call_log.call_date >=', $call_start_date)
            // ->where('egc_call_log.call_date <=', $call_end_date)
            ->where('egc_call_log.redirected_to', 0)                  // Redirected to 0
            ->where('egc_call_log.status', 0)                         // Status is 0
            ->where('egc_call_log.duration', '!=', '00:00:00')        // Duration is not '00:00:00'
            ->count();

        return $outgoingcall_count ? $outgoingcall_count : 0;
    }

    // missed_call lead
    function missed_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('egc_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('egc_contact_book.contact_book_id', 'desc')->first();

        $contact_book_id  = $contact_book->contact_book_id ?? '0';
        $missedcall_count = DB::table('egc_call_log')
            ->join('egc_contact_book', 'egc_call_log.contact_book_id', '=', 'egc_contact_book.contact_book_id')
            ->where('egc_call_log.contact_book_id', $contact_book_id)
            // ->where('egc_call_log.call_date >=', $call_start_date)
            // ->where('egc_call_log.call_date <=', $call_end_date)
            ->where('egc_call_log.redirected_to', 0) // Redirected to 0
            ->where('egc_call_log.status', 2)        // Status is 2 for missed calls
            ->where('egc_call_log.missed_status', 0) // Missed status is 0
            ->count();

        return $missedcall_count ? $missedcall_count : 0;
    }

    // rejected_call lead
    function rejected_call_count_mob($mobile)
    {
        $normalizedPhoneNo    = ltrim($mobile, '0'); // Remove leading zero if present
        $phoneWithCountryCode = '+91' . $normalizedPhoneNo;

        $contact_book = DB::table('egc_contact_book')->where('phone_no', $mobile)
            ->orWhere('phone_no', $phoneWithCountryCode)
            ->orderBy('egc_contact_book.contact_book_id', 'desc')->first();

        $contact_book_id = $contact_book->contact_book_id ?? '0';
        $rejected_call   = DB::table('egc_call_log')
            ->join('egc_contact_book', 'egc_call_log.contact_book_id', '=', 'egc_contact_book.contact_book_id')
            ->where('egc_call_log.contact_book_id', $contact_book_id)
            // ->where('egc_call_log.call_date >=', $call_start_date)
            // ->where('egc_call_log.call_date <=', $call_end_date)
            ->where('egc_call_log.redirected_to', 0) // Redirected to 0
            ->where('egc_call_log.status', 3)        // Status is 3 for rejected calls
            ->count();

        return $rejected_call ? $rejected_call : 0;
    }

   


    function convertFromINR($targetCurrency)
    {
        $accessKey = 'c38c8b247356f247c551f252db1bfc3a';
        $api_key = 'cur_live_eFtAAPwYAI2xWoBgFCqsB0FsOma21R9kEgpEsHV1';
        $endpoint = 'convert';



        $response = Http::get("https://api.currencyapi.com/v3/latest?apikey={$api_key}&currencies={$targetCurrency}&base_currency=INR");


        // $response = Http::get("https://api.exchangerate.host/{$endpoint}", [
        //     'access_key' => $accessKey,
        //     'from' => 'INR',
        //     'to' => $targetCurrency,
        //     'amount' => $amountInR,
        // ]);

        if ($response->successful()) {
            $data = $response->json();
            return [
                'exchange_rate' => $data['data'][$targetCurrency]['value'] ?? null,
            ];
            // return [
            //     'converted_amount' => $data['result'] ?? null,
            //     'exchange_rate' => $data['info']['rate'] ?? null,
            //     'exchange_quote' => $data['info']['quote'] ?? null,
            // ];
        } else {
            return  null;
            // return [
            //         'converted_amount' =>  null,
            //         'exchange_rate' => null,
            //         'exchange_quote' =>  null,
            //     ];
        }
    }
    function ConvertedAmount($exchange_quote, $amount)
    {
        $converted_amount = ($exchange_quote != 0) ? $amount * $exchange_quote : 0;
        return $converted_amount;
    }
    //New
    function staff_details($sno)
    {
        $result = StaffModel::select('egc_staff.sno', 'egc_staff.branch_id', 'egc_staff.staff_image', 'egc_staff.status', 'egc_staff.staff_name', 'egc_job_role.job_position_name')
            ->leftJoin('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.position_role')
            ->where('egc_staff.status', 0)
            ->where('egc_staff.sno', $sno)
            ->orderBy('egc_staff.staff_name', "ASC")->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
 

    function get_branch_sales_staff_list($branch_id)
    {
        $result = StaffModel::select('egc_staff.sno', 'egc_staff.branch_id', 'egc_staff.status', 'egc_staff.staff_name', 'egc_job_role.job_position_name')
            ->leftJoin('egc_job_role', 'egc_job_role.sno', '=', 'egc_staff.position_role')
            ->where('egc_staff.status', 0)
            ->where('egc_staff.department_id', 1)
            ->where('egc_staff.branch_id', $branch_id)
            ->orderBy('egc_staff.staff_name', "ASC")->get();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }




   
   // Get Branch and Franchise list based on user_id
  function get_branch_control_list_user($user_id)
  {
    // Fetch the user based on user_id
    $user = StaffModel::where('sno', $user_id)->first();

    if ($user && $user->sno == 124) {
      $branches = BranchModel::whereNotIn('sno', [1])
        ->where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();

      return ['branches' => $branches, 'franchises' => $franchises];
    } elseif ($user !== null) {
      // Decode multi_branch_access column (assuming it's a JSON array like ["1","2"])
      $accessibleBranches = json_decode($user->multi_branch_access, true);

      if (!empty($accessibleBranches)) {
        // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
        $branches = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 1)
          ->get();

        $franchises = BranchModel::whereIn('sno', $accessibleBranches)
          ->where('status', 0)
          ->where('branch_type', 2)
          ->get();

        return ['branches' => $branches, 'franchises' => $franchises];
      }
    } else {
      // Fetch branches (branch_type = 1) and franchises (branch_type = 2) that match allowed branch IDs
      $branches = BranchModel::where('status', 0)
        ->where('branch_type', 1)
        ->get();

      $franchises = BranchModel::where('status', 0)
        ->where('branch_type', 2)
        ->get();
      return ['branches' => $branches, 'franchises' => $franchises];
    }
  }
  
 
    
    function get_employee_skill_by_id($id = '')
    {
        $result = DB::table('egc_employee_skill')->where('status', 0)->where('sno', $id)->first();
        if ($result !== null) {
            return $result;
        } else {
            return null;
        }
    }
    
    function get_Qbank_section_count($id)
{
    $data = DB::table('egc_exam_questions')
        ->where('bank_id', $id)
        ->distinct('section_id')  // only unique sections
        ->count('section_id');

    return $data;
}

    function getCurrencyRate($targetCurrency, $sourceCurrency = 'INR')
    {
        try {
            // Define API key (ideally should be in an environment variable)
           
            $api_key = 'cur_live_eFtAAPwYAI2xWoBgFCqsB0FsOma21R9kEgpEsHV1';
            // Make the API request
            $response = Http::get("https://api.currencyapi.com/v3/latest", [
                'apikey' => $api_key,
                'currencies' => $sourceCurrency,
                'base_currency' => $targetCurrency
            ]);
        // return $response;
            // Check if the response is successful
            if ($response->successful()) {
                // Get the conversion rate from the response
                $rate = $response->json()['data'][$sourceCurrency]['value'] ?? null;
    
                // Ensure rate is found
                if ($rate) {
                    return $rate;
                } else {
                    throw new \Exception("Rate not found for {$sourceCurrency} to {$targetCurrency}");
                }
            } else {
                throw new \Exception("Error fetching currency data: " . $response->status());
            }
        } catch (\Exception $e) {
            // Handle the error (you can log it, rethrow, or return a default value)
            \Log::error("Currency API Error: " . $e->getMessage());
            return null; // Or a default rate if you prefer
        }
    }
    
     function ConvertedAmountInr($currency_code, $amount)
    {
         $currencyRate = CurrencyRateModel::orderBy('sno', 'desc')->first();
             $rate = 1 ;
            if($currencyRate){
                $currencyData = json_decode($currencyRate->currency_data, true);
                
                $code = $currency_code;
    
                if (isset($currencyData[$code]) && $currencyData[$code] != 0) {
                    $rate = 1 / $currencyData[$code]; // Convert to INR
                } else {
                    $rate = 1; // Handle missing or zero rate
                }
               
            }
        $converted_amount = ($rate != 0) ? $amount * $rate : 0;
        $rounded = round($converted_amount, 2);
        return $rounded;
    }
    
    function ConvertedAmountAny($from_currency, $to_currency, $amount)
    {
        $currencyRate = CurrencyRateModel::orderBy('sno', 'desc')->first();
        $rateFrom = 1;
        $rateTo   = 1;
    
        if ($currencyRate) {
            $currencyData = json_decode($currencyRate->currency_data, true);
    
            // Rate for "from" currency
            if (isset($currencyData[$from_currency]) && $currencyData[$from_currency] != 0) {
                $rateFrom = $currencyData[$from_currency];
            }
    
            // Rate for "to" currency
            if (isset($currencyData[$to_currency]) && $currencyData[$to_currency] != 0) {
                $rateTo = $currencyData[$to_currency];
            }
        }
    
        // Convert to INR first, then to target currency
        $amountInInr = $amount / $rateFrom;  
        $converted   = $amountInInr * $rateTo; 
    
        return round($converted, 2);
    }

      public function showTicker($branch_id = '', $role_id = '')
    {
        $now = \Carbon\Carbon::now();
    
        $ticker = DB::table('egc_news_broadcast')
            ->where('status', 0)
             ->whereJsonContains('branch_id', (string) $branch_id) // cast to string if stored as strings
        ->whereJsonContains('role_ids', (string) $role_id)  
            ->where('start_date', '<=', $now)
            ->where('end_date', '>=', $now)
            ->orderBy('sno', 'desc')
            ->first();
    
        if ($ticker) {
            $settings = json_decode($ticker->theme_style, true);
            $news = json_decode($ticker->information, true);
    
            // Attach news data to settings (plugin expects "data")
            $settings['data'] = $news ?? [];
            return $settings;
        }
    
        return null;
    }

}