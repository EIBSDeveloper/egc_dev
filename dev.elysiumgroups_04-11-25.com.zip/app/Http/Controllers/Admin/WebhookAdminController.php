<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use Illuminate\Http\Request;

class WebhookAdminController extends Controller
{
    public function index(Request $request)
    {
         $page = $request->input('page', 1);
        $perpage = (int) $request->input('sorting_filter', 25);
        $offset = ($page - 1) * $perpage;
        $search_filter = $request->search_filter ?? '';
        $webhooks = WebhookDispatchModel::with('attemptLogs')
            ->orderBy('created_at', 'desc')
            ->paginate($perpage);

        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $webhooks->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'url' => $item->webhook->url ?? 'N/A',
                    'attempts' => $item->attempts,
                    'last_response' => $item->last_response,
                    'last_attempt_at' => $item->last_attempt_at,
                    'next_attempt_at' => $item->next_attempt_at,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $webhooks->currentPage(),
                'last_page' => $webhooks->lastPage(),
                'total' => $webhooks->total(),
            ]);
        }

        return view('content.admin.webhooks.webhooks_list', [
            'webhooks' => $webhooks,
            'perpage' => $perpage,
            'search_filter' => $search_filter,
        ]);
    }

    public function retry($id)
    {
        $dispatch = WebhookDispatchModel::findOrFail($id);

        if ($dispatch->status !== 2) { // only retry failed or pending
            SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
            // Only update status to 'processing', leave last_response as-is
            $dispatch->update(['status' => 1]); 
            broadcast(new WebhookDispatchedEvent($dispatch));
        }

        return redirect()->back()->with('success', 'Webhook retried successfully.');
    }
}
