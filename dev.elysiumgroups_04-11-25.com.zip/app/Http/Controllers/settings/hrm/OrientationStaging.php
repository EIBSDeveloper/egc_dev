<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class OrientationStaging extends Controller
{
    public function index()
    {
        return view(
            'content.settings.hrm.orientation_staging.orientation_staging_list');
    }

}
