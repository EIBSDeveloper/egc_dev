<?php

namespace App\Http\Controllers\control_panel\user_management;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;

class ManageUsers extends Controller
{
  public function index()
  {
    // $userpermission = UserRolePermissionModel::where('eibs_user_role_permission.status', '!=', 2)
    //   ->join('eibs_user_role', 'eibs_user_role_permission.role_id', '=', 'eibs_user_role.sno')
    //   ->select(
    //     'eibs_user_role_permission.sno',
    //     'eibs_user_role.sno as role_id',
    //     'eibs_user_role.role_name',
    //     'eibs_user_role_permission.status'
    //   )
    //   ->get();
    return view('content.control_panel.user_management.manage_users.manage_users_list');
  }
}