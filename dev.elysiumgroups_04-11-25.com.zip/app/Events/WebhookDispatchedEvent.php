<?php
namespace App\Events;

use App\Models\WebhookDispatchModel;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class WebhookDispatchedEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $dispatch;

    public function __construct(WebhookDispatchModel $dispatch)
    {
        $this->dispatch = $dispatch;
    }

    public function broadcastOn()
    {
        return new Channel('webhooks'); 
    }

    public function broadcastWith()
    {
        return [
            'id' => $this->dispatch->sno,
            'status' => $this->dispatch->status,
            'attempts' => $this->dispatch->attempts,
            'last_response' => $this->dispatch->last_response,
            'next_attempt_at' => $this->dispatch->next_attempt_at,
        ];
    }
}
