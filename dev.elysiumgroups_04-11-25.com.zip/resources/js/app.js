/*
  Add custom scripts here
*/
import './socket';
import.meta.glob([
  '../assets/img/**',
  './socket',
  // '../assets/json/**',
  '../assets/vendor/fonts/**'
]);
