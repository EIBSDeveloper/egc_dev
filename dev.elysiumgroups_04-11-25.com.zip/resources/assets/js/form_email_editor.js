'use strict';

(function () {
  // ✅ Allow inline style attributes in Quill
  const Parchment = Quill.import('parchment');

  class StyleAttributor extends Parchment.Attributor.Style {
    add(node, value) {
      node.style.setProperty(this.keyName, value);
      return true;
    }
  }

  // ✅ Register commonly used inline styles
  const ColorStyle = new StyleAttributor('color', 'color', { scope: Parchment.Scope.INLINE });
  const BgColorStyle = new StyleAttributor('background', 'background-color', { scope: Parchment.Scope.INLINE });
  const TextDecoration = new StyleAttributor('textdecoration', 'text-decoration', { scope: Parchment.Scope.INLINE });
  const FontSizeStyle = new StyleAttributor('fontsize', 'font-size', { scope: Parchment.Scope.INLINE });
  const PaddingStyle = new StyleAttributor('padding', 'padding', { scope: Parchment.Scope.INLINE });
  const BorderRadiusStyle = new StyleAttributor('borderradius', 'border-radius', { scope: Parchment.Scope.INLINE });

  Quill.register(ColorStyle, true);
  Quill.register(BgColorStyle, true);
  Quill.register(TextDecoration, true);
  Quill.register(FontSizeStyle, true);
  Quill.register(PaddingStyle, true);
  Quill.register(BorderRadiusStyle, true);

  // Toolbar options
  const CreatefullToolbar = [
    [{ font: [] }, { size: [] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ color: [] }, { background: [] }],
    [{ script: 'super' }, { script: 'sub' }],
    [{ header: '1' }, { header: '2' }, 'blockquote', 'code-block'],
    [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }],
    [{ direction: 'rtl' }],
    ['link', 'image', 'video', 'formula'],
    ['clean']
  ];

  // Initialize Quill
  const CreatefullEditor = new Quill('#create_exam_guideline_editor', {
    bounds: '#create_exam_guideline_editor',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: CreatefullToolbar
    },
    theme: 'snow'
  });

  // Add custom HTML View button
  const toolbar = CreatefullEditor.getModule('toolbar');
  const buttonContainer = toolbar.container;

  const htmlButton = document.createElement('button');
  htmlButton.setAttribute('type', 'button');
  htmlButton.setAttribute('class', 'ql-htmlView');
  htmlButton.innerHTML = '<i class="mdi mdi-file-code"></i>'; // or use any icon
  buttonContainer.appendChild(htmlButton);

  // Toggle logic
  let isHtmlView = false;
  let htmlEditor = null;

  htmlButton.addEventListener('click', function () {
    const editorContainer = document.querySelector('#create_exam_guideline_editor');
    const editorElem = editorContainer.querySelector('.ql-editor');

    if (!isHtmlView) {
      // Show HTML textarea
      const htmlContent = CreatefullEditor.root.innerHTML;

      htmlEditor = document.createElement('textarea');
      htmlEditor.setAttribute('id', 'html-temp-editor');
      htmlEditor.style.width = '100%';
      htmlEditor.style.height = '300px';
      htmlEditor.style.marginTop = '10px';
      htmlEditor.value = htmlContent;

      editorElem.style.display = 'none';
      editorContainer.appendChild(htmlEditor);
    } else {
      // Save back HTML to Quill
      const updatedHtml = htmlEditor.value;
      CreatefullEditor.clipboard.dangerouslyPasteHTML(updatedHtml);

      htmlEditor.remove();
      htmlEditor = null;

      editorElem.style.display = '';
    }

    isHtmlView = !isHtmlView;
  });
})();
