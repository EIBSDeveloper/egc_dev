<!DOCTYPE html>
@php
$menuFixed = ($configData['layout'] === 'vertical') ? ($menuFixed ?? '') : (($configData['layout'] === 'front') ? '' : $configData['headerType']);
$navbarType = ($configData['layout'] === 'vertical') ? $configData['navbarType']: (($configData['layout'] === 'front') ? 'layout-navbar-fixed': '');
$isFront = ($isFront ?? '') == true ? 'Front' : '';
$contentLayout = (isset($container) ? (($container === 'container-xxl') ? "layout-compact" : "layout-wide") : "");
@endphp

<html lang="{{ session()->get('locale') ?? app()->getLocale() }}" class="{{ $configData['style'] }}-style {{($contentLayout ?? '')}} {{ ($navbarType ?? '') }} {{ ($menuFixed ?? '') }} {{ $menuCollapsed ?? '' }} {{ $menuFlipped ?? '' }} {{ $menuOffcanvas ?? '' }} {{ $footerFixed ?? '' }} {{ $customizerHidden ?? '' }}" dir="{{ $configData['textDirection'] }}" data-theme="{{ $configData['theme'] }}" data-assets-path="{{ asset('/assets') . '/' }}" data-base-url="{{url('/')}}" data-framework="laravel" data-template="{{ $configData['layout'] . '-menu-' . $configData['themeOpt'] . '-' . $configData['styleOpt'] }}">

  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>EGC&#174; | @yield('title') </title>
    <meta name="description" content="{{ config('variables.templateDescription') ? config('variables.templateDescription') : '' }}" />
    <meta name="keywords" content="{{ config('variables.templateKeyword') ? config('variables.templateKeyword') : '' }}">
    <!-- laravel CRUD token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Canonical SEO -->
    <link rel="canonical" href="{{ config('variables.productPage') ? config('variables.productPage') : '' }}">
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('assets/common/logo_small.png') }}" />

    <!-- Add this in the <head> section of your HTML -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" />

    <link href="{{url ('assets/custom_file/swal2.css')}}" rel="stylesheet" type="text/css" />

    <!-- Include Flatpickr CSS & JS (if not already included) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
      
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- CSS
    <link rel="stylesheet" href="{{ asset('resources/assets/vendor/libs/bs-stepper/bs-stepper.css') }}">
    <link rel="stylesheet" href="{{ asset('resources/assets/vendor/libs/animate-css/animate.css') }}"> -->
    <!-- <link rel="stylesheet" href="{{ asset('resources/assets/vendor/libs/sweetalert2/sweetalert2.css') }}"> -->
    <!-- <link rel="stylesheet" href="{{ asset('resources/assets/vendor/libs/tagify/tagify.css') }}">
    <link rel="stylesheet" href="{{ asset('resources/assets/vendor/libs/nouislider/nouislider.css') }}"> -->
    @vite([
      'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss',
      'resources/assets/vendor/libs/animate-css/animate.scss',
      'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
      'resources/assets/vendor/libs/tagify/tagify.scss',
      'resources/assets/vendor/libs/nouislider/nouislider.scss',
    ])

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.11/clipboard.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
    <!-- <script src="{{ asset('resources/assets/vendor/libs/nouislider/nouislider.js') }}"></script>
    <script src="{{ asset('resources/assets/vendor/libs/sweetalert2/sweetalert2.js') }}"></script>
    <script src="{{ asset('resources/assets/vendor/libs/tagify/tagify.js') }}"></script>
    <script src="{{ asset('resources/assets/vendor/libs/bs-stepper/bs-stepper.js') }}"></script> -->
    @vite([
      'resources/assets/vendor/libs/nouislider/nouislider.js',
      'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
      'resources/assets/vendor/libs/tagify/tagify.js',
      'resources/assets/vendor/libs/bs-stepper/bs-stepper.js',
    ])

    <!-- Include Styles -->
    <!-- $isFront is used to append the front layout styles only on the front layout otherwise the variable will be blank -->
    @include('layouts/sections/styles' . $isFront)
    <style>
      .txt_vertical {
        writing-mode: vertical-lr;
      }

      .download-image {
        /* background-image:url('{{ asset('/assets/egc_images/default_doc.png') }}'); */
        position: relative;
        background-size: cover;
        background-position: center;
      }

      .dataTables_scroll {
        position: relative;
        overflow: auto;
        /* max-height: 218px; */
        /*the maximum height you want to achieve*/
        width: 100%;
      }

      .dataTables_scroll thead {
        position: -webkit-sticky;
        position: sticky;
        top: 0;
        /* background-color: #ec9629 !important; */
        z-index: 2;
      }

      .text-justify {
        text-align: justify !important;
      }
    </style>
    <style>
      .scroll-container-wrapper {
        position: relative;
        display: flex;
        align-items: center;
        max-width: 100%;
        overflow: hidden;
      }


      .scroll-container {
        display: flex;
        overflow-x: auto;
        scroll-behavior: smooth;
        gap: 10px;
        padding: 0 40px;
        list-style: none;
      }

      .scroll-container::-webkit-scrollbar {
        display: none;
      }

      .item {
        flex: 0 0 auto;
        position: relative;
      }

      .scroll-link.active {
        position: relative;
      }

      .scroll-link.active::after {
        content: '';
        position: absolute;
        bottom: 0; /* place at bottom of link */
        left: 0;
        width: 100%;
        height: 3px;
        background-color: #ab2b22;
        border-radius: 2px;
      }

      .scroll-btn {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: #ab2b22;
        border: none;
        border-radius: 50%;
        padding: 5px;
        cursor: pointer;
        z-index: 10;
        display: none;
      }

      .scroll-btn.left { left: 0px; }
      .scroll-btn.right { right: 0px; }

      .scroll-arrow {
        width: 2rem;
        height: 2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
      }
      .custom-breadcrumb {
          background-color: #f8f9fa; /* White background */
          padding: 0.5rem 1rem;
          border-radius: 0.25rem;
          display: flex;
          align-items: center;
          list-style: none;
      }

      .custom-breadcrumb .breadcrumb-item {
          display: flex;
          align-items: center;
          font-size: 0.9rem;
          font-weight: 500;
      }

      .custom-breadcrumb .breadcrumb-item + .breadcrumb-item::before {
          content: '/'; /* Separator */
          padding: 0 0.5rem;
          color: #6c757d;
      }

      .custom-breadcrumb .active-link {
          color: #ab2b22 !important;
          text-decoration: none;
          font-weight: 500;
      }

      .custom-breadcrumb .breadcrumb-item a {
          color: #495057; 
          text-decoration: none;
      }

      .custom-breadcrumb .breadcrumb-item a:hover {
          text-decoration: underline;
      }
     
      /* .searchBar {
          width: 100%;
          display: flex;
          flex-direction: row;
          align-items: center;
      }

      .searchQueryInput {
          width: 100%;
          height: 2.8rem;
          background: #f5f5f5;
          outline: none;
          border: none;
          border-radius: 0.5rem;
          padding: 0 3.5rem 0 1.5rem;
          font-size: 1rem;
      }

      .searchQuerySubmit {
          width: 3.5rem;
          height: 1.2rem;
          margin-left: -2.5rem;
          background: none;
          border: none;
          outline: none;
      }

      .searchQuerySubmit:hover {
          cursor: pointer;
      } */

      .searchBar {
          width: 100%;
          display: flex;
          flex-direction: row;
          align-items: center;
          position: relative;
      }

      


      .searchQueryInput {
          width: 100%;
          height: 2.8rem;
          background: #f5f5f5;
          outline: none;
          border: none;
          border-radius: 0.5rem;
          padding: 0 6rem 0 1.5rem; /* extra space for 2 icons */
          font-size: 1rem;
      }

      .searchQuerySubmit {
          background: none;
          border: none;
          outline: none;
      }
      .searchAction {
          position: absolute;
          background: none;
          border: none;
          outline: none;
          right:0;
      }
      .searchQuerySubmit {
          background: none;
          border: none;
          outline: none;
      }

      
      .searchSubmit, .refreshBar {
            padding: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-left: 5px;
        }

        .searchSubmit:hover, .refreshBar:hover {
            background-color: #f5f5f5;
            border-radius: 50%;
        }

        .searchSubmit {
            background-color: transparent;
        }

        .refreshBar {
            background-color: transparent;
            display: none; /* Hidden initially */
        }

        .searchQueryInput:focus + .searchAction .searchSubmit {
            background-color: #f5f5f5;
        }

        .searchQueryInput:focus + .searchAction .refreshBar {
            display: block;
        }

        /* Optional: Adding a smooth transition for the search icon and refresh icon */
        .searchSubmit, .refreshBar {
            transition: transform 0.2s ease;
        }

        .searchSubmit:hover, .refreshBar:hover {
            transform: scale(1.2);
            background:none;
        }

      .searchIcon {
          right: 3rem; /* search stays left of refresh */
      }

      .refreshIcon {
          right: 0.8rem; /* refresh at far right */
      }

      .searchQuerySubmit:hover {
          cursor: pointer;
      }

      .avatar-stack {
          display: flex;
          align-items: center;
      }

      .avatar-img {
          width: 45px;
          height: 45px;
          border-radius: 50%;
          border: 2px solid #ab2b22;
          margin-left: -12px; /* overlap */
          box-shadow: 0 4px 8px rgba(0,0,0,0.2); /* 3D shadow */
          transform: perspective(500px) rotateY(-10deg); /* slight 3D tilt */
          transition: transform 0.3s ease, box-shadow 0.3s ease;
      }

      .avatar-img:first-child {
          margin-left: 0; /* prevent first from shifting */
      }

      .avatar-img:nth-child(2) {
          z-index: 3; /* center one always on top */
      }

      .avatar-img:hover {
          transform: perspective(500px) rotateY(0deg) scale(1.1);
          box-shadow: 0 6px 12px rgba(0,0,0,0.3);
          z-index: 2; /* bring hovered one on top */
      }

      .loading {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.8);
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
      }

      .dot {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        display: inline-block;
        animation: bounce 1.4s infinite ease-in-out;
        margin: 0 5px;
      }

      /* Colors */
      .dot.red    { background: #F58323; animation-delay: 0s;   }
      .dot.orange { background: #E31C3B; animation-delay: 0.2s; }
      .dot.yellow { background: #3B4850; animation-delay: 0.4s; }
      .dot.green  { background: #0D6AAF; animation-delay: 0.6s; }
      .dot.teal   { background: #169DD7; animation-delay: 0.8s; }
      .dot.blue   { background: #6AB745; animation-delay: 0.10s; }
      .dot.violet { background: #FCB831; animation-delay: 0.12s; }

      @keyframes bounce {
        0%, 80%, 100% { transform: scale(0.6); opacity: 0.6; }
        40% { transform: scale(1); opacity: 1; }
      }


    </style>

    <style>
    .skeleton-loader {
        /*display: flex;*/
        /*flex-direction: row;*/
        /*gap: 10px;*/
    }

    .skeleton-row {
        display: flex;
        flex-direction: row;
        gap: 10px;
    }

    .skeleton {
        width: 100%;
        height: 30px; /* Adjust height as needed */
        background: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
        background-size: 200% 100%;
        border-radius: 4px;
        animation: loading 1.2s infinite;
    }

    .skeleton-cell {
        flex: 1;
        height: 40px; /* Match the row height */
    }

    /*@keyframes loading {*/
    /*    0% { background-position: 200% 0; }*/
    /*    100% { background-position: -200% 0; }*/
    /*}*/
    
    .skeleton-loader-view {
            background-color: #e0e0e0;
            background-image: linear-gradient(90deg, #e0e0e0 25%, #f0f0f0 50%, #e0e0e0 75%);
            background-size: 200% 100%;
            animation: loading 1.2s infinite;
            border-radius: 4px;
            height: 20px;
        }
        
        .skeleton-loader-view.max-w-75 {
            width: 75%;
        }
        
        @keyframes loading {
            0% {
                background-position: -200% 0;
            }
            100% {
                background-position: 200% 0;
            }
        }
</style>


    <!-- Include Scripts for customizer, helper, analytics, config -->
    <!-- $isFront is used to append the front layout scriptsIncludes only on the front layout otherwise the variable will be blank -->
    @include('layouts/sections/scriptsIncludes' . $isFront)

  </head>
  {{-- <script src="assets/vendor/libs/select2/select2.js"></script> --}}

  <script src="{{url ('assets/custom_file/jquery-3.7.1.js')}}"></script>
  <script src="{{url ('assets/custom_file/dataTables.js')}}"></script>
  <script src="{{url ('assets/custom_file/dataTables.bootstrap5.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js"></script>
  <body>
    <div class="loading" id="loadingScreen"  style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(255, 255, 255, 0.9); z-index: 9999; display:none;">
      <div class="loading-content" style="text-align: center; position: absolute; top: 40%; left: 50%; transform: translate(-50%, -50%);">
          <img src="{{ asset('assets/common/logo_small.png') }}" alt="Company Logo" style="max-width: 120px; margin-bottom: 20px;height:100%">
          <div class="d-block">
            <div class="dot red"></div>
            <div class="dot orange"></div>
            <div class="dot yellow"></div>
            <div class="dot green"></div>
            <div class="dot teal"></div>
            <div class="dot blue"></div>
            <div class="dot violet"></div>
          </div>
      </div>
    </div>

    <!-- Layout Content -->
    @yield('layoutContent')
    <!--/ Layout Content -->

    

    <!-- Include Scripts -->
    <!-- $isFront is used to append the front layout scripts only on the front layout otherwise the variable will be blank -->
    @include('layouts/sections/scripts' . $isFront)
    <script>
        'use strict';
        $(function() {
            const select2 = $('.select3');

            if (select2.length) {
                select2.each(function() {
                    var $this = $(this);
                    select2Focus($this);
                    $this.wrap('<div class="position-relative"></div>').select2({
                        dropdownParent: $this.parent()
                    });
                });
            }
        });
    </script>

    <script>
      document.addEventListener("DOMContentLoaded", function() {
        const scrollContainer = document.getElementById('scrollContainer');
        const scrollLeftBtn = document.getElementById('scrollLeftBtn');
        const scrollRightBtn = document.getElementById('scrollRightBtn');

         if (!scrollContainer || !scrollLeftBtn || !scrollRightBtn) return;

        function updateScrollButtons() {
          const scrollLeft = scrollContainer.scrollLeft;
          const scrollWidth = scrollContainer.scrollWidth;
          const clientWidth = scrollContainer.clientWidth;
          const threshold = 1;

          scrollLeftBtn.style.display = scrollLeft > threshold ? 'flex' : 'none';
          scrollRightBtn.style.display = (scrollLeft + clientWidth) < (scrollWidth - threshold) ? 'flex' : 'none';
        }

        scrollLeftBtn.addEventListener('click', () => {
          scrollContainer.scrollBy({ left: -200, behavior: 'smooth' });
        });

        scrollRightBtn.addEventListener('click', () => {
          scrollContainer.scrollBy({ left: 200, behavior: 'smooth' });
        });

        scrollContainer.addEventListener('scroll', updateScrollButtons);
        window.addEventListener('resize', updateScrollButtons);

        // initial check
        updateScrollButtons();
      });
    </script>

    <script>
      document.addEventListener("DOMContentLoaded", function () {
        const tagInputs = document.querySelectorAll(".skill_tag");

        const whitelist = [
            "Select Skill Tags",
            "Development", "Managing"
        ];

        tagInputs.forEach((input) => {
            new Tagify(input, {
                whitelist: whitelist,
                maxTags: 10,
                dropdown: {
                    maxItems: 20,
                    classname: "tags-inline",
                    enabled: 0,
                    closeOnSelect: false
                }
            });
        });
      });
    </script>

    <script>
            // document.addEventListener('DOMContentLoaded', function () {
            //     const loader = document.getElementById('page-loader');
        
            //     // Show loader on page unload
            //     window.addEventListener('beforeunload', function () {
            //         loader.style.display = 'flex';
            //     });
        
            //     // Hide loader on page load
            //     window.addEventListener('load', function () {
            //         loader.style.display = 'none';
            //     });
        
            //     // Show loader on form submissions
            //     document.querySelectorAll('form').forEach(function (form) {
            //         form.addEventListener('submit', function () {
            //             loader.style.display = 'flex';
            //         });
            //     });
        
            //     // Show loader on link clicks
            //     // document.querySelectorAll('a').forEach(function (link) {
            //     //     link.addEventListener('click', function (event) {
            //     //         if (link.target === '_blank' || event.ctrlKey || event.metaKey) {
            //     //             return; // Skip new tabs or special key combinations
            //     //         }
            //     //         loader.style.display = 'flex';
            //     //     });
            //     // });
            // });
        document.addEventListener('DOMContentLoaded', function () {
            const loader = document.getElementById('loadingScreen');
            let loaderTimeout;
        
            // Show loader on page unload
            window.addEventListener('beforeunload', function () {
                loader.style.display = 'flex';
            });
        
            // Hide loader on page load
            window.addEventListener('load', function () {
                loader.style.display = 'none';
                clearTimeout(loaderTimeout);
            });
        
            // Hide loader on back/forward navigation
            window.addEventListener('pageshow', function () {
                loader.style.display = 'none';
                clearTimeout(loaderTimeout);
            });
        
            // Show loader on form submissions
            document.querySelectorAll('form').forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    // Prevent default if form is invalid
                    if (!form.checkValidity()) {
                        event.preventDefault(); // Stop form submission
                        loader.style.display = 'none'; // Hide loader immediately
                        alert("Form validation failed. Please check your inputs.");
                        return;
                    }
        
                    // Show loader and set a fallback timeout to hide it
                    loader.style.display = 'flex';
                    loaderTimeout = setTimeout(() => {
                        loader.style.display = 'none';
                        // alert("Submission took too long. Please try again.");
                    }, 2000); // Fallback to hide after 5 seconds
                });
            });
        });
    </script>

    <script>
      function toggleIcons(input) {
          const refreshIcon = document.querySelector(".refreshIcon");
          if (input.value.trim() !== "") {
              refreshIcon.style.display = "block";
          } else {
              refreshIcon.style.display = "none";
          }
      }

      function clearInput() {
          const input = document.querySelector(".searchQueryInput");
          input.value = "";
          toggleIcons(input);
          input.focus();
      }
    </script>
  </body>

</html>
