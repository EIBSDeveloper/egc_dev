<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Record Your Video</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    video { width: 100%; border-radius: 10px; background: #000; }
  </style>
</head>
<body class="bg-light p-4">

<div class="container text-center">
  <h3 class="mb-4 text-primary">Record Your Video</h3>

  <video id="preview" autoplay muted></video>
  <video id="recorded" controls class="d-none mt-3"></video>

  <div class="mt-4">
    <button id="startBtn" class="btn btn-success me-2">Start Recording</button>
    <button id="stopBtn" class="btn btn-danger me-2" disabled>Stop</button>
    <button id="submitBtn" class="btn btn-primary d-none">Submit Video</button>
  </div>

  <div id="status" class="mt-3 text-secondary"></div>
</div>

<script>
  let mediaRecorder, recordedChunks = [];
  const preview = document.getElementById('preview');
  const recorded = document.getElementById('recorded');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const submitBtn = document.getElementById('submitBtn');
  const status = document.getElementById('status');
  const token = "{{ $submission->token }}";

  // Start recording
  startBtn.onclick = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      preview.srcObject = stream;
      recordedChunks = [];
      mediaRecorder = new MediaRecorder(stream, { mimeType: 'video/webm' });

      mediaRecorder.ondataavailable = e => {
        if (e.data.size > 0) recordedChunks.push(e.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(recordedChunks, { type: 'video/webm' });
        const videoURL = URL.createObjectURL(blob);
        recorded.src = videoURL;
        recorded.classList.remove('d-none');
        preview.classList.add('d-none');
        submitBtn.classList.remove('d-none');
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      startBtn.disabled = true;
      stopBtn.disabled = false;
      status.innerText = 'Recording...';

    } catch (err) {
      alert('Camera access denied or not available.');
      console.error(err);
    }
  };

  // Stop recording
  stopBtn.onclick = () => {
    mediaRecorder.stop();
    startBtn.disabled = false;
    stopBtn.disabled = true;
    status.innerText = 'Recording stopped.';
  };

  // Submit video
  submitBtn.onclick = async () => {
    const blob = new Blob(recordedChunks, { type: 'video/webm' });
    const formData = new FormData();
    formData.append('video', blob, 'recorded_video.webm');
    formData.append('token', token);

    status.innerText = 'Uploading...';

    try {
      const response = await fetch('{{ route("record.upload") }}', {
        method: 'POST',
        headers: { 'X-CSRF-TOKEN': '{{ csrf_token() }}' },
        body: formData
      });

      if (response.ok) {
        status.innerHTML = '<span class="text-success">✅ Video uploaded successfully!</span>';
        submitBtn.disabled = true;
      } else {
        status.innerHTML = '<span class="text-danger">❌ Upload failed.</span>';
      }
    } catch (error) {
      console.error(error);
      status.innerHTML = '<span class="text-danger">❌ Upload error.</span>';
    }
  };
</script>

</body>
</html>
