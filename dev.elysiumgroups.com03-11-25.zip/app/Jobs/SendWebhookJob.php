<?php

namespace App\Jobs;

use App\Models\WebhookDispatchModel;
use App\Models\WebhookDispatchAttemptModel;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Throwable;

class SendWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $dispatchSno;
    public $tries = 5;

    public function __construct(int $dispatchSno)
    {
        $this->dispatchSno = $dispatchSno;
        $this->onQueue('webhooks');
    }

    public function backoff(): array
    {
        return [60, 120, 300, 900, 3600];
    }

    public function handle()
    {
        $dispatch = WebhookDispatchModel::find($this->dispatchSno);
        if (!$dispatch) return;

        if ($dispatch->status === 2) { // succeeded
            return;
        }

        $hook = $dispatch->webhook;
        if (!$hook) {
            // mark failed and return
            $dispatch->update(['status' => 3, 'last_response' => 'No webhook configured']);
            return;
        }

        $payload = $dispatch->payload ?? [];
        $bodyString = json_encode($payload);
        $dispatch->increment('attempts');
        $dispatch->update(['status' => 1, 'last_attempt_at' => now()]);

        $timestamp = now()->getTimestamp();
        $signature = null;
        if (!empty($hook->secret)) {
            $signature = hash_hmac('sha256', $timestamp . '.' . $bodyString, $hook->secret);
        }

        $headers = array_merge(
            is_array($hook->headers) ? $hook->headers : (is_string($hook->headers) ? json_decode($hook->headers, true) ?? [] : []),
            [
                'X-WEBHOOK-TIMESTAMP' => $timestamp,
                'X-WEBHOOK-SIGNATURE' => $signature,
                'X-IDEMPOTENCY-KEY' => $dispatch->message_uuid,
                'Accept' => 'application/json',
            ]
        );

        try {
            $response = Http::withHeaders($headers)
                ->timeout(15)
                ->post($hook->url, $payload);

            // Log attempt
            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => $response->status(),
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $response->body(),
            ]);

            if ($response->successful()) {
                $dispatch->update(['status' => 2, 'http_status' => $response->status(), 'last_response' => $response->body(), 'next_attempt_at' => null]);
                return;
            }

            // non-success -> treat as exception to let job be retried
            throw new \Exception("Non-success response: " . $response->status());

        } catch (Throwable $e) {
            WebhookDispatchAttemptModel::create([
                'webhook_dispatch_sno' => $dispatch->sno,
                'http_status' => method_exists($e, 'status') ? $e->status() : null,
                'request_headers' => json_encode($headers),
                'request_body' => $bodyString,
                'response_body' => $e->getMessage(),
                'error' => $e->getMessage(),
            ]);

            // set next_attempt_at with exponential-ish delay (fallback)
            $nextDelay = match ($dispatch->attempts) {
                1 => now()->addSeconds(60),
                2 => now()->addSeconds(120),
                3 => now()->addSeconds(300),
                default => now()->addSeconds(3600),
            };

            $dispatch->update(['status' => 3, 'next_attempt_at' => $nextDelay]);

            // rethrow so Laravel can apply automatic retry/backoff
            throw $e;
        }
    }

    public function failed(Throwable $exception)
    {
        $dispatch = WebhookDispatchModel::find($this->dispatchSno);
        if ($dispatch) {
            $dispatch->update(['status' => 3, 'last_response' => $exception->getMessage()]);
        }
    }
}
