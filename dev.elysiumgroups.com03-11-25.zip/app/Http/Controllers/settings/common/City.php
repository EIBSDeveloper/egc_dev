<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\StateModel;
use App\Models\CityModel;



class City extends Controller
{
  protected static $branch_id = 1;
//   public function index()
// {
//     return view('content.settings.common.city.city_list');
// }

//here i need to get the country table data by using the state table data

 public function index(Request $request)
  {

    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';

    $city = CityModel::select('egc_cities.*','egc_states.name as state_name','egc_countries.name as country_name','egc_countries.id as country_id')->where('egc_cities.status', '!=', 2)
    ->join('egc_states','egc_states.id','=','egc_cities.state_id')
    ->join('egc_countries','egc_countries.id','=','egc_states.country_id');
    if ($search_filter != '') {
        $city->where(function ($subquery) use ($search_filter) {
            $subquery->where('egc_cities.name', 'LIKE', "%{$search_filter}%")
                ->orWhere('egc_states.name', 'LIKE', "%{$search_filter}%")
                ->orWhere('egc_countries.name', 'LIKE', "%{$search_filter}%");  
        });
    }
    $city=$city->orderBy('egc_cities.id', 'desc')->paginate($perpage);
    // return view( 'content.settings.course.course_type.course_type_list' );
    return view('content.settings.common.city.city_list', [
      'city' => $city,
       'perpage' => $perpage,
      'search_filter' => $search_filter
    ]);
  }
  
  public function List(Request $request)
  {


      $stateId = $request->input('state_id');

      $city = CityModel::where('status', 0)->where('state_id', $stateId)
          ->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }
    public function List_for_edit(Request $request)
  {
    $stateId = $request->input('state_id');
    $city = CityModel::where('state_id', $stateId)->orderBy('name', 'ASC')
      ->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $city
    ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {
      $name                   = $request->name;
      $state_id                 = $request->state_id;

      $user_id                    = $request->user()->user_id ?? 1;
      $chk = CityModel::where('name', $name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
      } else {
        $category_check = CityModel::where('status', '!=', 2)->orderBy('id', 'desc')->first();

        if (!$category_check) {
            $cid = 'C1';
        } else {
            $data = $category_check->cid; // e.g., "C3"
            $number = (int) filter_var($data, FILTER_SANITIZE_NUMBER_INT); // extracts 3
            $next_number = $number + 1;
            $cid = 'C' . $next_number; // e.g., "C4"
        }

        $add_category = new CityModel();
        $add_category->cid  = $cid;
        $add_category->name = $name;
        $add_category->state_id = $state_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'City added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the City!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'City Created successfully!');
    }
  }

  public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      $id = $request->edit_id;
      $name                   = $request->name;
      $state_id                 = $request->state_id;

      $upd_CourseCategoryModel =  CityModel::where('id', $id)->first();

      $chk = CityModel::where('name', $name)->where('id', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'City has been  already assigned!'
        ]);
        return redirect()->back();
      } else {

        $upd_CourseCategoryModel->name  = $name;
        $upd_CourseCategoryModel->state_id  = $state_id;
        $upd_CourseCategoryModel->update();

        if ($upd_CourseCategoryModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'City updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the City !'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  CityModel::where('id', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  CityModel::where('id', $id)->first();
    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}