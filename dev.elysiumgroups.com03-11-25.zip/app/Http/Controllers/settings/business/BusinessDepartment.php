<?php

namespace App\Http\Controllers\settings\business;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\DepartmentModel;
use App\Models\CompanyModel;
use App\Models\SubErpWebhookModel;
use App\Models\WebhookDispatchModel;
use App\Jobs\SendWebhookJob;
use Carbon\Carbon;

class BusinessDepartment extends Controller
{

  // management Department
  public function index(Request $request)
  {
      
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    
    $Department = DepartmentModel::where('egc_department.status', '!=', 2)->orderBy('sno', 'desc')
      ->select('egc_department.*','egc_entity.entity_name','egc_company.company_name')
      ->join('egc_company', 'egc_department.company_id', 'egc_company.sno')
      ->join('egc_entity', 'egc_department.entity_id', 'egc_entity.sno')
      ->where('egc_department.company_type',2);
      
       if ($search_filter != '') {
            $Department->where(function ($subquery) use ($search_filter) {
                $subquery->where('egc_department.department_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_department.department_desc', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_company.company_name', 'LIKE', "%{$search_filter}%")
                    ->orWhere('egc_entity.entity_name', 'LIKE', "%{$search_filter}%");
                    
            });
        }

        $Department=$Department->orderBy('egc_department.sno', 'desc')->paginate($perpage);
        $helper = new \App\Helpers\Helpers();

        if ($request->ajax()) {
            $data = $Department->map(function ($item) use ($helper) {
                return [
                    'sno' => $item->sno,
                    'status' => $item->status,
                    'department_name' => $item->department_name,
                    'company_name' => $item->company_name,
                    'entity_name' => $item->entity_name,
                    'department_desc' => $item->department_desc,
                    'item' => $item,
                    'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
                ];
            });

            return response()->json([
                'data' => $data,
                'current_page' => $Department->currentPage(),
                'last_page' => $Department->lastPage(),
                'total' => $Department->total(),
            ]);
        }
    $company_list = CompanyModel::where('status', 0)->orderBy('sno', 'ASC')->get();
    return view('content.settings.business.department.department_list', [
      'ListTable' => $Department,
      'perpage' => $perpage,
      'search_filter' => $search_filter,
      'company_list' => $company_list
    ]);
  }



  public function List(Request $request)
  {
    
    $entity_id=$request->entity_id;
    $Department = DepartmentModel::where('status', 0)->where('entity_id',$entity_id)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function BranchDepartList(Request $request)
  {

    $branch_id = $request->branch_id;
    // ->where('branch_id', $branch_id)
    $Department = DepartmentModel::where('status', 0)->orderBy('sno', 'desc')->get();

    return response([
      'status' => 200,
      'message' => null,
      'error_msg' => null,
      'data' => $Department
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $staff =  DepartmentModel::where('sno', $id)->first();
    // return $staff;
    $staff->status = $request->input('status', 0);
    $staff->update();

    if ($staff) {
      return response([
        'status'    => 200,
        'message'   => 'Department Status Updated Successfully!',
        'error_msg' => 'Could not, update  Staff  Status!',
        'data'      => null,
      ], 200);
    } else {
      return response([
        'status'    => 200,
        'message'   => 'Could not update Staff  Status!',
        'error_msg' => 'Could not, update  Company  Status!',
        'data'      => null,
      ], 200);
    }
  }
  public function Delete($id)
  {
    $upd_DepartmentModel = DepartmentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->update();



    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
  public function Add(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'department_name' => 'required_if:erp_department_name,other_department'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {

      $company_id = $request->company_id;
      $entity_id = $request->entity_id;

      // If user selected "other", take manual input
      if ($request->erp_department_name == 'new_department') {
          $department_name = $request->department_name;
          $erp_department_id = $request->erp_department_id;
      }
      else {
          $department_name = $request->department_name_hidden;
          $erp_department_id = $request->erp_department_name; // sno from ERP
      }

 
      
      $department_desc = $request->department_desc;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', $department_name)->where('company_type', 2)->where('entity_id', $entity_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {
        $category_check = DepartmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $department_id = 'DP-0001/' . $year;
        } else {

          $data = $category_check->department_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $requestID = sprintf('DP-%04d', $next_number);

          $year = substr(date('y'), -2);
          $department_id = $requestID . '/' . $year;
        }

        $add_department = new DepartmentModel();
        $add_department->department_id = $department_id;
        $add_department->company_type = 2;
        $add_department->company_id = $company_id;
        $add_department->entity_id = $entity_id;
        $add_department->erp_department_id = $erp_department_id;
        $add_department->department_name = $department_name;
        $add_department->department_desc = $department_desc;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          if($request->erp_department_name == 'new_department'){
              $this->dispatchWebhooks($add_department, $user_id);
          }
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'department added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {
    $editdepartment = DepartmentModel::where('sno', $id)->first();
    if (!$editdepartment) {
      return response([
        'status' => 404,
        'message' => 'Department not found',
        'error_msg' => 'No record found with the given ID.',
        'data' => null,
      ], 404);
    }

    return response([
      'status' => 200,
      'message' => 'Department fetched successfully',
      'error_msg' => null,
      'data' => $editdepartment,
    ], 200);
  }

   public function Update(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'department_name' => 'required'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      // return $request;
      $sno = $request->edit_id;
      $department_name = $request->department_name;
      $department_desc = $request->department_desc;
      $user_id = $request->user()->user_id;
      $chk = DepartmentModel::where('department_name', $department_name)->where('company_type', 2)->where('sno', '!=', $sno)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Department Name Already Exists!'
        ]);
        return redirect()->back();
      } else {


        $up_department = DepartmentModel::where('sno', $sno)->first();
        $up_department->department_name = $department_name;
        $up_department->department_desc = $department_desc;
        $up_department->created_by = $user_id;
        $up_department->updated_by = $user_id;

        $up_department->save();

        if ($up_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Department updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  protected function dispatchWebhooks(DepartmentModel $broadcast, $userId = 1)
  {
      $webhook = SubErpWebhookModel::where('status', 0)->where('webhook_module','Department_Hook')->where('entity_id',$broadcast->entity_id)->first();

          $dispatch = WebhookDispatchModel::create([
              'sub_erp_webhook_sno' => $webhook->sno,
              'dispatchable_type' => get_class($broadcast),
              'dispatchable_id' => $broadcast->sno,
              'message_uuid' => $broadcast->sno,
              'payload' => $broadcast->toArray(),
              'status' => 0,
              'attempts' => 0,
              'created_by' => $userId,
              'updated_by' => $userId,
          ]);

          // enqueue the job
          SendWebhookJob::dispatch($dispatch->sno)->onQueue('webhooks');
     
  }
}