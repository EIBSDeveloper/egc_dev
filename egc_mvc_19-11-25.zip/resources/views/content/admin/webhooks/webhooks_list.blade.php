@extends('layouts/layoutMaster')

@section('title', 'Webhook Moniter')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
        
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}"
                                type="button"
                                class="nav-link scroll-link "
                                role="tab">
                                General Settings
                            </a>
                        </li>        
                        <li class="item nav-item">
                            <a
                                href="{{ url('/settings/broadcast_theme') }}"
                                type="button"
                                class="nav-link scroll-link"
                                aria-selected="true">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button"
                                class="nav-link scroll-link ">
                                Entity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link ">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button"
                                class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button"
                                class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                        <li class="nav-item">
                                <a href="{{ url('/settings/business/department') }}" type="button"
                                    class="nav-link scroll-link ">
                                    Business
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="{{ url('/admin/webhooks') }}" type="button"
                                    class="nav-link scroll-link active">
                                    Webhook Moniter
                                </a>
                            </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>  
            </ul>
        </div>
        <div class="card-body">
            <h4 class="ms-2">Webhook Moniter</h4>
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [6,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Webhook..."
                                    value="{{ $search_filter }}"/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12"> 
                    <div class="table-responsive">
                        <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-center text-nowrap align-middle  fw-bold fs-6 gs-0 bg-primary">
                                    <th class="min-w-50px">S.No</th>
                                    <th class="min-w-150px text-center">URL</th>
                                    <th class="min-w-50px">Status</th>
                                    <th class="min-w-100px">Attempts</th>
                                    <th class="min-w-100px">Last Attempt</th>
                                    <th class="min-w-100px">Next Attempt</th>
                                    <th class="min-w-80px text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="list-table-body" class="text-black fw-semibold fs-7">
                                <tr class="skeleton-loader" id="skeleton-loader">
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                    <td class="skeleton-cell">
                                        <div class="skeleton"></div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>

        <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>
   
<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item,index) {     
        var bg_color=item.status ==2 ? 'bg-success' :
                        (item.status ==3 ? 'bg-danger' :
                        (item.status ==1 ? 'bg-warning' : 'bg-secondary')
                        );
            var statusName=item.status ==2 ? 'Success' :
                        (item.status ==3 ? 'Failed' :
                        (item.status ==1 ? 'Processing' : 'Pending')
                        );
        return `
            <tr id="webhook-${item.sno}">
                <td><label class="fs-7 fw-medium">${index}</label></td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="text-truncate max-w-150px fw-semibold fs-7"
                            data-bs-toggle="tooltip" data-bs-placement="bottom"
                            title="${item.url}">${item.url}
                        </div>
                    </div>
                </td>
                <td align="center">
                    <span class="badge status ${bg_color}" data-bs-toggle="tooltip" data-bs-placement="bottom" title='${item.last_response}'>${statusName}</span>
                </td>
                <td align="center">
                    <span class="badge bg-info attempts">${item.attempts}</span>
                </td>
                <td align="start">
                        <span class="badge bg-danger last-attempt">${item.last_attempt_at ? formatDateTime(item.last_attempt_at) : '-'}</span>
                </td>
                <td align="center">
                        <span class="badge bg-warning text-black next-attempt">${item.next_attempt_at ? formatDateTime(item.next_attempt_at) : '-'}</span>
                </td>
                <td class="action text-center ">
                    ${item.status != 2 ? `
                    <form class="retry-form" data-id="${item.sno}" action="/admin/webhooks/retry/${item.sno}" method="POST">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        <button type="submit" class="btn btn-sm btn-primary">Retry</button>
                    </form>` : 
                    '<span class="mdi mdi-check-circle-outline text-success"></span>'}
                </td>
            </tr>
        `;
    }

    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/admin/webhooks?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('list-table-body').innerHTML = ''; // Clear old data
        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

        fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach((item, index) => {
                        document.getElementById('list-table-body').insertAdjacentHTML('beforeend', buildRow(item, index + 1));
                    });

                }else{
                    document.getElementById('list-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                    $('[data-bs-toggle="tooltip"]').tooltip();

                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="8" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<!-- Add Validation -->
<script>
        document.addEventListener('click', function(e) {
            if(e.target.closest('.retry-form button')){
                e.preventDefault();
                const form = e.target.closest('.retry-form');
                const sno = form.dataset.id;

                fetch(form.action, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': form.querySelector('[name="_token"]').value,
                        'X-Requested-With': 'XMLHttpRequest',
                    }
                })
                .then(res => res.json())
                .then(res => {
                    if(res.success){
                        toastr.success('Retry triggered successfully');
                        loadThemes(currentPage); // reload current page
                    } else {
                        toastr.error('Failed to trigger retry');
                    }
                })
                .catch(err => console.error(err));
            }
        });


        var pusher = new Pusher('9996b96e908059a0d53f', {
            cluster: 'ap2',
            encrypted: true
        });
            console.log("before socket start")
        // Subscribe to the 'webhooks' channel (private channel)
       var channel = pusher.subscribe('webhooks');

     
        // Listen for the 'WebhookDispatchedEvent' event
        channel.bind('WebhookDispatchedEvent', function(e) {
            // support either e.id or e.sno
            const id = (e.id !== undefined ? e.id : e.sno);
            if (!id) return; // defensive

            const row = document.getElementById('webhook-' + id);

            // compute badge classes from status
            const statusName = e.status == 2 ? 'Success' :
                            (e.status == 3 ? 'Failed' :
                                (e.status == 1 ? 'Processing' : 'Pending'));
            const bgColorClass = e.status == 2 ? 'bg-success' :
                                (e.status == 3 ? 'bg-danger' :
                                (e.status == 1 ? 'bg-warning' : 'bg-secondary'));

            if (row) {
                // update existing row
                const statusCell = row.querySelector('.status');
                if (statusCell) {
                    statusCell.className = `badge status ${bgColorClass}`;
                    statusCell.innerText = statusName;

                    // Set tooltip title to last_response
                       const tooltipText = e.last_response ? e.last_response : '';

                        statusCell.setAttribute("title", tooltipText);
                        statusCell.setAttribute("data-bs-original-title", tooltipText);
                }
                const attemptsEl = row.querySelector('.attempts');
                if (attemptsEl) attemptsEl.innerText = e.attempts ?? '';

                const lastAttemptEl = row.querySelector('.last-attempt');
                if (lastAttemptEl) lastAttemptEl.innerText = e.last_attempt_at ? formatDateTime(e.last_attempt_at) : '-';

                const nextAttemptEl = row.querySelector('.next-attempt');
                if (nextAttemptEl) nextAttemptEl.innerText = e.next_attempt_at ? formatDateTime(e.next_attempt_at) : '-';

                // if success remove retry button
                if (e.status == 2) {
                    const actionCell = row.querySelector('.action');
                    if (actionCell) actionCell.innerHTML = '<span class="mdi mdi-check-circle-outline text-success"></span>';
                }

                 const tooltip = bootstrap.Tooltip.getInstance(statusCell);
                    if (tooltip) tooltip.dispose();
                    new bootstrap.Tooltip(statusCell);
            } else {
                // new row (insert at top)
                const tableBody = document.getElementById('list-table-body');
                tableBody.insertAdjacentHTML('afterbegin', buildRow(e, 1));
            }
        });


        function formatDateTime(dateString) {
            if (!dateString) return '';

            const date = new Date(dateString);
            const options = {
                day: '2-digit',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: true,
            };
            return date.toLocaleString('en-GB', options).replace(',', '');
        }
</script>




@endsection
