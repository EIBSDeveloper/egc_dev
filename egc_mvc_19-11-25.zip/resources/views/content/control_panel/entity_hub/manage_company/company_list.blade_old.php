@extends('layouts/layoutMaster')

@section('title', 'Manage Company')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Company</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_create_company">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Company
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                        <div>
                            <span>Show</span>
                            <br>
                            <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                                <option value="10">10</option>
                                <option value="25" selected>25</option>
                                <option value="50">50</option>
                                <option value="100">100</option>
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input class="searchQueryInput" type="text" name="searchQueryInput" placeholder="Enter Company Name/ Mobile No" value="" />
                                <a href="{{url('entity_hub/manage_company')}}" class="searchQuerySubmit" type="submit" name="searchQuerySubmit">
                                    <svg style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="#ab2b22" d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Company</th>
                                <th class="min-w-100px">Email ID</th>
                                <th class="min-w-100px">Contact Person / Mobile</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="text-black fw-semibold fs-7">
                            <tr>
                                <td>
                                    <div class="d-flex allign-items-center gap-2">
                                        <span class="rounded-circle py-1 px-3 fw-bold" style="background-color: #2B1A66;"></span>
                                        <div>
                                            <div class="d-flex align-items-center">
                                                <div class="text-truncate max-w-175px" data-bs-toggle="tooltip"
                                                    data-bs-placement="bottom"
                                                    title="Elysian Intelligence Business Solution">Elysian Intelligence
                                                    Business Solution</div>
                                                <a href="https://eibsglobal.com/" target="_blank" class="ms-1"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL">
                                                    <i class="mdi mdi-web fs-4 text-dark"></i>
                                                </a>
                                            </div>
                                            <div class="d-block">
                                                <label class="badge bg-warning fs-8 text-black fw-bold">Private Limited
                                                    Company (Pvt Ltd)</label>
                                            </div>
                                        </div>
                                        <label data-bs-toggle="modal" data-bs-target="#kt_modal_location_map">
                                            <i class="mdi mdi-map-marker-radius fs-4 text-dark" data-bs-toggle="tooltip"
                                                data-bs-placement="bottom"
                                                title="Ground Floor, A Block, Elysium Campus, 229, Church Rd, Anna Nagar, Madurai, Tamil Nadu 625020"></i>
                                        </label>
                                    </div>
                                </td>
                                <td>
                                    <label>info@eibsglobal.com</label>
                                </td>
                                <td>
                                    <label>Sankar Ganesh</label>
                                    <div class="d-block">
                                        <label class="fs-8 text-black fw-semibold">9894444710</label>
                                    </div>
                                </td>
                                <td>
                                    <label class="switch switch-square">
                                        <input type="checkbox" class="switch-input" checked />
                                        <span class="switch-toggle-slider">
                                            <span class="switch-on"></span>
                                            <span class="switch-off"></span>
                                        </span>
                                    </label>
                                </td>
                                <td>
                                    <div class="text-center">
                                        <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#kt_modal_create_entity">
                                            <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Entity"> <i
                                                    class="mdi mdi-source-branch-plus fs-3 text-black me-1"></i></span></a>
                                        <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true"
                                            aria-expanded="false">
                                            <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_view_company">
                                                <span> <i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span></a>
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_update_company">
                                                <span><i
                                                        class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                                            </a>
                                            <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal"
                                                data-bs-target="#kt_modal_delete_company">
                                                <span><i
                                                        class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                                            </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>



    <!--begin::Modal - Create Company -->
    <div class="modal fade" id="kt_modal_create_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Company</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Company Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Company Type</option>
                                <option value="1">Private Limited Company (Pvt Ltd)</option>
                                <option value="2">Public Limited Company (PLC)</option>
                                <option value="3">Limited Liability Partnership (LLP)</option>
                                <option value="4">Government Organization</option>
                                <option value="5">Non-Profit Organization (NGO/NPO)</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">USA</option>
                                <option value="2">UAE</option>
                                <option value="3">India</option>
                                <option value="4">South Africa</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1">Tamilnadu</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Kerala</option>
                                <option value="4">Karnataka</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1">Madurai</option>
                                <option value="2">Virudhunagar</option>
                                <option value="3">Thirunelveli</option>
                                <option value="4">Coimbatore</option>
                                <option value="5">Chennai</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter GST No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CIN No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Tax No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Color<span
                                    class="text-danger">*</span></label>
                             <input type="color" class="form-control" id="" placeholder="Enter Company Color" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create Company</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Company-->


    <!--begin::Modal - Update Company -->
    <div class="modal fade" id="kt_modal_update_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Company</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->

                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Company Name"
                                value="Elysian Intelligence Business Solution" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Company Type</option>
                                <option value="1" selected>Private Limited Company (Pvt Ltd)</option>
                                <option value="2">Public Limited Company (PLC)</option>
                                <option value="3">Limited Liability Partnership (LLP)</option>
                                <option value="4">Government Organization</option>
                                <option value="5">Non-Profit Organization (NGO/NPO)</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID"
                                value="info@eibsglobal.com" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL"
                                value="https://eibsglobal.com/" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                value="Sankar Ganesh" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                                value="9894444710" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">USA</option>
                                <option value="2">UAE</option>
                                <option value="3" selected>India</option>
                                <option value="4">South Africa</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1" selected>Tamilnadu</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Kerala</option>
                                <option value="4">Karnataka</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1" selected>Madurai</option>
                                <option value="2">Virudhunagar</option>
                                <option value="3">Thirunelveli</option>
                                <option value="4">Coimbatore</option>
                                <option value="5">Chennai</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street"
                                value="Ground Floor, C Block, Elysium Campus, 229, Church Rd, Anna Nagar" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No"
                                value="229" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" value="625020" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter GST No"
                                value="27AABCU9603R1ZV" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CIN No"
                                value="U12345MH2005PTC123456" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" value="AABCU9603R" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Tax No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Tax No" value="1234567890" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Color<span
                                    class="text-danger">*</span></label>
                             <input type="color" class="form-control" id="" value="#2B1A66" placeholder="Enter Company Color" />
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description">-</textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" value="HDFC" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                value="Anna Nagar" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder"
                                value="Elysian Intelligence Business Solution
                                " />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No"
                                value="8574854578452" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                value="HDFC0002027" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Update Company</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Company-->

    <!--begin::Modal View Company--->
    <div class="modal fade" id="kt_modal_view_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex flex-column">
                      <div class="avatar-stack">
                              <img src="{{ asset('assets/egc_images/newImgs/company-buildingNew1.png') }}" alt="user-avatar" class="avatar-img" />
                              <img src="{{ asset('assets/egc_images/newImgs/company-building.png') }}" alt="user-avatar" class="avatar-img" />
                              <img src="{{ asset('assets/egc_images/newImgs/apartment.png') }}" alt="user-avatar" class="avatar-img" />
                        </div>
                        <div class="row mb-2">
                            <h3 class="text-black">View Company</h3>
                        </div>
                    </div>
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                    <input type="hidden" id="sts_change_id" name="sts_change_id" />
                    <div class="row mb-3">
                        <div class="nav-align-top nav-tabs-shadow mb-3">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                        Company Info
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#legaltax" aria-controls="legaltax" aria-selected="false">
                                        Legal / Tax
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#bankinfo" aria-controls="bankinfo"
                                        aria-selected="false">
                                        Bank Info
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-8">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Company</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Elysian Intelligence Business Solution">
                                                    Elysian Intelligence Business Solution
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Company Type</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Private Limited Company (Pvt Ltd)">Private
                                                    Limited Company (Pvt Ltd)
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Email ID</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="info@eibsglobal.com">info@eibsglobal.com</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-6 fw-semibold">Website URL</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <a href="https://elysiumtechnologies.com/" target="_blank"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="https://eibsglobal.com/">
                                                    <div class="text-truncate max-w-75 text-black fs-7  fw-semibold">
                                                        https://eibsglobal.com/</div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Contact Person</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Sankar Ganesh">
                                                    Sankar Ganesh</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">C.P. Mobile No</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">9894444710</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                            <label class="col-1 fw-semibold fs-7">:</label>
                                            <label class="col-6 fw-semibold fs-6 text-black">-</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="legaltax" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-8">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">GST No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="27AABCU9603R1ZV">
                                                    27AABCU9603R1ZV</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">CIN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="U12345MH2005PTC123456">U12345MH2005PTC123456
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">PAN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="AABCU9603R">
                                                    AABCU9603R</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Tax No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="1234567890">
                                                    1234567890</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="bankinfo" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-8">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Bank</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">HDFC</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">Anna Nagar</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">IFSC Code</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">HDFC0002027</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account Holder</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">Elysium Intelligence Business
                                                Solutions</label>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <label class="col-6 text-black fs-6 fw-semibold">8574854578452</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal View Company-->


    <!--begin::Modal - Create Entity -->
    <div class="modal fade" id="kt_modal_create_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Entity</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000" xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Company</option>
                                <option value="1">Elysium Technologies Pvt Ltd</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CRM URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CRM URL" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select Country</option>
                                <option value="1">USA</option>
                                <option value="2">UAE</option>
                                <option value="3">India</option>
                                <option value="4">South Africa</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select State</option>
                                <option value="1">Tamilnadu</option>
                                <option value="2">Andhra Pradesh</option>
                                <option value="3">Kerala</option>
                                <option value="4">Karnataka</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select">
                                <option value="">Select City</option>
                                <option value="1">Madurai</option>
                                <option value="2">Virudhunagar</option>
                                <option value="3">Thirunelveli</option>
                                <option value="4">Coimbatore</option>
                                <option value="5">Chennai</option>
                            </select>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                            <input type="text" class="form-control" placeholder="Enter GST No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                            <input type="text" class="form-control" placeholder="Enter CIN No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" />
                        </div>
                        <div class="col-lg-8 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" placeholder="Enter Description"></textarea>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No" />
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code" />
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create Entity</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Entity-->


    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Elysian
                            Intelligence Business Solution </b>
                        Company ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->


    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "pageLength": 25,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                 //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
@endsection
