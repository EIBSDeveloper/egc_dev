<?php

namespace App\Http\Controllers\settings\entity;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\FinancialYearModel;
use Illuminate\Support\Facades\Validator;

class Level extends Controller
{
    public function index()
    {
        return view(
            'content.settings.entity.level.level');
    }

}
