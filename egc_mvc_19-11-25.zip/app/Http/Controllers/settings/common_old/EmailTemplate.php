<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Validator;

class EmailTemplate extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    return view('content.settings.common.email_template.email_template_list');
  }
  public function List()
  {
    $LedgerCategory = EmailTemplateModel::where('status', '!=', 2)->where('branch_id', self::$branch_id)->orderBy('sno', 'desc')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $LedgerCategory
    ], 200);
  }
  public function EmailAdd()
  {
    return view('content.settings.common.email_template.add');
  }

  public function Edit()
  {
    return view('content.settings.common.email_template.edit');
  }
  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'email_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input fields',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $email_name       = $request->email_name;
      $email_subject          = $request->email_subject;
      $user_id                    = $request->user()->user_id;
      $chk = EmailTemplateModel::where('email_name', ucwords($email_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Email is exist!'
        ]);
        return redirect('settings/common/email_template');
      } else {
        $category_check = EmailTemplateModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $email_template_id = 'ET-0001/' . $year;
        } else {

          $data = $category_check->email_template_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int)$result + 1;
          $request = sprintf('ET-%04d', $next_number);

          $year = substr(date('y'), -2);
          $email_template_id = $request . '/' . $year;
        }

        $add_ledger = new EmailTemplateModel();
        $add_ledger->email_template_id         = $email_template_id;
        $add_ledger->email_name       = Ucfirst($email_name);
        $add_ledger->email_subject       = $email_subject;
        $add_ledger->branch_id         = self::$branch_id;
        $add_ledger->created_by        = $user_id;
        $add_ledger->updated_by        = $user_id;


        $add_ledger->save();

        if ($add_ledger) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Email added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Email!'
          ]);
        }
      }
      return redirect('settings/common/email_template');
    }
  }



  public function Update(Request $request)
  {

    // return $request;

    $validator = Validator::make($request->all(), [
      'email_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return   response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg'     => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $email_name       = $request->email_name;
      $email_subject       = $request->email_subject;
      $edit_id       = $request->edit_id;

      $upd_LedgerCategoryModel =  EmailTemplateModel::where('sno', $edit_id)->first();

      $chk = EmailTemplateModel::where('email_name', ucwords($email_name))->where('branch_id', self::$branch_id)->where('sno', '!=', $edit_id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Ledger is exist!'
        ]);
        return redirect()->back();
      } else {


        $upd_LedgerCategoryModel->email_name  = Ucfirst($email_name);
        $upd_LedgerCategoryModel->email_subject  = $email_subject;
        $upd_LedgerCategoryModel->update();
        // return $upd_LedgerCategoryModel;

        if ($upd_LedgerCategoryModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Email Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the Email!'
          ]);
        }
      }
    }
    return redirect('settings/common/email_template');
  }


  public function Delete($id)
  {
    $upd_LedgerCategoryModel = EmailTemplateModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status  = 2;
    $upd_LedgerCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_LedgerCategoryModel =  EmailTemplateModel::where('sno', $id)->first();
    $upd_LedgerCategoryModel->status = $request->input('status', 0);
    $upd_LedgerCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}
