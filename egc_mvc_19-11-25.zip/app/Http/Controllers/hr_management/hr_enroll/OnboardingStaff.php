<?php

namespace App\Http\Controllers\hr_management\hr_enroll;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OnboardingStaff extends Controller
{
  public function index()
  {
    return view('content.hr_management.hr_enroll.onboarding_staff.staff_list');
  }
}
