@extends('layouts/layoutMaster')

@section('title', 'Manage Users')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
    </style>
 @php
      $helper = new \App\Helpers\Helpers();
      $selectedBranch = request()->query('branch_id') ?? auth()->user()->branch_id;
  @endphp
    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Users</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                User Management
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="card-body">
            <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
            <!-- <div class="btn-group dropstart"> -->

            </div>
            <div class="row mb-3 align-items-stretch">
                <div class="col-md-3"></div>
                <!-- Branch / Franchise Selector -->
                <div class="col-md-3">
                    @if(isset($role_permission->manage_branch))
                        @if($role_permission->manage_branch == 2)
                            @php
                                $user_id = auth()->user()->user_id;
                                $branch_data = $helper->get_branch_control_list($user_id);
                                $branches = $branch_data['branches'];
                                $franchises = $branch_data['franchises'];
                            @endphp
                            <label for="branchSelectsgoal" class="form-label fw-semibold">Select Branch</label>
                            <select name="branch_id" class="select3 form-select" id="branchSelectsgoal" onchange="fetchRoleList()">
                                @if($user_id == 0)
                                    <option value="0" selected>All Branches</option>
                                @endif
                                @if ($branches->isNotEmpty())
                                    <optgroup label="Branches">
                                        @foreach ($branches as $branch)
                                            <option value="{{ $branch->sno }}" {{ $selectedBranch == $branch->sno ? 'selected' : '' }}>
                                                {{ $branch->branch_name }}
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                                @if ($franchises->isNotEmpty())
                                    <optgroup label="Franchises">
                                        @foreach ($franchises as $franchise)
                                            <option value="{{ $franchise->sno }}" {{ $selectedBranch == $franchise->sno ? 'selected' : '' }}>
                                                {{ $franchise->franchise_name }}
                                            </option>
                                        @endforeach
                                    </optgroup>
                                @endif
                            </select>
                        @elseif($role_permission->manage_branch == 1)
                            @if($branch_common)
                                <div class="d-flex align-items-center mt-2">
                                    <i class="mdi mdi-source-branch text-primary fs-3 me-2"></i>
                                    <div>
                                        <h5 class="text-primary mb-0">{{ $branch_common->city_name }}</h5>
                                        <small class="text-muted">{{ $branch_common->branch_name }}</small>
                                    </div>
                                </div>
                            @endif
                        @endif
                    @endif
                </div>

                <!-- Mini Dashboard Cards -->
                <div class="col-md-3">
                    <div class="card" style="height: 100px;">
                        <div class="card-body px-3">
                            <div class="text-center text-dark fw-semibold fs-5">Management</div>
                            <div class="card-info">
                                <div class="fs-3 fw-bold text-center mb-2">
                                    <label class="badge bg-success rounded-pill mb-2"><span id="management_staff">0</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="card" style="height: 100px;">
                        <div class="card-body px-3">
                            <div class="text-center text-dark fw-semibold fs-5">Business</div>
                            <div class="card-info">
                                <div class="fs-3 fw-bold text-center mb-2">
                                    <label class="badge bg-info rounded-pill mb-2" data-bs-toggle="tooltip" data-bs-placement="bottom" data-bs-original-title="Faculties"><span id="business_staff">0</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Add additional mini cards here if necessary -->
                 
            </div>



            <div class="row">
                <div class="col-lg-12">
                    <div class="table-responsive">
                        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                            <thead>
                                <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Name</th>
                                <th class="min-w-100px">Role/Department</th>
                                <th class="min-w-80px">Login/Logout</th>
                                <th class="min-w-80px">Date</th>
                                <th class="min-w-100px">Created By</th>
                                <th class="min-w-50px"><span>Status</span></th>
                                <th class="min-w-50px"><span class="text-end">Action</span></th>
                                </tr>
                            </thead>
                            <tbody class="text-black fw-semibold fs-7">
                                <div id="loader" style="display: none; text-align: center;">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Loading...</span>
                                </div>
                                </div>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<div class="modal fade" id="staffDetailModal" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
    data-bs-backdrop="static">
    <!--begin::Modal dialog-->
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <!--begin::Modal content-->
        <div class="modal-content rounded">
            <!--begin::Modal header-->
            <div class="modal-header justify-content-end border-0 pb-0">
                <!--begin::Close-->
                <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                    <span class="svg-icon svg-icon-1">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                transform="rotate(-45 6 17.3137)" fill="currentColor" />
                            <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->
                </div>
                <!--end::Close-->
            </div>
            <!--end::Modal header-->
            <!--begin::Modal body-->
            <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                <!--begin::Heading-->
                <div class="mb-4 text-center">
                    <h3 class="text-center mb-4 text-black">Staff Details</h3>
                </div>
                <div class="row g-4 align-items-center">
                  <div class="col-md-3 text-center">
                    <img id="staffModalImage" src="#" alt="Staff Image" class="img-thumbnail" />
                    <div class="mt-2 fw-bold" id="staffModalNick">N/A</div>
                  </div>
                  <div class="col-md-9 fs-5">
                    <div class="row mb-2 ">
                      <div class="col-6">
                        <div class="staff-data-label">Name</div>
                        <div class="staff-data-value" id="staffModalName">N/A</div>
                      </div>
                      <div class="col-6">
                        <div class="staff-data-label">Role</div>
                        <div class="staff-data-value" id="staffModalRole">N/A</div>
                      </div>
                    </div>
                    <div class="row mb-2 ">
                      <div class="col-6">
                        <div class="staff-data-label">Email</div>
                        <div class="staff-data-value" id="staffModalEmail">N/A</div>
                      </div>
                      <div class="col-6">
                        <div class="staff-data-label">Mobile</div>
                        <div class="staff-data-value" id="staffModalMobile">N/A</div>
                      </div>
                    </div>
                    <div class="row mb-2">
                      <div class="col-6">
                        <div class="staff-data-label">Branch</div>
                        <div class="staff-data-value" id="staffModalBranch">N/A</div>
                      </div>
                      <div class="col-6">
                        <div class="staff-data-label">Department</div>
                        <div class="staff-data-value" id="staffModalDepartment">N/A</div>
                      </div>
                    </div>
                    <div class="row mb-2">
                      <div class="col-6">
                        <div class="staff-data-label">Created By</div>
                        <div class="staff-data-value" id="staffModalCreatedBy">N/A</div>
                      </div>
                      <div class="col-6">
                        <div class="staff-data-label">Created Date</div>
                        <div class="staff-data-value" id="staffModalCreatedDate">N/A</div>
                      </div>
                    </div>
                    <div class="row mb-2">
                      <div class="col-6">
                        <div class="staff-data-label">User Name</div>
                        <div class="staff-credential" id="staffModalUsername">N/A</div>
                      </div>
                      <div class="col-6">
                        <div class="staff-data-label">Password</div>
                        <div class="staff-credential" id="staffModalPassword">N/A</div>
                      </div>
                    </div>
                  </div>
                </div>

            </div>
            <!--end::Modal body-->
        </div>
        <!--end::Modal content-->
    </div>
    <!--end::Modal dialog-->
</div>

<style>
    #staffModalImage {
    width: 150px;
    height: 150px;
    object-fit: cover;
    object-position: center;
    border-radius: 50%;
    }

    .staff-data-label {
        color: #6c757d; /* Muted grey for labels */
        font-weight: 500;
    }

    .staff-data-value {
        color: #1e1e2d; /* Dark bold value */
        font-weight: 600;
    }

    .staff-credential {
        color: #0056b3; /* Blue for username/password */
        font-weight: 700;
    }

</style>
<script>
$(document).ready(function () {
    fetchRoleList(); // Initial load

    $('#branchSelectsgoal').on('change', function () {
        fetchRoleList(); // Reload on branch change
    });
});

function fetchRoleList() {
    let branchId = $('#branchSelectsgoal').val();

    $('#loader').show(); // Show loader before request

    $.ajax({
        url: "{{ route('user_role_manage') }}",
        type: "GET",
        data: {
            branch_id: branchId
        },
        success: function (response) {
            let rows = '';
            let data = response.data || [];


            if (data.length === 0) {
                rows = `<tr><td colspan="5" class="text-center">No data available</td></tr>`;
                    // Handle no data
                    $('#management_staff').text('00');
                    $('#business_staff').text('00');
            } else {
                    let totalManagement = parseInt(response.management_staff || 0);
                    let totalBusiness = parseInt(response.business_staff || 0);
                data.forEach(function (item) {
                    
                     let staff_image = '';
                    if (item.staff_image && item.staff_image.trim() !== '' && item.staff_image.trim() !== 'N/A') {
                        if (item.company_type == 1) {
                            staff_image = `staff_images/Management/${item.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${item.staff_company_id}/${item.entity_id}/${item.staff_image}`;
                        }
                    } else {
                        staff_image = item.gender == 1
                            ? 'assets/egc_images/auth/user_2.png'
                            : 'assets/egc_images/auth/user_7.png';
                    }
                    staff_image = `{{ asset('${staff_image}') }}`;


                    let staffImage = '';
                    if (staff_image) {
                        staffImage = `
                            <div class="symbol symbol-35px me-2">
                                <div class="image-input border rounded-pill image-input-circle" data-kt-image-input="true">
                                    <img src="${staff_image}" alt="user-avatar" class="rounded-circle w-50px h-50px" />
                                </div>
                            </div>`;
                    } else {
                        // Build initials avatar with helper-generated image from backend if available
                        staffImage = `
                            <div class="symbol symbol-35px me-2">
                                ${item.name_image_html || ''} <!-- Make sure backend sends this pre-generated HTML -->
                            </div>`;
                    }

                    let genderIcon = '';
                    if (item.gender == 1) {
                        genderIcon = `<i class="mdi mdi-face-man text-info" data-bs-toggle="tooltip" title="Male"></i>`;
                    } else if (item.gender == 2) {
                        genderIcon = `<i class="mdi mdi-face-woman text-danger" data-bs-toggle="tooltip" title="Female"></i>`;
                    } else {
                        genderIcon = `<i class="mdi mdi-face-woman text-warning" data-bs-toggle="tooltip" title="Others"></i>`;
                    }

                   

                    let created_staff_image = '';
                    if (item.created_by_staff_image && item.created_by_staff_image.trim() !== '' && item.created_by_staff_image.trim() !== 'N/A') {
                        if (item.created_by_company_type == 1) {
                            created_staff_image = `staff_images/Management/${item.created_by_staff_image}`;
                        } else {
                            created_staff_image = `staff_images/Buisness/${item.created_by_company_id}/${item.created_by_entity_id}/${item.created_by_staff_image}`;
                        }
                    } else {
                        created_staff_image = item.created_by_gender == 1
                            ? 'assets/egc_images/auth/user_2.png'
                            : 'assets/egc_images/auth/user_7.png';
                    }
                    created_staff_image = `{{ asset('${created_staff_image}') }}`;

                    rows += `
                        <tr>
                            <td>
                                <div class="d-flex px-1">
                                    ${staffImage}
                                    <div class="mb-0">
                                        <label>
                                            <span class="fs-7 me-1">${item.staff_name}</span>
                                            ${genderIcon}
                                        </label>
                                        <div class="d-flex text-primary fs-8">
                                            <a href="javascript:;" class="text-primary fs-8" data-bs-toggle="tooltip" title="Staff Nick Name">${item.nick_name}</a>
                                            <div class="">
                                                <a href="javascript:;" class="dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                                    <i class="ms-1 mdi mdi-information fs-9"></i>
                                                </a>
                                                <div class="dropdown-menu py-2 px-4 text-black scroll-y w-400px max-h-250px">
                                                    <div class="row mt-4 mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Name</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fw-bold fs-8">${item.staff_name}</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Nick Name</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">${item.nick_name}</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Mob No</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">${item.mobile_no}</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Email ID</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">${item.email_id}</label>
                                                    </div>
                                                    <div class="row mb-2">
                                                        <label class="col-3 text-black fs-8 fw-semibold">Work</label>
                                                        <label class="col-1 text-black fs-8 fw-semibold">:</label>
                                                        <label class="col-8 text-black fs-8 fw-bold">${item.exp_type == 1 ? 'Fresher' : 'Experience'}</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-primary mb-1 fs-7" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Role Name">${item.role_name}</span><br>
                                <span class="badge bg-secondary fs-8" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Department Name">${item.department_name}</span>
                            </td>
                            <td>
                              <span
                                class="badge mb-1 fs-7 d-block"
                                style="background-color: #e8f0fe; color: #1a237e;"
                                data-bs-toggle="tooltip"
                                data-bs-placement="bottom"
                                title="Login Time">
                                ${item.login_time ?? '-'}
                              </span>
                              <span
                                class="badge fs-7 d-block"
                                style="background-color: #fce4ec; color: #880e4f;"
                                data-bs-toggle="tooltip"
                                data-bs-placement="bottom"
                                title="Logout Time">
                                ${item.logout_time ?? '-'}
                              </span>
                            </td>


                            <td>${item.created_date}</td>
                            <td>
                                <div class="d-flex align-items-center">
                                    ${item.created_by_staff_image !== 'N/A'
                                        ? `<div class="symbol symbol-35px me-2">
                                                <div class="image-input border rounded-pill image-input-circle">
                                                    <img src="${created_staff_image}"
                                                         alt="avatar"
                                                         class="rounded-circle w-50px h-50px" />
                                                </div>
                                           </div>`
                                        : `<div class="symbol symbol-35px me-2">
                                                ${item.created_by_nick_name.charAt(0).toUpperCase()}
                                           </div>`}
                                    <div class="d-flex flex-column">
                                        <span class="text-dark fw-bold">${item.created_by}</span>
                                        <span class="text-muted fs-8">${item.created_by_nick_name}</span>
                                    </div>
                                </div>
                            </td>
                            <td><label  class="btn btn-sm btn-info">Active</label></td>
                           <td><label class="btn btn-sm btn-primary" onclick="viewStaff(${item.sno})">View</label></td>
                        </tr>`;
                });


                function formatNumber(n) {
                    return n < 10 ? '0' + n : n;
                }

                $('#management_staff').text(formatNumber(totalManagement));
                $('#business_staff').text(formatNumber(totalBusiness));
            }

            $('.list_page tbody').html(rows);


        },
        complete: function () {
            $('#loader').hide(); // Hide loader after success or error
        },
        error: function () {
            $('.list_page tbody').html(`<tr><td colspan="7" class="text-center text-danger">Failed to load data</td></tr>`);
        }
    });
}
function viewStaff(id) {
    $.ajax({
        url: `/staff/view/${id}`,
        method: 'GET',
        success: function (response) {
            if (response.status === 200) {
                const staff = response.data;

                 let staff_image = '';
                    if (staff.staff_image && staff.staff_image.trim() !== '' && staff.staff_image.trim() !== 'N/A') {
                        if (staff.company_type == 1) {
                            staff_image = `staff_images/Management/${staff.staff_image}`;
                        } else {
                            staff_image = `staff_images/Buisness/${staff.staff_company_id}/${staff.entity_id}/${staff.staff_image}`;
                        }
                    } else {
                        staff_image = staff.gender == 1
                            ? 'assets/egc_images/auth/user_2.png'
                            : 'assets/egc_images/auth/user_7.png';
                    }
                    staff_image = `{{ asset('${staff_image}') }}`;
                // Populate modal or UI fields here
                $('#staffModalName').text(staff.staff_name);
                $('#staffModalImage').attr('src', `${staff_image}`);
                $('#staffModalBranch').text(staff.company_name);
                $('#staffModalRole').text(staff.role_name);
                $('#staffModalEmail').text(staff.email_id);
                $('#staffModalCreatedBy').text(staff.created_by);
                $('#staffModalNick').text(staff.nick_name);
                $('#staffModalDepartment').text(staff.department_name);
                $('#staffModalMobile').text(staff.mobile_no);
                 $('#staffModalUsername').text(staff.username);
                $('#staffModalPassword').text(staff.password);
                $('#staffModalCreatedDate').text(staff.created_date);
                // Show modal
                $('#staffDetailModal').modal('show');
            }
        },
        error: function () {
            toastr.error("Failed to fetch staff details.");
        }
    });
}

</script>
<style>
    .badges {
        display: inline-block;
        padding: 0.25em 0.6em;
        font-size: 0.75rem;
        border-radius: 0.25rem;
        color: #fff;
    }
.bg-primarys { background-color: #007bff; }
.bg-secondarys { background-color: #6c757d; }
</style>

@endsection
