<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CurrencyFormatModel extends Model
{
    use HasFactory;
    public $table = "egc_country_currencies";
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'country_name',
        'currency_code',
        'currency_name',
        'currency_symbol',
        'description',
        'rate_per',
        'created_at',
        'updated_at',
        'status',
    ];
}