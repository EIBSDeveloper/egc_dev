<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class SubErpWebhookModel extends Model {
    protected $table = 'egc_sub_erp_webhooks';
    protected $primaryKey = 'sno';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = true; // created_at, updated_at exist

    protected $fillable = ['name','company_id','entity_id','webhook_module','url','secret','headers','status','created_by','updated_by'];

    protected $casts = [
        'headers' => 'array',
        'status' => 'integer',
    ];
}
