<?php

namespace App\Http\Controllers\control_panel\user_management;

use App\Http\Controllers\Controller;
use App\Models\UserRolePermissionModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use App\Models\StaffModel;
use App\Models\User;
use App\Models\UserRoleModel;
use App\Models\DepartmentModel;
use App\Models\BranchModel;
use App\Models\CompanyModel;
use Illuminate\Support\Facades\DB;

class ManageUsers extends Controller
{
  public function index()
  {
    // $userpermission = UserRolePermissionModel::where('egc_user_role_permission.status', '!=', 2)
    //   ->join('egc_user_role', 'egc_user_role_permission.role_id', '=', 'egc_user_role.sno')
    //   ->select(
    //     'egc_user_role_permission.sno',
    //     'egc_user_role.sno as role_id',
    //     'egc_user_role.role_name',
    //     'egc_user_role_permission.status'
    //   )
    //   ->get();
    return view('content.control_panel.user_management.manage_users.manage_users_list');
  }

   
  public function List(Request $request)
  {
      $company_id = $request->company_id ?? $request->user()->company_id;
  
      // Get staff list for the branch
      $stafflist = StaffModel::where('status', 0)
          ->where('role_id', '>' ,1)
          ->where('company_id', $company_id)
          ->orderBy('sno', 'desc')
          ->get();
        // Department-wise staff counts for current staff's branch
          $management_staff = StaffModel::where('status', 0)
              ->where('role_id', '>' ,1)
              ->where('company_type', 1)
              ->count();
      
          $business_staff = StaffModel::where('status', 0)
                 ->where('company_type', 2)
              ->count();
      
      
  
      $staffData = $stafflist->map(function ($staff) {
              $CompanyId = $staff->company_id;
          
              
          
              // Related data
              $department = DepartmentModel::where('status', 0)->where('sno', $staff->department_id)->first();
              $user = User::where('user_id', $staff->sno)->first();
          
              $Company = $user
                  ? CompanyModel::where('status', 0)->where('sno', $user->company_id)->first()
                  : CompanyModel::where('status', 0)->where('sno', $staff->company_id)->first();
          
              $role = UserRoleModel::where('egc_user_role.status', 0)->where('sno', $staff->role_id)->first();
              $creator = StaffModel::where('sno', $staff->created_by)->first();
              
                // Fetch latest login log if available
              $loginLog = $user ? DB::table('user_login_logs')
                  ->where('user_id', $user->id)
                  ->latest('login_at')
                  ->first() : null;
          
              return [
                  'staff_name'                    => $staff->staff_name,
                  'sno'                           => $staff->sno,
                  'nick_name'                     => $staff->nick_name,
                  'staff_image'                   => $staff->staff_image,
                  'staff_company_id'                   => $staff->company_id ?? '0',
                  'entity_id'                   => $staff->entity_id ?? '0',
                  'company_type'                   => $staff->company_type ?? '1',
                  'email_id'                      => $staff->email_id,
                  'gender'                        => $staff->gender,
                  'mobile_no'                     => $staff->mobile_no,
                  'created_by'                    => $creator ? $creator->staff_name : 'N/A',
                  'created_by_company_type'       => $creator ? $creator->company_type : '1',
                  'created_by_company_id'       => $creator ? $creator->company_id : '0',
                  'created_by_entity_id'       => $creator ? $creator->entity_id : '0',
                  'created_by_gender'             => $creator ? $creator->gender : '1',
                  'created_by_staff_image'        => $creator ? $creator->staff_image : 'N/A',
                  'created_by_nick_name'          => $creator ? $creator->nick_name : 'N/A',
                  'created_date'                  => optional($staff->created_at)->format('d-M-Y'),
                  'role_name'                     => $role ? $role->role_name : 'N/A',
                  'company_name'                   => $Company ? $Company->company_name : 'N/A',
                  'branch_id'                     => $user ? $user->branch_id : 'N/A',
                  'company_id'                     => $user ? $user->company_id : 'N/A',
                  'id'                            => $user ? $user->id : 'N/A',
                  'original_branch_id'            => $staff->branch_id ?? 'N/A',
                  'department_name'               => $department ? $department->department_name : 'N/A',
                    // Login/Logout info
                  'login_time'                    => $loginLog && $loginLog->login_at ? \Carbon\Carbon::parse($loginLog->login_at)->format('d-M-Y h:i A') : '-',
                  'logout_time'                   => $loginLog && $loginLog->logout_at ? \Carbon\Carbon::parse($loginLog->logout_at)->format('d-M-Y h:i A') : '-',
                  
              ];
          });

  
      return response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $staffData,
          'management_staff'                   => $management_staff,
          'business_staff'              => $business_staff,
      ], 200);
  }
    
   public function View(Request $request, $id)
  {
    $staff = StaffModel::where('sno', $id)->where('status', 0)->first();

    if (!$staff) {
        return response()->json([
            'status' => 404,
            'message' => 'Staff not found'
        ], 404);
    }

    $user = User::where('user_id', $staff->sno)->first();
    $branch = $user
        ? BranchModel::where('status', 0)->where('sno', $user->branch_id)->first()
        : BranchModel::where('status', 0)->where('sno', $staff->branch_id)->first();

    $role = UserRoleModel::where('status', 0)->where('sno', $staff->role_id)->first();
    $department = DepartmentModel::where('status', 0)->where('sno', $staff->department_id)->first();
    $creator = StaffModel::where('sno', $staff->created_by)->first();

    return response()->json([
        'status' => 200,
        'data' => [
            'staff_name' => $staff->staff_name,
            'nick_name' => $staff->nick_name,
            'staff_image' => $staff->staff_image,
            'email_id' => $staff->email_id,
            'mobile_no' => $staff->mobile_no,
            'username' => $staff->user_name,
            'password' => $staff->password,
            'gender' => $staff->gender,
            'created_by' => $creator?->staff_name ?? 'N/A',
            'created_by_nick_name' => $creator?->nick_name ?? 'N/A',
            'created_by_staff_image' => $creator?->staff_image ?? 'N/A',
            'branch_name' => $branch ? ($branch->franchise_name ?: $branch->branch_name) : 'N/A',
            'role_name' => $role->role_name ?? 'N/A',
            'department_name' => $department->department_name ?? 'N/A',
            'created_date' => optional($staff->created_at)->format('d-M-Y'),
        ]
    ]);
  }

  
}