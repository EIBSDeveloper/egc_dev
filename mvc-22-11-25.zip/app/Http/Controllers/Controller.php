<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Helpers\Helpers;
use App\Models\GeneralSettingsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, ValidatesRequests;

    public function __construct(Request $request)
    {
        // $this->middleware(function ($request, $next) {
        //     if (Auth::check()) {
        //         $this->shareCommonData($request->user());
        //     }
        //     return $next($request);
        // });
        // Share common data with all views
        $this->shareCommonData();
        // self::$branch_id = $request->user()->branch_id;
        // $branchId = Auth::user()->branch_id;
    }

    protected function shareCommonData()
    {
        $general = GeneralSettingsModel::first();
        $helper = new Helpers();

        $logoUrl = $general ? $helper->Logo_pic($general->logo) : null;
        $favUrl = $general ? $helper->Fav_Icon_pic($general->fav_icon) : null;
        $title   = $general ? $general->title : null;
        // Share data with all views
        view()->share([
            'title' => $title,
            'logoUrl' => $logoUrl,
            'favUrl' => $favUrl,
        ]);
    }
}
