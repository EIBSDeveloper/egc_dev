/*
  Add custom scripts here
*/

import.meta.glob([
  '../assets/img/**',
  './socket',
  // '../assets/json/**',
  '../assets/vendor/fonts/**'
]);
