@extends('layouts/layoutMaster')

@section('title', 'Manage Company')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.scss', 'resources/assets/vendor/libs/select2/select2.scss'])
@endsection

@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js', 'resources/assets/vendor/libs/bs-stepper/bs-stepper.js', 'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js'])
@endsection

@section('content')
    <style>
        .dataTables_scroll {
            max-height: 200px;
        }
        
    </style>

    <!-- Lead List Table -->
    <div class="card card-action">
        <div class="card-header border-bottom pb-1 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-start justify-content-start flex-column">
                <h5 class="card-title mb-1 text-black">Manage Company</h5>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb custom-breadcrumb">
                        <!-- Home -->
                        <li class="breadcrumb-item">
                            <a href="{{ url('/dashboard') }}">
                                <i class="mdi mdi-home"></i> Home
                            </a>
                        </li>
                        <li class="breadcrumb-item" aria-current="page">
                            <a href="javascript:void(0);">
                                <i class="mdi mdi-monitor-dashboard"></i> Control Panel
                            </a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">
                            <a href="javascript:void(0);" class="active-link">
                                Entity Hub
                            </a>
                        </li>
                    </ol>
                </nav>
            </div>
            <div>
                <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                    <a href="javascript:;" class="btn btn-sm fw-bold btn-primary text-white" data-bs-toggle="modal"
                        data-bs-target="#kt_modal_create_company">
                        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Company
                    </a>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="d-flex align-items-center justify-content-between mb-4 ">
                        <div>
                            <span>Show</span>
                            <select id="perpage" class="form-select form-select-sm w-75px"
                                onchange="loadThemes(1)">
                                @php $options = [6,10, 25, 100, 500]; @endphp
                                @foreach ($options as $option)
                                    <option value="{{ $option }}" {{ $perpage == $option ? 'selected' : '' }}>
                                        {{ $option }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                            <div class="searchBar">
                                <input type="text" id="search_filter" class="searchQueryInput"
                                    placeholder="Search Company..."
                                    value="{{ $search_filter }}"/>
                                
                                <div class="searchAction">
                                    <div class="d-flex align-items-center">
                                        <a href="javascript:;"  class="searchSubmit" id="searchSubmit" >
                                            <span class="mdi mdi-magnify fs-4 fw-bold"  style="color:#ab2b22;"></span>
                                        </a>
                                        <a href="javascript:;" class="refreshBar" id="refreshSearch" >
                                            <span class="mdi mdi-refresh fs-4 fw-bold" style="color:#ab2b22;"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <table class="table align-middle table-row-dashed  table-striped table-hover gy-0 gs-1 list_page">
                        <thead>
                            <tr class="text-start align-top  fw-bold fs-6 gs-0 bg-primary">
                                <th class="min-w-150px">Company</th>
                                <th class="min-w-100px">Email ID</th>
                                <th class="min-w-100px">Contact Person / Mobile</th>
                                <th class="min-w-50px">Status</th>
                                <th class="min-w-100px text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody id="company-table-body" class="text-black fw-semibold fs-7">
                            <tr class="skeleton-loader" id="skeleton-loader">
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                                <td class="skeleton-cell">
                                    <div class="skeleton"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="text-center my-3" id="pagination-container">
                    <!-- Pagination buttons will appear here -->
                </div>
            </div>
        </div>
    </div>





    <!--begin::Modal - Create Company -->
    <div class="modal fade" id="kt_modal_create_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Company</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form method="POST" action="{{ route('add_company') }}" id="add_form" autocomplete="off" enctype="multipart/form-data">
                        @csrf
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" name="company_name" id="company_name" class="form-control" placeholder="Enter Company Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });"maxlength="50" />
                                <div class="error_msg text-danger" id="company_name_err"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Short Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="company_short_name" name="company_short_name" placeholder="Enter Company Short Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="6"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" name="company_type" id="company_type">
                                    <option value="">Select Company Type</option>
                                    @if (isset($Company_type_list))
                                        @foreach ($Company_type_list as $type_list)
                                            <option value="{{ $type_list->sno }}">{{ $type_list->company_type_name }}
                                                ({{ $type_list->slug_name }})
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control"  placeholder="Enter Email ID" id="company_mail" name="company_mail" oninput=" this.value = this.value.toLowerCase();"maxlength="50" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Website URL" id="website_url" name="website_url" maxlength="80" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="ct_person" name="ct_person" placeholder="Enter Contact Person Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" maxlength="10" placeholder="Enter Contact Person Mobile No" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="ct_per_mobile_no" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="countryId" name="country">
                                    <option value="">Select Country</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                        class="text-danger">*</span></label>
                                <select class="select3 form-select" id="stateId" name="state">
                                    <option value="">Select State</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                                <select class="select3 form-select" id="cityId" name="city">
                                    <option value="">Select City</option>
                                </select>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Area / Street"  id="area_street" name="area_street" maxlength="50" />
                                 <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Door/Flat No" id="door_flat_no" name="door_flat_no" maxlength="50"/>
                                 <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Pincode" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="pincode" name="pincode" maxlength="20"/>
                                 <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">GST No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter GST No" id="gst_no"
                                    name="gst_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter CIN No" id="cin_no"
                                    name="cin_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">PAN No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter PAN No" id="pan_no"
                                    name="pan_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                            
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Color<span
                                        class="text-danger">*</span></label>
                                <input type="color" class="form-control" id="company_base_color" name="company_base_color" placeholder="Enter Company Color">
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                                <textarea class="form-control h-auto" rows="1" placeholder="Enter Description" id="company_desc" name="company_desc" maxlength="350"></textarea>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <div class="row">
                                    <label class="col-lg-1 text-black fs-6 fw-semibold">Logo<span class="text-danger">*</span></label>
                                    <div class="col-lg-11 ps-5">
                                        <div class="align-items-sm-center gap-4">
                                            <img src="{{asset('assets/common/logo_small.png')}}" alt="Fav Icon"
                                                class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                                id="logo_create" />
                                            <div class="button-wrapper">
                                                <div class="d-flex align-items-start mt-2 mb-2">
                                                    <label for="fav_upload" class="btn btn-sm btn-primary me-2" tabindex="0"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Fav Icon">
                                                        <i class="mdi mdi-tray-arrow-up"></i>
                                                        <input type="file" name="fav_icon" id="fav_upload" class="fav_file-in"
                                                            hidden accept="image/png, image/jpeg" />
                                                    </label>
                                                    <button type="button" class="btn btn-sm btn-outline-danger fav_file-reset"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Fav Icon">
                                                        <i class="mdi mdi-reload"></i>
                                                    </button>
                                                </div>
                                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                            </div>
                                        </div>
                                        <div class="error_msg text-danger"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" value="1" name="company_in_menu" id="company_in_menu" />Company Menu
                                </label>
                            </div>
                        </div>
                        <div class="divider">
                            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                        </div>
                        <div class="row mb-6">
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Name" id="comapny_bank_name" name="comapny_bank_name" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Bank Branch Name" id="comapny_bank_branch" name="comapny_bank_branch" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account Holder" id="comapny_acc_holder" name="comapny_acc_holder" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter Account No" id="comapny_acc_no" name="comapny_acc_no" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                            <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" placeholder="Enter IFSC Code" id="comapny_bank_ifsc" name="comapny_bank_ifsc" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                            </div>
                        </div>
                        <div class="divider">
                            <div class="text-black mb-4 fs-5 fw-semibold divider-text">Social Media</div>
                        </div>
                        <div class="row mb-6">
                            @if(isset($social_media_list))
                                @foreach($social_media_list as $slist)
                                <div class="col-lg-4 mb-3">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input toggle-field" type="checkbox" id="checkSocialMedia_{{$slist->sno}}" data-target="#socialMediaField_{{$slist->sno}}">
                                        <label class="text-black mb-1 fs-6 fw-semibold" for="checkSocialMedia_{{$slist->sno}}">{{$slist->social_media_name}}</label>
                                    </div>
                                    <div id="socialMediaField_{{$slist->sno}}" class="d-none">
                                        <input type="text" class="form-control" name="social_media[{{$slist->sno}}]" placeholder="Enter {{$slist->social_media_name}} URL" />
                                    </div>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                @endforeach
                            @endif
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" id="company_create_btn" class="btn btn-primary" onclick="AddvalidateForm()">Create Company</button>
                        </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Company-->



    <!--begin::Modal - Update Company -->
    <div class="modal fade" id="kt_modal_update_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Company</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 ">
                    <!--begin::Heading-->
                    <form method="POST" action="{{ route('update_company') }}" id="edit_form" autocomplete="off" enctype="multipart/form-data">
                        @csrf
                    <div class="row mb-6">
                        <input type="hidden" id="edit_id" name="edit_id" />
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Company Name" name="company_name" id="edit_company_name"
                                 oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                            <div class="error_msg text-danger" id="edit_company_name_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                                <label class="text-black mb-1 fs-6 fw-semibold">Company Short Name<span
                                        class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="edit_company_short_name" name="company_short_name" placeholder="Enter Company Short Name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="6"/>
                                <div class="error_msg text-danger"></div>
                            </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Type<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select"  name="company_type" id="edit_company_type">
                                <option value="">Select Company Type</option>
                                    @if (isset($Company_type_list))
                                        @foreach ($Company_type_list as $type_list)
                                            <option value="{{ $type_list->sno }}">{{ $type_list->company_type_name }}
                                                ({{ $type_list->slug_name }})
                                            </option>
                                        @endforeach
                                    @endif
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID"
                               id="edit_company_mail" name="company_mail"
                                    oninput=" this.value = this.value.toLowerCase();" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL"
                                 id="edit_website_url" name="website_url"maxlength="80" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name"
                                id="edit_ct_person" name="ct_person"
                                    oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No"
                               maxlength="10"
                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="edit_ct_per_mobile_no" name="ct_per_mobile_no" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="edit_countryId" name="country">
                                <option value="">Select Country</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="edit_stateId" name="state" >
                                <option value="">Select State</option>
                            </select>
                             <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select" id="edit_cityId" name="city">
                                <option value="">Select City</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street"
                                  id="edit_area_street" name="area_street" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No"
                                id="edit_door_flat_no" name="door_flat_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="edit_pincode" name="pincode" maxlength="20"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter GST No"
                               id="edit_gst_no" name="gst_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CIN No"
                                id="edit_cin_no"
                                    name="cin_no" maxlength="50"/>
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" id="edit_pan_no"
                                    name="pan_no"maxlength="50" />
                                <div class="error_msg text-danger"></div>
                        </div>
                       
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company Color<span
                                    class="text-danger">*</span></label>
                            <input type="color" class="form-control" id="edit_company_base_color" name="company_base_color" placeholder="Enter Company Color"
                               >
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" rows="1" placeholder="Enter Description" id="edit_company_desc" name="company_desc" maxlength="100">-</textarea>
                        </div>
                         <input type="hidden" name="old_company_image" id="old_company_image">
                        <div class="col-lg-4 mb-3">
                            <div class="row">
                                <label class="col-lg-1 text-black fs-6 fw-semibold">Logo<span class="text-danger">*</span></label>
                                <div class="col-lg-11 ps-5">
                                    <div class="align-items-sm-center gap-4">
                                        <img src="{{ asset('assets/common/logo_small.png') }}" alt="user-avatar"
                                            class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                            id="logo_update" />
                                        <div class="button-wrapper">
                                            <div class="d-flex align-items-start mt-2 mb-2">
                                                <label for="upload" class="btn btn-sm btn-primary me-2" tabindex="0"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                                    <i class="mdi mdi-tray-arrow-up"></i>
                                                    <input type="file" name="logo" id="upload" class="file-in"
                                                        hidden accept="image/png, image/jpeg" />
                                                </label>

                                                <button type="button" class="btn btn-sm btn-outline-danger file-reset"
                                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                                    <i class="mdi mdi-reload"></i>
                                                </button>
                                            </div>
                                            <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                        </div>
                                    </div>
                                     <div class="error_msg text-danger"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" name="company_in_menu" id="edit_company_in_menu" value="1" />Company Menu
                            </label>
                        </div>
                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name" id="edit_comapny_bank_name" name="comapny_bank_name" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name"
                                id="edit_comapny_bank_branch" name="comapny_bank_branch" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder"
                                id="edit_comapny_acc_holder" name="comapny_acc_holder" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No"
                                id="edit_comapny_acc_no" name="comapny_acc_no" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code"
                                 id="edit_comapny_bank_ifsc" name="comapny_bank_ifsc" maxlength="20" />
                                <div class="error_msg text-danger"></div>
                        </div>
                    </div>
                     <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Social Media</div>
                    </div>
                    <div class="row mb-6" id="socialRow2">
                        @if(isset($social_media_list))
                                @foreach($social_media_list as $slist)
                                <div class="col-lg-4 mb-3">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input toggle-field-edit" type="checkbox" id="edit_checkSocialMedia_{{$slist->sno}}" data-target="#edit_socialMediaField_{{$slist->sno}}">
                                        <label class="text-black mb-1 fs-6 fw-semibold" for="edit_checkSocialMedia_{{$slist->sno}}">{{$slist->social_media_name}}</label>
                                    </div>
                                    <div id="edit_socialMediaField_{{$slist->sno}}" class="d-none">
                                        <input type="text" class="form-control" name="social_media[{{$slist->sno}}]" placeholder="Enter {{$slist->social_media_name}} URL" />
                                    </div>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                @endforeach
                            @endif
                       

                       

                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="update_company_btn" class="btn btn-primary"  onclick="EditvalidateForm()">Update Company</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Update Company-->

    <!--begin::Modal View Company--->
    <div class="modal fade" id="kt_modal_view_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-lg">
            <!--begin::Modal content-->
            <div class="modal-content rounded" style="background: linear-gradient(225deg, white 20%, #fba919 100%);">
                <!--begin::Close-->
                <div class="d-flex justify-content-end px-2 py-2">
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                </div>
                <!--end::Close-->
                <!--begin::Modal header-->
                <div class="modal-header d-flex align-items-center justify-content-between border-bottom-1">
                    <div class="d-flex align-items-center mb-2 gap-2">
                        <div class="avatar-stack">
                            <img src="{{ asset('assets/common/logo_small.png') }}" id="view_company_logo" alt="user-avatar"
                                class="avatar-img" />
                        </div>
                        <div class="">
                            <span class="text-black fw-semibold fs-3">View Company</span>
                        </div>
                    </div>
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20 bg-white">
                    <input type="hidden" id="sts_change_id" name="sts_change_id" />
                    <div class="row mb-3">
                        <div class="nav-align-top nav-tabs-shadow mb-3">
                            <ul class="nav nav-tabs" role="tablist">
                                <li class="nav-item">
                                    <button type="button" class="nav-link active" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#basic_info" aria-controls="basic_info" aria-selected="true">
                                        Company Info
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#legaltax" aria-controls="legaltax" aria-selected="false">
                                        Legal / Tax
                                    </button>
                                </li>
                                <li class="nav-item">
                                    <button type="button" class="nav-link" role="tab" data-bs-toggle="tab"
                                        data-bs-target="#bankinfo" aria-controls="bankinfo" aria-selected="false">
                                        Bank Info
                                    </button>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="basic_info" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5  text-dark fs-7 fw-semibold">Company</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                 <div class="skeleton-loader-view max-w-75" id="view_companyname_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_companyname" style="display:none;">
                                                    Elysian Intelligence Business Solution
                                                </div>
                                            </div>
                                        </div>

                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Company Type</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_companytype_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_companytype" style="display:none;">Private
                                                    Limited Company (Pvt Ltd)
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Email ID</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_emailid_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_emailid" style="display:none;">info@eibsglobal.com</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-6 fw-semibold">Website URL</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_website_tag_skeleton"></div>
                                                <a href="" target="_blank"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" class="view-data"
                                                    title="" id="view_website_tag" style="display:none;">
                                                    <div class="text-truncate max-w-75 text-black fs-7  fw-semibold" id="view_website">
                                                        https://eibsglobal.com/</div>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Contact Person</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_contactperson_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6  fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_contactperson" style="display:none;">
                                                    Sankar Ganesh</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">C.P. Mobile No</label>
                                            <label class="col-1 text-black fs-7  fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" id="view_cp_mobileno_skeleton"></label>
                                            <label class="text-black fs-6 fw-semibold view-data" id="view_cp_mobileno" style="display:none;">9894444710</label>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 fw-semibold fs-7 text-dark">Description</label>
                                            <label class="col-1 fw-semibold fs-7">:</label>
                                            <div class="col-6">
                                            <label class="skeleton-loader-view max-w-75" id="view_description_skeleton"></label>
                                            <label class="fw-semibold fs-6 text-black view-data" id="view_description" style="display:none;">-</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="legaltax" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">GST No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_gstno_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_gstno" style="display:none;">
                                                    27AABCU9603R1ZV</div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">CIN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_cinno_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_cinno" style="display:none;">U12345MH2005PTC123456
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">PAN No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <div class="skeleton-loader-view max-w-75" id="view_panno_skeleton"></div>
                                                <div class="text-truncate max-w-75 text-black fs-6 fw-semibold view-data"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="" id="view_panno" style="display:none;">
                                                    AABCU9603R</div>
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="bankinfo" role="tabpanel">
                                <div class="row ">
                                    <div class="col-lg-12">
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Bank</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" id="view_bank_skeleton"></label>
                                                <label class=" text-black fs-6 fw-semibold view-data" id="view_bank" style="display:none;">HDFC</label>
                                            </div>
                                            
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Branch</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class="skeleton-loader-view max-w-75" id="view_branch_skeleton"></label>
                                                <label class="text-black fs-6 fw-semibold view-data" id="view_branch" style="display:none;">Anna Nagar</label>
                                            </div>
                                           
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">IFSC Code</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" id="view_ifsccode_skeleton"></label>
                                                <label class=" text-black fs-6 fw-semibold view-data" id="view_ifsccode" style="display:none;">HDFC0002027</label>
                                            </div>
                                            
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account Holder</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                                <label class=" skeleton-loader-view max-w-75" id="view_accountholder_skeleton"></label>
                                                <label class=" text-black fs-6 fw-semibold view-data" id="view_accountholder" style="display:none;">Elysium Intelligence Business
                                                Solutions</label>
                                            </div>
                                            
                                        </div>
                                        <div class="row mb-4">
                                            <label class="col-5 text-dark fs-7 fw-semibold">Account No</label>
                                            <label class="col-1 text-black fs-7 fw-semibold">:</label>
                                            <div class="col-6">
                                            <label class=" skeleton-loader-view max-w-75" id="view_accountno_skeleton"></label>
                                            <label class=" text-black fs-6 fw-semibold view-data" id="view_accountno"style="display:none;">8574854578452</label>
                                            </div>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal View Company-->


    <!--begin::Modal - Create Entity -->
    <div class="modal fade" id="kt_modal_create_entity" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-xl">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Entity</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary border rounded border-gray-200"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opa Credential Book="0.5" x="6" y="17.3137" width="16" height="2"
                                    rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="currentColor" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <form method="POST" action="{{ route('add_entity') }}" id="add_entity_form" autocomplete="off" enctype="multipart/form-data">
                        @csrf
                    <div class="row mb-6">
                        <input type="hidden" name="company_id" id="entity_company_id">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Company<span
                                    class="text-danger">*</span></label>
                            <div>
                                <label class="fw-bold fs-5" id="entity_company_name"></label>
                                <div class="error_msg text-danger" id="entity_company_name_err"></div>
                            </div>
                            <!--<select class="select3 form-select">-->
                            <!--    <option value="">Select Company</option>-->
                            <!--    <option value="1">Elysium Technologies Pvt Ltd</option>-->
                            <!--</select>-->
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Name" name="entity_name" id="entity_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50" />
                            <div class="error_msg text-danger" id="entity_name_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Entity Short Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Entity Short Name"  name="entity_short_name" id="entity_short_name" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="6"/>
                            <div class="error_msg text-danger" id="entity_short_name_err"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Email ID<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Email ID" id="entity_mail" name="entity_mail" oninput=" this.value = this.value.toLowerCase();" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Website URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Website URL" id="entity_website_url" name="website_url" maxlength="80"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">ERP Base URL<span class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter CRM URL"  id="entity_base_url" name="entity_base_url" >
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Location URL<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="entity_location_url" name="location_url" 
                                placeholder="Enter Location URL" >
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Name" id="entity_ct_person" name="ct_person" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Contact Person Mobile No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Contact Person Mobile No" maxlength="10"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="entity_ct_per_mobile_no" name="ct_per_mobile_no" />
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Country<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="entity_countryId" name="country">
                                <option value="">Select Country</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">State<span
                                    class="text-danger">*</span></label>
                            <select class="select3 form-select" id="entity_stateId" name="state">
                                <option value="">Select State</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">City<span class="text-danger">*</span></label>
                            <select class="select3 form-select" id="entity_cityId" name="city">
                                <option value="">Select City</option>
                            </select>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Area / Street<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Area / Street" id="entity_area_street" name="area_street" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Door/Flat No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Door/Flat No" id="entity_door_flat_no" name="door_flat_no" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Pincode<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Pincode"  oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                    id="entity_pincode" name="pincode" maxlength="10" />
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">GST No</label>
                            <input type="text" class="form-control" placeholder="Enter GST No" id="entity_gst_no" name="gst_no" maxlength="30" />
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">CIN No</label>
                            <input type="text" class="form-control" placeholder="Enter CIN No" id="entity_cin_no" name="cin_no" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">PAN No</label>
                            <input type="text" class="form-control" placeholder="Enter PAN No" id="entity_pan_no" name="pan_no" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Description</label>
                            <textarea class="form-control h-auto" rows="1" placeholder="Enter Description" id="entity_desc" name="entity_desc" maxlength="80"></textarea>
                        </div>
                         <div class="col-lg-4 mb-3">
                                <div class="row">
                                    <label class="col-lg-1 text-black fs-6 fw-semibold">Logo<span class="text-danger">*</span></label>
                                    <div class="col-lg-11 ps-5">
                                        <div class="align-items-sm-center gap-4">
                                            <img src="{{asset('assets/common/logo_small.png')}}"
                                                alt="entity-logo"
                                                class="d-block w-px-120 h-px-120 rounded border border-gray-600 border-solid"
                                                id="logo_entity" />

                                            <div class="button-wrapper">
                                                <div class="d-flex align-items-start mt-2 mb-2">
                                                    <label for="uploadEntity" class="btn btn-sm btn-primary me-2" tabindex="0"
                                                          data-bs-toggle="tooltip" data-bs-placement="top" title="Upload Logo">
                                                        <i class="mdi mdi-tray-arrow-up"></i>
                                                        <input type="file" name="entity_logo" id="uploadEntity"
                                                              class="file-in-entity" hidden accept="image/png, image/jpeg" />
                                                    </label>

                                                    <button type="button" class="btn btn-sm btn-outline-danger file-reset-entity"
                                                            data-bs-toggle="tooltip" data-bs-placement="top" title="Reset Logo">
                                                        <i class="mdi mdi-reload"></i>
                                                    </button>
                                                </div>
                                                <div class="small">Allowed JPG, PNG. Max size of 800K</div>
                                            </div>
                                        </div>
                                        <div class="error_msg text-danger"></div>
                                    </div>
                                </div>
                            </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" name="entity_in_menu" id="entity_in_menu" value="1" />Entity Menu
                            </label>
                        </div>

                    </div>
                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Bank Details</div>
                    </div>
                    <div class="row mb-6">
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Name"  id="entity_bank_name" name="comapny_bank_name" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Bank Branch Name<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Bank Branch Name" id="entity_bank_branch" name="comapny_bank_branch" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account Holder<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account Holder" id="entity_acc_holder" name="comapny_acc_holder" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">Account No<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Account No" id="entity_acc_no" name="comapny_acc_no" maxlength="50"/>
                             <div class="error_msg text-danger"></div>
                        </div>
                        <div class="col-lg-4 mb-3">
                            <label class="text-black mb-1 fs-6 fw-semibold">IFSC Code<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter IFSC Code" id="entity_bank_ifsc" name="comapny_bank_ifsc" maxlength="50"/>
                            <div class="error_msg text-danger"></div>
                        </div>
                    </div>

                    <div class="divider">
                        <div class="text-black mb-4 fs-5 fw-semibold divider-text">Social Media</div>
                    </div>
                   <div class="row mb-6" id="socialRow1">
                            @if(isset($social_media_list))
                                @foreach($social_media_list as $slist)
                                <div class="col-lg-4 mb-3">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input toggle-field-entity" type="checkbox" id="entitycheckSocialMedia_{{$slist->sno}}" data-target="#entitysocialMediaField_{{$slist->sno}}">
                                        <label class="text-black mb-1 fs-6 fw-semibold" for="entitycheckSocialMedia_{{$slist->sno}}">{{$slist->social_media_name}}</label>
                                    </div>
                                    <div id="entitysocialMediaField_{{$slist->sno}}" class="d-none">
                                        <input type="text" class="form-control" name="social_media[{{$slist->sno}}]" placeholder="Enter {{$slist->social_media_name}} URL" />
                                    </div>
                                    <div class="error_msg text-danger"></div>
                                </div>
                                @endforeach
                            @endif
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary" onclick="AddEntityvalidateForm()" id="complete_entity_btn">Create Entity</button>
                    </div>
                    </form>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Create Entity-->



    <!--begin::Modal - Delete -->
    <div class="modal fade" id="kt_modal_delete_company" tabindex="-1" aria-hidden="true" data-bs-keyboard="false"
        data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Elysian
                            Intelligence Business Solution </b>
                        Company ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center pt-8 mb-4">
                    <button type="submit" class="btn btn-danger me-3" onclick="deleteDepartmentCategory()">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete -->

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>
    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

{{-- create's social media --}}
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".toggle-field").forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            const target = document.querySelector(this.dataset.target);
            if (this.checked) {
                target.classList.remove("d-none");
            } else {
                target.classList.add("d-none");
            }
        });
    });
});
</script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".toggle-field-edit").forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            const target = document.querySelector(this.dataset.target);
            if (this.checked) {
                target.classList.remove("d-none");
            } else {
                target.classList.add("d-none");
            }
        });
    });
});
</script>

{{-- entity's social media --}}
<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll(".toggle-field-entity").forEach(function(checkbox) {
        checkbox.addEventListener("change", function() {
            const target = document.querySelector(this.dataset.target);
            if (this.checked) {
                target.classList.remove("d-none");
            } else {
                target.classList.add("d-none");
            }
        });
    });
});
</script>

{{-- update's social media --}}
<script>
    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll(".toggle-field-2").forEach(function(checkbox) {
            checkbox.addEventListener("change", function() {
                const target = document.querySelector(this.dataset.target);
                if (this.checked) {
                    target.classList.remove("d-none");
                } else {
                    target.classList.add("d-none");
                }
            });
        });
    });
</script>

    <script>
        $(".list_page").DataTable({
            "ordering": false,
            "pageLength": 25,
            // "aaSorting":[],
            "language": {
                "lengthMenu": "Show _MENU_",
            },
            "dom": "<'row mb-3'" +
                //"<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
                //"<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
                ">" +

                "<'table-responsive'tr>" +

                "<'row'" +
                //"<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
                //"<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
                ">"
        });
    </script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    const logoFileInput = document.querySelector('.file-in');
    const logoResetButton = document.querySelector('.file-reset');
    const faviconFileInput = document.querySelector('.fav_file-in');
    const faviconResetButton = document.querySelector('.fav_file-reset');
    const entityFileInput = document.querySelector('.file-in-entity');
    const entityReset = document.querySelector('.file-reset-entity');


     logoResetButton.addEventListener('click', function() {
        const logoImage = document.getElementById('logo_update');
        const resetLogoImage = '/assets/common/logo_small.png';  // Default image
        logoImage.src = resetLogoImage;  // Reset the image to default
        logoFileInput.value = null;  // Clear the file input
    });

    // Function to preview Update image
    logoFileInput.addEventListener('change', function() {
        const logoImage = document.getElementById('logo_update');
        if (this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                logoImage.src = e.target.result;  // Display the selected image
            };
            reader.readAsDataURL(this.files[0]);
        }
    });


   entityReset.addEventListener('click', function() {
    const entityImage = document.getElementById('logo_entity');
    const resetEntityImage = "{{ asset('assets/eapl_images/default_entity.png') }}"; // default image
    entityImage.src = resetEntityImage;
    entityFileInput.value = null;
});
    // Function to reset favicon image and input
    faviconResetButton.addEventListener('click', function() {
        const faviconImage = document.getElementById('logo_create');
        const resetFaviconImage =
            "{{ asset('assets/common/logo_small.png') }}";
        faviconImage.src = resetFaviconImage;
        faviconFileInput.value = null;
    });



   entityFileInput.addEventListener('change', function() {
    const entityImage = document.getElementById('logo_entity');
    if (this.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
            entityImage.src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
    }
});

    // Function to preview Create image
    faviconFileInput.addEventListener('change', function() {
        const faviconImage = document.getElementById('logo_create');
        if (this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                faviconImage.src = e.target.result;
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
});
</script>

<script>
    let currentPage = 1;
    let isLoading = false;
    let abortController = new AbortController();

    function formatDate(date) {
        const options = { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
        return new Date(date).toLocaleDateString('en-GB', options);
    }

    function buildRow(item) {
        return `
            <tr>
                <td>
                    <div class="d-flex allign-items-center gap-2">
                        <div>
                            <div class="d-flex align-items-center">
                                <div class="text-truncate max-w-175px" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.company_name}">
                                    ${item.company_name}
                                </div>
                                <a href="${item.company_website}" target="_blank" class="ms-1" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Website URL">
                                    <i class="mdi mdi-web fs-4 text-dark"></i>
                                </a>
                            </div>
                            <div class="d-block">
                                <label class="badge bg-warning fs-8 text-black fw-bold">${item.company_type_name}</label>
                            </div>
                        </div>
                        <label data-bs-toggle="modal" data-bs-target="#kt_modal_location_map">
                            <i class="mdi mdi-map-marker-radius fs-4 text-dark" data-bs-toggle="tooltip" data-bs-placement="bottom" title="${item.company_address}"></i>
                        </label>
                    </div>
                </td>
                <td>${item.company_mail}</td>
                <td>
                    <label>${item.company_ct_person}</label>
                    <div class="d-block">
                        <label class="fs-8 text-black fw-semibold">${item.company_ct_number}</label>
                    </div>
                </td>
                <td>
                    <label class="switch switch-square">
                        <input type="checkbox" class="switch-input" ${item.status == 0 ? 'checked' : ''} onchange="updatelevelStatus('${item.sno}', this.checked)"/>
                        <span class="switch-toggle-slider">
                            <span class="switch-on"></span>
                            <span class="switch-off"></span>
                        </span>
                    </label>
                </td>
                <td class="text-center">
                    <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal" data-bs-target="#kt_modal_create_entity" onclick="addEntityModel('${item.sno}','${item.company_name}')" >
                        <i class="mdi mdi-source-branch-plus fs-3 text-black me-1"></i>
                    </a>
                    <a href="{{ url('/branch/add') }}" class="btn btn-icon btn-sm">
                        <span data-bs-toggle="tooltip" data-bs-placement="bottom" title="Add Branch"> <i class="mdi mdi-plus-network-outline fs-3 text-black me-1"></i></span>
                    </a>
                    <a class="btn btn-icon btn-sm" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="mdi mdi-dots-vertical fs-3 text-black"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end" style="width: 200px !important">
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_view_company"  onclick="viewmodel('${item.sno}')">
                            <span><i class="mdi mdi-eye fs-3 text-black me-1"></i>View</span>
                        </a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_update_company"  onclick="editmodel('${item.sno}')" >
                            <span><i class="mdi mdi-square-edit-outline fs-3 text-black me-1"></i>Edit</span>
                        </a>
                        <a href="javascript:;" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#kt_modal_delete_company" onclick="confirmDelete('${item.sno}','${item.company_name}')">
                            <span><i class="mdi mdi-delete-outline fs-3 text-black me-1"></i>Delete</span>
                        </a>
                    </div>
                </td>
            </tr>
        `;
    }
    function loadThemes(page = 1) {
        const perpage = document.getElementById('perpage').value;
        const search = document.getElementById('search_filter').value;
        const url = `/entity_hub/manage_company?page=${page}&sorting_filter=${perpage}&search_filter=${search}`;

        // Show skeleton loader and clear old data before fetching new data
        isLoading = true;
        document.getElementById('company-table-body').innerHTML = ''; // Clear old data
        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', skeletenRow()); // Clear old data
        $('#skeleton-loader').show(); // Show skeleton loader

        if (abortController.signal) {
            abortController.abort(); // Abort the previous request
        }
        abortController = new AbortController();

         fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }, signal: abortController.signal })
            .then(res => res.json())
            .then(res => {
                // Insert new data into the table
                if(res.data.length > 0){
                    res.data.forEach(item => {
                        document.getElementById('company-table-body').insertAdjacentHTML('beforeend', buildRow(item));
                    });

                }else{
                    document.getElementById('company-table-body').insertAdjacentHTML('beforeend', NoDataFound());
                }
                     $('[data-bs-toggle="tooltip"]').tooltip();
                // Update pagination and results info
                updatePagination(res.current_page, res.last_page, res.total, perpage);

                // Hide skeleton loader after data is fetched
                isLoading = false;
                $('#skeleton-loader').hide();
            })
            .catch(error => {
                if (error.name !== 'AbortError') { // Only handle abort error
                    console.error('Error loading data:', error);
                }
                // Hide skeleton loader in case of error
                $('#skeleton-loader').hide();
                isLoading = false;
            });
    }

    function skeletenRow(){
        return `
            <tr class="skeleton-loader" id="skeleton-loader">
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
                <td class="skeleton-cell">
                    <div class="skeleton"></div>
                </td>
            </tr>
            `;
    }

    function NoDataFound(){
        return `
            <tr><td colspan="5" class="text-center">No Data Found</td></tr>
            `;
    }

    function updatePagination(currentPage, lastPage, total, perpage) {
        let paginationContainer = document.getElementById('pagination-container');
        paginationContainer.innerHTML = ''; // Clear old pagination

        // Set the pagination container style
        paginationContainer.style.display = "flex";
        paginationContainer.style.justifyContent = "space-between";
        paginationContainer.style.alignItems = "center";

        // Showing result count info (e.g., Showing 1 to 25 of 3556 results)
        let start = (currentPage - 1) * perpage + 1;
        let end = Math.min(currentPage * perpage, total);
        let showingInfo = `Showing ${start} to ${end} of ${total} results`;
        paginationContainer.insertAdjacentHTML('beforeend', showingInfo);

        // Create Pagination Buttons

        // << First button
        let firstButton = `<li class="page-item ${currentPage === 1 ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="First Page"><button class=" page-link" onclick="loadThemes(1)" >«</button> </li>`;
        
        // < Previous button
        let prevButton = `<li class="page-item ${currentPage > 1 ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Previous"><button class=" page-link" onclick="loadThemes(${currentPage - 1})" >‹</button> </li>`;
        
        // Next button
        let nextButton = `<li class="page-item ${currentPage < lastPage ? '' : 'disabled'}" data-bs-toggle="tooltip" data-bs-placement="top" title="Next"><button class="page-link" onclick="loadThemes(${currentPage + 1})" >›</button> </li>`;
        
        // >> Last button
        let lastButton = `<li class="page-item ${currentPage === lastPage ? 'disabled' : ''}" data-bs-toggle="tooltip" data-bs-placement="top" title="Last Page"><button class=" page-link" onclick="loadThemes(${lastPage})" >»</button> </li>`;

        // Page Number Buttons (Dynamically show a range of pages around the current page)
        let pageButtons = '';
        let range = 2; // Show 2 pages before and after the current page
        let startPage = Math.max(1, currentPage - range);
        let endPage = Math.min(lastPage, currentPage + range);

        // Generate page numbers
        for (let i = startPage; i <= endPage; i++) {
            pageButtons += `<li class="page-item ${i === currentPage ? 'active' : ''}"><button class="page-link " onclick="loadThemes(${i})">${i}</button> </li>`;
        }

        // Add the pagination buttons and page numbers
        paginationContainer.insertAdjacentHTML('beforeend', `
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    ${firstButton}
                    ${prevButton}
                    ${pageButtons}
                    ${nextButton}
                    ${lastButton}
                </ul>
            </nav>
        `);

        // Update perpage dropdown if changed
        document.getElementById('perpage').value = perpage;
    }

    function debounceSearch(e) {
        if (e.keyCode === 13) {
            loadThemes(1);  // Trigger the search when the user presses enter
        }
    }

    // SearchBar
    document.getElementById('search_filter').addEventListener('input', function() {
        const searchValue = document.getElementById('search_filter').value;
        if (searchValue) {
            document.getElementById('refreshSearch').style.display = 'inline-block';  // Show the refresh button
        } else {
            document.getElementById('refreshSearch').style.display = 'none';  // Hide the refresh button
        }
    });

     // Listen for changes in the perpage dropdown and reload data
    document.getElementById('perpage').addEventListener('change', () => loadThemes(1));

    // Listen for Enter key in the search filter and reload data
    document.getElementById('search_filter').addEventListener('keyup', debounceSearch);

    document.getElementById('refreshSearch').addEventListener('click', function() {
        document.getElementById('search_filter').value = '';  // Clear the search input
        loadThemes(1);  // Reload the table data without the search filter
    });
    document.getElementById('searchSubmit').addEventListener('click', function() {
        loadThemes(1);  // Reload the table data without the search filter
    });

    // Initial load
    loadThemes(1);

</script>

<!-- Add Validation -->
<script>
    function AddvalidateForm() {
        let isValid = 0;

        // Clear all previous errors
        document.querySelectorAll('.error_msg').forEach(div => {
            div.innerText = '';
        });

        // Helper to set error
        function setError(id, message) {
            document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
            isValid = 1;
        }

        // Required fields validation
        const requiredFields = [{
                id: 'company_name',
                name: 'Company Name'
            },
            {
                id: 'company_type',
                name: 'Company Type'
            },
            {
                id: 'company_mail',
                name: 'Email ID'
            },
            {
                id: 'website_url',
                name: 'Website URL'
            },
            {
                id: 'ct_person',
                name: 'Contact Person Name'
            },
            {
                id: 'ct_per_mobile_no',
                name: 'Contact Person Mobile No'
            },
            {
                id: 'countryId',
                name: 'Country'
            },
            {
                id: 'stateId',
                name: 'State'
            },
            {
                id: 'cityId',
                name: 'City'
            },
            {
                id: 'area_street',
                name: 'Area / Street'
            },
            {
                id: 'door_flat_no',
                name: 'Door/Flat No'
            },
            {
                id: 'pincode',
                name: 'Pincode'
            },
            {
                id: 'gst_no',
                name: 'GST No'
            },
            {
                id: 'cin_no',
                name: 'CIN No'
            },
            {
                id: 'pan_no',
                name: 'PAN No'
            },
            {
                id: 'company_short_name',
                name: 'Company Short Name'
            },
            
            {
                id: 'comapny_bank_name',
                name: 'Bank Name'
            },
            {
                id: 'comapny_bank_branch',
                name: 'Bank Branch Name'
            },
            {
                id: 'comapny_acc_holder',
                name: 'Account Holder'
            },
            {
                id: 'comapny_acc_no',
                name: 'Account No'
            },
            {
                id: 'comapny_bank_ifsc',
                name: 'IFSC Code'
            }
        ];

        requiredFields.forEach(field => {
            const value = document.getElementById(field.id).value.trim();
            if (value === '') {
                setError(field.id, `${field.name} is required.`);
            }
        });

        // Email format validation
        const email = document.getElementById('company_mail').value.trim();
        const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (email !== '' && !emailPattern.test(email)) {
            setError('company_mail', 'Enter a valid Email ID.');
        }

        // Mobile number format validation
        const mobile = document.getElementById('ct_per_mobile_no').value.trim();
        const mobilePattern = /^[6-9]\d{9}$/;
        if (mobile !== '' && !mobilePattern.test(mobile)) {
            setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
        }

        const websiteUrl = document.getElementById('website_url').value.trim();
        const urlPattern = /^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?$/i;

        if (websiteUrl !== '' && !urlPattern.test(websiteUrl)) {
            setError('website_url', 'Enter a valid Website URL (e.g., https://example.com or www.example.com)');
        }

        // Logo upload validation
            const logoInput = document.getElementById('fav_upload');
            const logoFile = logoInput.files[0]; // Get the uploaded file
            
            if (!logoFile) {
                setError('fav_upload', 'Logo is required.');
            } else {
                // Check file format (JPG, PNG)
                const allowedFormats = ['image/jpeg', 'image/png'];
                if (!allowedFormats.includes(logoFile.type)) {
                    setError('fav_upload', 'Allowed formats are JPG and PNG only.');
                }

                // Check file size (Max 800KB)
                const maxSize = 800 * 1024; // 800KB in bytes
                if (logoFile.size > maxSize) {
                    setError('fav_upload', 'Logo file size must be less than 800KB.');
                }
            }
            
            const socialMediaFields = document.querySelectorAll('.toggle-field:checked'); // Get all checked checkboxes
                socialMediaFields.forEach(checkbox => {
                    const socialMediaId = checkbox.getAttribute('id').replace('checkSocialMedia_', ''); // Get the social media ID
                    const urlInput = document.querySelector(`#socialMediaField_${socialMediaId} input`);
                    const url = urlInput.value.trim();
                    if (url === '') {
                        setError(`checkSocialMedia_${socialMediaId}`, `${checkbox.nextElementSibling.innerText} URL is required.`);
                    }
                });

        if (isValid == 0) {
            $('#add_form').submit();
        }
    }
</script>

<script>
    $(document).ready(function() {
        // Fetch and populate countries
        $.ajax({
            url: "{{ route('country') }}",
            type: "GET",
            success: function(response) {
                if (response.status === 200 && response.data) {
                    var countryDropdown = $('#countryId');
                    countryDropdown.empty();
                    countryDropdown.append('<option value="">Select Country</option>');
                    response.data.forEach(function(country) {
                        countryDropdown.append($('<option></option>').attr('value', country
                            .id).text(country.name));
                    });
                }
            },
            error: function(error) {
                console.error('Error fetching countries:', error);
            }
        });
        // Event listener for country change
        $('#countryId').on('change', function() {
            var countryId = $(this).val();
            var stateDropdown = $('#stateId');
            var cityDropdown = $('#cityId');

            stateDropdown.empty().append('<option value="">Select State</option>');
            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId) {
                // Fetch and populate states based on selected country
                $.ajax({
                    url: "{{ route('state') }}",
                    type: "GET",
                    data: {
                        country_id: countryId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(state) {
                                stateDropdown.append($('<option></option>').attr(
                                    'value', state.id).text(state.name));
                            });
                        }
                        stateDropdown.val("").change();
                        cityDropdown.val("").change();
                    },
                    error: function(error) {
                        console.error('Error fetching states:', error);
                    }
                });
            }
        });
        // Event listener for state change
        $('#stateId').on('change', function() {
            var stateId = $(this).val();
            var countryId = $('#countryId').val();
            var cityDropdown = $('#cityId');

            cityDropdown.empty().append('<option value="">Select City</option>');

            if (countryId && stateId) {
                // Fetch and populate cities based on selected state and country
                $.ajax({
                    url: "{{ route('city') }}",
                    type: "GET",
                    data: {
                        country_id: countryId,
                        state_id: stateId
                    },
                    success: function(response) {
                        if (response.status === 200 && response.data) {
                            response.data.forEach(function(city) {
                                cityDropdown.append($('<option></option>').attr(
                                    'value', city.id).text(city.name));
                            });
                        }
                        cityDropdown.val("").change();
                    },
                    error: function(error) {
                        console.error('Error fetching cities:', error);
                    }
                });
            }
        });
    });
</script>
<script>
        function updatelevelStatus(UniversityId, isChecked) {
            const status = isChecked ? 0 : 1; // Set status based on checkbox state

            fetch(`/company_status/${UniversityId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token
                    },
                    body: JSON.stringify({
                        status: status
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Company status Updated successfully!');
                        loadThemes(1);
                    } else {
                        toastr.error('Error updating Company status');
                    }
                })
                .catch(error => {
                    console.error('Error updating Company status:', error);
                });
        }
    </script>
    <script>
        function confirmDelete(sno, name) {
            document.querySelector('#kt_modal_delete_company .btn-danger').setAttribute(
                'data-id', sno);
            $('#delete_message').html('Are you sure you want to delete <br> <b class="text-danger"> ' + name +
                '</b> Company ?');
        }

        function deleteDepartmentCategory() {

            var universityId = document.querySelector('#kt_modal_delete_company .btn-danger').getAttribute('data-id');

            fetch('/company_delete/' + universityId, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        toastr.success('Company Deleted successfully!');
                        location.reload();

                    } else if(data.status === 302) {
                        toastr.error(data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

        function viewmodel(id) {
             // Show skeleton loaders before fetch
            document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                skeleton.style.display = 'block'; // Show skeleton loaders
            });
        
            // Hide actual data elements
            document.querySelectorAll('.view-data').forEach(element => {
                element.style.display = 'none'; // Hide actual data until it is loaded
            });
            
            fetch('/company_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                          var logoPath = com.company_logo ? `/Company_logos/${com.company_logo}` : '/assets/common/logo_small.png';
                        document.getElementById('view_company_logo').src = logoPath;
                        document.querySelectorAll('.skeleton-loader-view').forEach(skeleton => {
                            skeleton.style.display = 'none'; // Hide skeleton loaders
                        });
                        document.querySelectorAll('.view-data').forEach(element => {
                            element.style.display = 'block'; // Show actual data
                        });
                        
                        $('#view_companyname').html(com.company_name).attr('title', com.company_name);
                        $('#view_companytype').html(com.company_type_name + '(' + com.slug_name + ')'); //company_mail
                        $('#view_emailid').html(com.company_mail).attr('title', com.company_mail);
                        $('#view_website').html(com.company_website);
                        $('#view_website_tag').attr('title', com.company_website).attr('href', com
                            .company_website);
                        $('#view_websitelink').attr('href', com.company_website); //company_ct_person//company_ct_number
                        $('#view_contactperson').html(com.company_ct_person).attr('title', com.company_ct_person);
                        $('#view_cp_mobileno').html(com.company_ct_number);
                        $('#view_address').html(
                                              (com.company_door_no || '') +', '+
                                              (com.company_area || '') +', '+
                                              (com.citiesname || '') +', '+
                                              (com.statename || '') +', '+
                                              (com.name || '')
                                            );
                        $('#view_description').html(com.company_desc||'-');
                        $('#view_gstno').html(com.company_gst);
                        $('#view_cinno').html(com.company_cin);
                        $('#view_panno').html(com.company_pan);
                        $('#view_bank').html(com.company_bank_name);
                        $('#view_branch').html(com.company_bank_branch);
                        $('#view_accountholder').html(com.company_acc_holder);
                        $('#view_accountno').html(com.company_acc_no).attr('title', com.company_acc_no);
                        $('#view_ifsccode').html(com.company_ifsc);
                        
                        $('[data-bs-toggle="tooltip"]').tooltip();
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
<!-- status Change  & Delete-->

   <script>
        function editmodel(id) {
            fetch('/company_view/' + id, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 200) {
                        var com = data.data;
                        $('#edit_id').val(id);
                        $('#edit_company_name').val(com.company_name);
                        $('#edit_company_short_name').val(com.company_short_name);
                        $('#edit_company_type').val(com.company_type).change();
                        $('#edit_company_mail').val(com.company_mail);
                        $('#edit_website_url').val(com.company_website);
                        $('#edit_ct_person').val(com.company_ct_person).attr('title', com.company_ct_person);
                        $('#edit_ct_per_mobile_no').val(com.company_ct_number);
                        // Fetch and populate countries
                        $.ajax({
                            url: "{{ route('country_ed_list') }}",
                            type: "GET",
                            success: function(response) {
                                if (response.status === 200 && response.data) {
                                    var countryDropdown = $('#edit_countryId');
                                    countryDropdown.empty();
                                    countryDropdown.append(
                                        '<option value="">Select Country</option>');
                                    response.data.forEach(function(country) {
                                        countryDropdown.append($('<option></option>')
                                            .attr('value', country.id).text(country
                                                .name));
                                    });
                                    countryDropdown.val(com.company_country).change();
                                }
                            },
                            error: function(error) {
                                console.error('Error fetching countries:', error);
                            }
                        });
                        // Event listener for country change
                        $('#edit_countryId').on('change', function() {
                            var countryId = $(this).val();
                            var stateDropdown = $('#edit_stateId');
                            var cityDropdown = $('#edit_cityId');

                            stateDropdown.empty().append('<option value="">Select State</option>');
                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId) {
                                // Fetch and populate states based on selected country
                                $.ajax({
                                    url: "{{ route('state_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(state) {
                                                stateDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', state.id)
                                                    .text(state.name));
                                            });
                                            stateDropdown.val(com.company_state).change();
                                        }
                                        
                                    },
                                    error: function(error) {
                                        console.error('Error fetching states:', error);
                                    }
                                });
                            }
                        });
                        // Event listener for state change
                        $('#edit_stateId').on('change', function() {
                            var stateId = $(this).val();
                            var countryId = $('#edit_countryId').val();
                            var cityDropdown = $('#edit_cityId');

                            cityDropdown.empty().append('<option value="">Select City</option>');

                            if (countryId && stateId) {
                                // Fetch and populate cities based on selected state and country
                                $.ajax({
                                    url: "{{ route('city_ed_list') }}",
                                    type: "GET",
                                    data: {
                                        country_id: countryId,
                                        state_id: stateId
                                    },
                                    success: function(response) {
                                        if (response.status === 200 && response.data) {
                                            response.data.forEach(function(city) {
                                                cityDropdown.append($(
                                                        '<option></option>')
                                                    .attr(
                                                        'value', city.id)
                                                    .text(city.name));
                                                cityDropdown.val(com
                                                        .company_city)
                                                    .change();
                                            });
                                        }
                                    },
                                    error: function(error) {
                                        console.error('Error fetching cities:', error);
                                    }
                                });
                            }
                        });

                        if(com.company_in_menu == 1){
                            $('#edit_company_in_menu').prop('checked',true);
                        }else{
                            $('#edit_company_in_menu').prop('checked',false);
                        }
                        
                        $('#edit_area_street').val(com.company_area);
                        $('#edit_door_flat_no').val(com.company_door_no);
                        $('#edit_pincode').val(com.company_pincode);
                        $('#edit_company_desc').val(com.company_desc);
                        $('#edit_company_base_color').val(com.company_base_color);
                        $('#edit_gst_no').val(com.company_gst);
                        $('#edit_cin_no').val(com.company_cin);
                        $('#edit_pan_no').val(com.company_pan);
                        $('#old_company_image').val(com.company_logo);
                        $('#edit_comapny_bank_name').val(com.company_bank_name);
                        $('#edit_comapny_bank_branch').val(com.company_bank_branch);
                        $('#edit_comapny_acc_holder').val(com.company_acc_holder);
                        $('#edit_comapny_acc_no').val(com.company_acc_no);
                        $('#edit_comapny_bank_ifsc').val(com.company_ifsc);
                         var logoPath = com.company_logo ? `/Company_logos/${com.company_logo}` : '/assets/common/logo_small.png';
                        document.getElementById('logo_update').src = logoPath;
                        document.getElementById('old_company_image').value = com.company_logo || '';
                        
                          
                        
                        if (com.social_media_details) {
                            const socialMediaDetails = JSON.parse(com.social_media_details);
                            Object.keys(socialMediaDetails).forEach(key => {
                                const checkbox = document.getElementById(`edit_checkSocialMedia_${key}`);
                                if (checkbox) {
                                    checkbox.checked = true;  // Check the checkbox if URL exists
                                    const inputField = document.querySelector(`#edit_socialMediaField_${key} input`);
                                    if (inputField) {
                                        inputField.value = socialMediaDetails[key]; // Set the URL in the input field
                                    }
                                    const target = document.querySelector(`#edit_socialMediaField_${key}`);
                                    if (checkbox.checked) {
                                        target.classList.remove("d-none"); // Show the target if checked
                                    } else {
                                        target.classList.add("d-none"); // Hide the target if unchecked
                                    }
                                }
                            });
                        }
                    } else {
                        console.error(data.error_msg);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
    <script>
        function EditvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'edit_company_name',
                    name: 'Company Name'
                },
                {
                    id: 'edit_company_type',
                    name: 'Company Type'
                },
                {
                    id: 'edit_company_mail',
                    name: 'Email ID'
                },
                {
                    id: 'edit_website_url',
                    name: 'Website URL'
                },
                {
                    id: 'edit_ct_person',
                    name: 'Contact Person Name'
                },
                {
                    id: 'edit_ct_per_mobile_no',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'edit_countryId',
                    name: 'Country'
                },
                {
                    id: 'edit_stateId',
                    name: 'State'
                },
                {
                    id: 'edit_cityId',
                    name: 'City'
                },
                {
                    id: 'edit_area_street',
                    name: 'Area / Street'
                },
                {
                    id: 'edit_door_flat_no',
                    name: 'Door/Flat No'
                },
                {
                    id: 'edit_pincode',
                    name: 'Pincode'
                },
                {
                    id: 'edit_gst_no',
                    name: 'GST No'
                },
                {
                    id: 'edit_cin_no',
                    name: 'CIN No'
                },
                {
                    id: 'edit_pan_no',
                    name: 'PAN No'
                },
                 {
                    id: 'edit_company_short_name',
                    name: 'Company Short Name'
                },
                {
                    id: 'edit_comapny_bank_name',
                    name: 'Bank Name'
                },
                {
                    id: 'edit_comapny_bank_branch',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'edit_comapny_acc_holder',
                    name: 'Account Holder'
                },
                {
                    id: 'edit_comapny_acc_no',
                    name: 'Account No'
                },
                {
                    id: 'edit_comapny_bank_ifsc',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('company_mail').value.trim();
            if (email !== '' && !/^\S+@\S+\.\S+$/.test(email)) {
                setError('company_mail', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('ct_per_mobile_no').value.trim();
            const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
            }
            
            // Logo upload validation
                const logoInput = document.getElementById('upload');
                const logoFile = logoInput.files[0]; // Get the uploaded file
                const oldLogo =$('#old_company_image').val();
                if (!logoFile) {
                    if(!oldLogo){
                        setError('upload', 'Logo is required.');
                    }
                    
                } else {
                    // Check file format (JPG, PNG)
                    const allowedFormats = ['image/jpeg', 'image/png'];
                    if (!allowedFormats.includes(logoFile.type)) {
                        setError('upload', 'Allowed formats are JPG and PNG only.');
                    }
    
                    // Check file size (Max 800KB)
                    const maxSize = 800 * 1024; // 800KB in bytes
                    if (logoFile.size > maxSize) {
                        setError('upload', 'Logo file size must be less than 800KB.');
                    }
                }
            
            const socialMediaFields = document.querySelectorAll('.toggle-field-edit:checked'); // Get all checked checkboxes
                socialMediaFields.forEach(checkbox => {
                    const socialMediaId = checkbox.getAttribute('id').replace('edit_checkSocialMedia_', ''); // Get the social media ID
                    const urlInput = document.querySelector(`#edit_socialMediaField_${socialMediaId} input`);
                    const url = urlInput.value.trim();
                    if (url === '') {
                        setError(`edit_checkSocialMedia_${socialMediaId}`, `${checkbox.nextElementSibling.innerText} URL is required.`);
                    }
                });

            if (isValid == 0) {
                $('#edit_form').submit();
            }
        }
    </script>

<script>
        let debounceTimer;

        function debounce(func, delay) {
            return function() {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        function checkUniqueField(field, value, errorElementId, submitButtonId) {
            if (value === '') {
                $('#' + errorElementId).text('');
                return;
            }

            let sno = $('#edit_id').val() || null;

            $.ajax({
                url: '/check_duplicates_company',
                method: 'POST',
                data: {
                    _token: '{{ csrf_token() }}',
                    field: field,
                    value: value,
                    sno: sno
                },
                success: function(response) {
                    if (response.exists) {
                        $('#' + errorElementId).text(response.message);
                        $('#' + submitButtonId).prop('disabled', true);
                    } else {
                        $('#' + errorElementId).text('');
                        $('#' + submitButtonId).prop('disabled', false);
                    }
                }
            });
        }

        // Bind with debounce
        $('#company_name').on('input', debounce(function() {
            checkUniqueField('company_name', $(this).val(), 'company_name_err', 'company_create_btn');
        }, 600));

        $('#edit_company_name').on('input', debounce(function() {
            checkUniqueField('company_name', $(this).val(), 'edit_company_name_err', 'update_company_btn');
        }, 600));

    </script>
    
    <script>
        function addEntityModel(id,name){
            $('#entity_company_name').text(name);
            $('#entity_company_id').val(id)
        }
        
        $(document).ready(function() {
            // Fetch and populate countries
            $.ajax({
                url: "{{ route('country') }}",
                type: "GET",
                success: function(response) {
                    if (response.status === 200 && response.data) {
                        var countryDropdown = $('#entity_countryId');
                        countryDropdown.empty();
                        countryDropdown.append('<option value="">Select Country</option>');
                        response.data.forEach(function(country) {
                            countryDropdown.append($('<option></option>').attr('value', country
                                .id).text(country.name));
                        });
                    }
                },
                error: function(error) {
                    console.error('Error fetching countries:', error);
                }
            });
            // Event listener for country change
            $('#entity_countryId').on('change', function() {
                var countryId = $(this).val();
                var stateDropdown = $('#entity_stateId');
                var cityDropdown = $('#entity_cityId');
    
                stateDropdown.empty().append('<option value="">Select State</option>');
                cityDropdown.empty().append('<option value="">Select City</option>');
    
                if (countryId) {
                    // Fetch and populate states based on selected country
                    $.ajax({
                        url: "{{ route('state') }}",
                        type: "GET",
                        data: {
                            country_id: countryId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(state) {
                                    stateDropdown.append($('<option></option>').attr(
                                        'value', state.id).text(state.name));
                                });
                            }
                            stateDropdown.val("").change();
                            cityDropdown.val("").change();
                        },
                        error: function(error) {
                            console.error('Error fetching states:', error);
                        }
                    });
                }
            });
            // Event listener for state change
            $('#entity_stateId').on('change', function() {
                var stateId = $(this).val();
                var countryId = $('#entity_countryId').val();
                var cityDropdown = $('#entity_cityId');
    
                cityDropdown.empty().append('<option value="">Select City</option>');
    
                if (countryId && stateId) {
                    // Fetch and populate cities based on selected state and country
                    $.ajax({
                        url: "{{ route('city') }}",
                        type: "GET",
                        data: {
                            country_id: countryId,
                            state_id: stateId
                        },
                        success: function(response) {
                            if (response.status === 200 && response.data) {
                                response.data.forEach(function(city) {
                                    cityDropdown.append($('<option></option>').attr(
                                        'value', city.id).text(city.name));
                                });
                            }
                            cityDropdown.val("").change();
                        },
                        error: function(error) {
                            console.error('Error fetching cities:', error);
                        }
                    });
                }
            });
        });
        
        function AddEntityvalidateForm() {
            let isValid = 0;

            // Clear all previous errors
            document.querySelectorAll('.error_msg').forEach(div => {
                div.innerText = '';
            });

            // Helper to set error
            function setError(id, message) {
                document.querySelector(`#${id}`).closest('.mb-3').querySelector('.error_msg').innerText = message;
                isValid = 1;
            }

            // Required fields validation
            const requiredFields = [{
                    id: 'entity_name',
                    name: 'Entity Name'
                },
                {
                    id: 'entity_company_id',
                    name: 'Company'
                },
                {
                    id: 'entity_mail',
                    name: 'Email ID'
                },
                {
                    id: 'entity_website_url',
                    name: 'Website URL'
                },
                {
                    id: 'entity_location_url',
                    name: 'Location URL'
                },
                {
                    id: 'entity_short_name',
                    name: 'Entity Short Name'
                },
                {
                    id: 'entity_base_url',
                    name: 'Entity Base URL'
                },
                {
                    id: 'entity_ct_person',
                    name: 'Contact Person Name'
                },
                {
                    id: 'entity_ct_per_mobile_no',
                    name: 'Contact Person Mobile No'
                },
                {
                    id: 'entity_countryId',
                    name: 'Country'
                },
                {
                    id: 'entity_stateId',
                    name: 'State'
                },
                {
                    id: 'entity_cityId',
                    name: 'City'
                },
                {
                    id: 'entity_area_street',
                    name: 'Area / Street'
                },
                {
                    id: 'entity_door_flat_no',
                    name: 'Door/Flat No'
                },
                {
                    id: 'entity_pincode',
                    name: 'Pincode'
                },
                {
                    id: 'entity_gst_no',
                    name: 'GST No'
                },
                {
                    id: 'entity_cin_no',
                    name: 'CIN No'
                },
                {
                    id: 'entity_pan_no',
                    name: 'PAN No'
                },
                {
                    id: 'entity_bank_name',
                    name: 'Bank Name'
                },
                {
                    id: 'entity_bank_branch',
                    name: 'Bank Branch Name'
                },
                {
                    id: 'entity_acc_holder',
                    name: 'Account Holder'
                },
                {
                    id: 'entity_acc_no',
                    name: 'Account No'
                },
                {
                    id: 'entity_bank_ifsc',
                    name: 'IFSC Code'
                }
            ];

            requiredFields.forEach(field => {
                const value = document.getElementById(field.id).value.trim();
                if (value === '') {
                    setError(field.id, `${field.name} is required.`);
                }
            });

            // Email format validation
            const email = document.getElementById('entity_mail').value.trim();
            if (email !== '' && !/^\S+@\S+\.\S+$/.test(email)) {
                setError('entity_mail', 'Enter a valid Email ID.');
            }

            // Mobile number format validation
            const mobile = document.getElementById('entity_ct_per_mobile_no').value.trim();
            const mobilePattern = /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[6789]\d{9}$/;

            if (mobile !== '' && !mobilePattern.test(mobile)) {
                setError('ct_per_mobile_no', 'Enter a valid 10-digit Mobile Number.');
            }
            
            const websiteUrl = document.getElementById('entity_website_url').value.trim();
            const entityBaseUrl = document.getElementById('entity_base_url').value.trim();
            const urlPattern = /^(https?:\/\/)?(www\.)?([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(\/[^\s]*)?$/i;
    
            if (websiteUrl !== '' && !urlPattern.test(websiteUrl)) {
                setError('entity_website_url', 'Enter a valid Website URL (e.g., https://example.com or www.example.com)');
            }
            if (entityBaseUrl !== '' && !urlPattern.test(entityBaseUrl)) {
                setError('entity_base_url', 'Enter a valid Base URL (e.g., https://example.com or www.example.com)');
            }
            
             // Logo upload validation
            const logoInput = document.getElementById('uploadEntity');
            const logoFile = logoInput.files[0]; // Get the uploaded file
            
            if (!logoFile) {
                setError('uploadEntity', 'Logo is required.');
            } else {
                // Check file format (JPG, PNG)
                const allowedFormats = ['image/jpeg', 'image/png'];
                if (!allowedFormats.includes(logoFile.type)) {
                    setError('uploadEntity', 'Allowed formats are JPG and PNG only.');
                }

                // Check file size (Max 800KB)
                const maxSize = 800 * 1024; // 800KB in bytes
                if (logoFile.size > maxSize) {
                    setError('uploadEntity', 'Logo file size must be less than 800KB.');
                }
            }
            
            const socialMediaFields = document.querySelectorAll('.toggle-field-entity:checked'); // Get all checked checkboxes
                socialMediaFields.forEach(checkbox => {
                    const socialMediaId = checkbox.getAttribute('id').replace('entitycheckSocialMedia_', ''); // Get the social media ID
                    const urlInput = document.querySelector(`#entitysocialMediaField_${socialMediaId} input`);
                    const url = urlInput.value.trim();
                    if (url === '') {
                        setError(`entitycheckSocialMedia_${socialMediaId}`, `${checkbox.nextElementSibling.innerText} URL is required.`);
                    }
                });

            if (isValid == 0) {
                $('#add_entity_form').submit();
            }
        }
    </script>
@endsection
