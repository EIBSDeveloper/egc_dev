@extends('layouts/layoutMaster')
@section('style')
@section('title', 'Orientation Staging')

@section('vendor-style')
    @vite(['resources/assets/vendor/libs/select2/select2.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
    @vite(['resources/assets/vendor/libs/select2/select2.js'])
@endsection

@section('content')

    <!-- Users List Table -->
    <div class="card">
        <div class="card-header pb-1">
            <ul class="nav nav-tabs flex-nowrap" role="tablist">
                <div class="scroll-container-wrapper">
                    <button class="scroll-btn left" id="scrollLeftBtn"><span class="scroll-arrow"><i
                                class="mdi mdi-chevron-left fs-2 text-white"></i></span></button>
                    <div class="scroll-container" id="scrollContainer">
                        <li class="item nav-item">
                            <a href="{{ url('/settings/general_settings') }}" type="button" class="nav-link scroll-link"
                                role="tab">
                                General Settings
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/sms_template') }}" type="button" class="nav-link scroll-link ">
                                Common
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/credential_book') }}" type="button" class="nav-link scroll-link">
                                Entity
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/document') }}" type="button" class="nav-link scroll-link active">
                                HRM
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/applicant_status') }}" type="button" class="nav-link scroll-link ">
                                Recruitment
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="{{ url('/settings/department') }}" type="button" class="nav-link scroll-link ">
                                Management
                            </a>
                        </li>
                    </div>
                    <button class="scroll-btn right" id="scrollRightBtn" style="display: block;"><i
                            class="mdi mdi-chevron-right fs-2 text-white"></i></button>
                </div>
            </ul>
        </div>
        <div class="card-body px-1 py-1">
            <div class="nav-align-right nav-tabs-shadow">
                <ul class="nav nav-tabs" role="tablist">

                    <li class="nav-item">
                        <a href="{{ url('/settings/document') }}" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                Documents
                                <span><i class="fa-solid fa-folder-open me-2 fs-4"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/document_checklist') }}" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                Document Checklist
                                <span><i class="fa-solid fa-list-check me-2 fs-4"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/orientation_staging') }}" type="button" class="nav-link active"
                            role="tab">
                            <label class="fs-6 right_nav">
                                Orientation Staging
                                <span><i class="mdi mdi-calendar-account-outline me-2 fs-2"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/questionnaire') }}" type="button" class="nav-link" role="tab">
                            <label class="fs-6 right_nav">
                                Questionnaire
                                <span><i class="mdi mdi-file-question-outline me-2 fs-2"></i></span>
                            </label>
                        </a>
                    </li>
                    <!-- <li class="nav-item">
                        <a href="{{ url('/settings/evaluation') }}" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                Evaluation
                                <span><i class="mdi mdi-file-edit me-2 fs-2"></i></span>
                            </label>
                        </a>
                    </li> -->
                    <li class="nav-item">
                        <a href="{{ url('/settings/metrics') }}" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                Metrics
                                <span><i class="mdi mdi-pen-plus me-2 fs-2"></i></span>
                            </label>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="{{ url('/settings/onboarding') }}" type="button" class="nav-link " role="tab">
                            <label class="fs-6 right_nav">
                                <span>Onboard Checklist<i class="mdi mdi-account-plus ms-2 fs-2"></i></span>
                            </label>
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="d-flex align-items-center justify-content-between pb-0 mb-4 pt-0 mt-0"
                        style="border-bottom: 1px solid gray;">
                        <div class="d-flex flex-column align-items-start">
                            <h5 class="card-title mb-1 text-black"> Orientation Staging</h5>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb custom-breadcrumb">
                                    <!-- Home -->
                                    <li class="breadcrumb-item">
                                        <a href="{{ url('/dashboard') }}">
                                            <i class="mdi mdi-cog"></i> Settings
                                        </a>
                                    </li>
                                    <li class="breadcrumb-item" aria-current="page">
                                        <a href="javascript:void(0);">Common </a>
                                    </li>
                                    <li class="breadcrumb-item active" aria-current="page">
                                        <a href="javascript:void(0);" class="active-link">
                                            Orientation Staging
                                        </a>
                                    </li>
                                </ol>
                            </nav>
                        </div>
                        <div class="d-flex justify-content-end align-items-center mb-2 gap-2">
                            <a href="#" class="btn btn-sm fw-bold btn-primary" data-bs-toggle="modal"
                                data-bs-target="#kt_modal_add_orientation_staging">
                                <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Orientation Staging
                            </a>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                                <div>
                                    <span>Show</span>
                                    <br>
                                    <select id="perpage" name="perpage" class="form-select form-select-sm w-60px">
                                        <option value="10">10</option>
                                        <option value="25" selected>25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                    </select>
                                </div>
                                <div class="d-flex align-items-center justify-content-end flex-wrap gap-2">
                                    <div class="searchBar">
                                        <input class="searchQueryInput" type="text" name="searchQueryInput"
                                            placeholder="Enter Orientation Staging" value=""
                                            oninput="toggleIcons(this)" />
                                        <a href="{{ url('/settings/orientation_staging') }}"
                                            class="searchQuerySubmit searchIcon">
                                            <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                                <path fill="#ab2b22" d="M9.5,3A6.5,6.5 0 0,1 16,9.5
                                                        C16,11.11 15.41,12.59 14.44,13.73
                                                        L14.71,14H15.5L20.5,19L19,20.5
                                                        L14,15.5V14.71L13.73,14.44
                                                        C12.59,15.41 11.11,16
                                                        9.5,16A6.5,6.5 0 0,1 3,9.5
                                                        A6.5,6.5 0 0,1 9.5,3
                                                        M9.5,5C7,5 5,7 5,9.5
                                                        C5,12 7,14 9.5,14
                                                        C12,14 14,12 14,9.5
                                                        C14,7 12,5 9.5,5Z" />
                                            </svg>
                                        </a>
                                        <button class="searchQuerySubmit refreshIcon" onclick="clearInput()"
                                            style="display:none;">
                                            <svg style="width:24px;height:24px" viewBox="0 0 24 24">
                                                <path fill="#ab2b22" d="M17.65,6.35C16.2,4.9 14.21,4 12,4
                                                        A8,8 0 0,0 4,12H1L4.89,16.89
                                                        L9,12H6A6,6 0 0,1 12,6
                                                        C13.66,6 15.14,6.69 16.22,7.78
                                                        L17.65,6.35M19.11,7.11L15,12
                                                        H18A6,6 0 0,1 12,18
                                                        C10.34,18 8.86,17.31 7.78,16.22
                                                        L6.35,17.65C7.8,19.1 9.79,20
                                                        12,20A8,8 0 0,0 20,12H23L19.11,7.11Z" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <table
                                class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
                                <thead>
                                    <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
                                        <th class="min-w-50px">S.No</th>
                                        <th class="min-w-50px">Orientation Staging</th>
                                        <th class="min-w-50px">Schedule  Duration</th>
                                        <th class="min-w-50px">Fields</th>
                                        <th class="min-w-50px">Emoji</th>
                                        <th class="min-w-50px">Status</th>
                                        <th class="min-w-50px">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>

                                        <td>
                                            <label class="fw-medium fs-7">1</label>
                                        </td>
                                        <td>
                                            <label class="fs-7 fw-medium " data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Company Orientation">Company Orientation</label>
                                        </td>

                                        <td align="center">
                                            <label class="text-black fw-medium  fs-7 ">5 Days</label>
                                        </td>
                                        <td>
                                            <div class="d-flex flex-column gap-2">
                                                <div class="d-flex gap-2">

                                                    <div><label
                                                            class="badge bg-label-primary border border-primary text-black fw-medium fs-8 ">Score</label>
                                                    </div>

                                                </div>
                                                <div><label
                                                        class="badge bg-label-primary border border-primary text-black fw-medium fs-8 ">Evaluation
                                                    </label></div>
                                            </div>
                                        </td>
                                        <td>
                                            <span><i class="mdi mdi-emoticon-happy-outline fs-2"></i></span>
                                        </td>
                                        <td>
                                            <label class="switch switch-square">
                                                <input type="checkbox" class="switch-input" checked />
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_edit_orientation_staging"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_delete_orientation_staging"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                                                    <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <label class="fw-medium fs-7">2</label>
                                        </td>
                                        <td>
                                            <label class="fs-7 fw-medium " data-bs-toggle="tooltip"
                                                data-bs-placement="bottom" title="Company Introduction">Company
                                                Introduction</label>
                                        </td>

                                        <td align="center">
                                            <label class=" text-black fw-medium px-3 fs-7 ">2 Hours</label>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">

                                                <div><label
                                                        class="badge bg-label-primary border border-primary text-black fw-medium fs-8 ">Score</label>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <span><i class="mdi mdi-emoticon-neutral-outline fs-2"></i></span>
                                        </td>
                                        <td>
                                            <label class="switch switch-square">
                                                <input type="checkbox" class="switch-input" checked />
                                                <span class="switch-toggle-slider">
                                                    <span class="switch-on"></span>
                                                    <span class="switch-off"></span>
                                                </span>
                                            </label>
                                        </td>
                                        <td>
                                            <span class="text-end">
                                                <a href="#" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_edit_orientation_staging"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit">
                                                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                                                </a>
                                                <a href="javascript:;" class="btn btn-icon btn-sm" data-bs-toggle="modal"
                                                    data-bs-target="#kt_modal_delete_orientation_staging"
                                                    data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete">
                                                    <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                                                </a>
                                            </span>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--begin::Modal - Add  Orientation Staging -->
    <div class="modal fade" id="kt_modal_add_orientation_staging" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Create Orientation Staging</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-0 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Orientation Staging<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Orientation Staging">
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Schedule Duration<span
                                    class="text-danger">*</span></label>
                            <div class="input-group ">
                                <input type="text" class="form-control" placeholder="Enter Duration">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">Select</button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="#" selected>Day</a></li>
                                    <li><a class="dropdown-item" href="#">Hours</a></li>
                                    <li><a class="dropdown-item" href="#">Month</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" />Score
                            </label>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" />Evaluation
                            </label>
                        </div>
                        {{-- <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2 metric_checkbox" type="checkbox" />
                                Metrics
                            </label>
                        </div> --}}
                        <div class="col-lg-12 mb-2 metric_div" style="display:none;">
                            <label class="text-black fw-semibold fs-6"><u>Metrics List</u></label>
                        </div>
                        <div class="row mb-2 scroll-y max-h-200px metric_div" style="display:none;">
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />Culture Score
                                </label>
                            </div>
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />First Impression
                                </label>
                            </div>
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />On-Time Presence
                                </label>
                            </div>
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />Knowledge
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="fw-semibold mb-1 text-black">Emoji<span class="text-danger">*</span></label>
                            <div class="scroll-y max-h-200px">
                                <div class="d-flex flex-wrap gap-3 py-4 px-4">
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('box_smile');">
                                        <i class="mdi mdi-sticker-emoji fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_1" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_smile');">
                                        <i class="mdi mdi-emoticon-lol-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_2" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sad');">
                                        <i class="mdi mdi-emoticon-frown-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_3" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_angry');">
                                        <i class="mdi mdi-emoticon-confused-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_4" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cry');">
                                        <i class="mdi mdi-emoticon-cry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_5" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_feel');">
                                        <i class="mdi mdi-emoticon-sad-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_6" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sick');">
                                        <i class="mdi mdi-emoticon-sick-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_7" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_no_eye');">
                                        <i class="mdi mdi-emoticon-dead-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_8" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_kiss');">
                                        <i class="mdi mdi-emoticon-kiss-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_9" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_one_eye');">
                                        <i class="mdi mdi-emoticon-wink-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_10" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_angry');">
                                        <i class="mdi mdi-emoticon-angry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_11" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_devil');">
                                        <i class="mdi mdi-emoticon-devil-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_12" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_happy');">
                                        <i class="mdi mdi-emoticon-happy-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_13" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_all_close');">
                                        <i class="mdi mdi-emoticon-tongue-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_14" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_eye_up');">
                                        <i class="mdi mdi-emoticon-excited-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_15" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cooler');">
                                        <i class="mdi mdi-emoticon-cool-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_16" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_happy');">
                                        <i class="mdi mdi-emoticon-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_17" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_boy');">
                                        <i class="mdi mdi-face-man-shimmer-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_18" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4 py-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Create
                            Orientation Staging</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Add   Orientation Staging-->


    <!--begin::Modal - Edit  Orientation Staging -->
    <div class="modal fade" id="kt_modal_edit_orientation_staging" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static" data-bs-focus="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-md">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <!--begin::Modal header-->
                <div
                    class="modal-header d-flex align-items-center justify-content-between border border-bottom-1 pb-0 mb-4">
                    <div class="text-center mt-4">
                        <h3 class="text-center text-black">Update Orientation Staging</h3>
                    </div>
                    <!--begin::Close-->
                    <div class="btn btn-sm btn-icon btn-active-color-primary rounded" style="border: 2px solid #000;"
                        data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"
                                xmlns="http://www.w3.org/2000/svg">
                                <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1"
                                    transform="rotate(-45 6 17.3137)" fill="#000" />
                                <rect x="7.41422" y="6" width="16" height="2" rx="1"
                                    transform="rotate(45 7.41422 6)" fill="#000" />
                            </svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body pt-0 pb-0 px-10 px-xl-20">
                    <!--begin::Heading-->
                    <div class="row">
                        <!-- Basic -->
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Orientation Staging<span
                                    class="text-danger">*</span></label>
                            <input type="text" class="form-control" placeholder="Enter Orientation Staging" value="Company Orientation">
                        </div>
                        <div class="col-lg-12 mb-4">
                            <label class="text-black fs-6 fw-semibold">Schedule Duration<span
                                    class="text-danger">*</span></label>
                            <div class="input-group ">
                                <input type="text" class="form-control" placeholder="Enter Duration" value="5">
                                <button class="btn btn-outline-primary dropdown-toggle" type="button"
                                    data-bs-toggle="dropdown" aria-expanded="false">Select</button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="#" selected>Day</a></li>
                                    <li><a class="dropdown-item" href="#">Hours</a></li>
                                    <li><a class="dropdown-item" href="#">Month</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" checked/>Score
                            </label>
                        </div>
                        <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2" type="checkbox" checked/>Evaluation
                            </label>
                        </div>
                        {{-- <div class="col-lg-4 mb-4">
                            <label class="fw-semibold mb-1 text-black">
                                <input class="form-check-input me-2 metric_checkbox" type="checkbox" />
                                Metrics
                            </label>
                        </div> --}}
                        <div class="col-lg-12 mb-2 metric_div" style="display:none;">
                            <label class="text-black fw-semibold fs-6"><u>Metrics List</u></label>
                        </div>
                        <div class="row mb-2 scroll-y max-h-200px metric_div" style="display:none;">
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />Culture Score
                                </label>
                            </div>
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />First Impression
                                </label>
                            </div>
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />On-Time Presence
                                </label>
                            </div>
                            <div class="col-lg-6 mb-4">
                                <label class="fw-semibold mb-1 text-black">
                                    <input class="form-check-input me-2" type="checkbox" />Knowledge
                                </label>
                            </div>
                        </div>
                        <div class="col-lg-12 mb-3">
                            <label class="text-dark mb-1 fs-6 fw-semibold">Emoji<span class="text-danger">*</span></label>
                            <div class="scroll-y max-h-200px">
                                <div class="d-flex flex-wrap gap-3 py-4 px-4">
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('box_smile');">
                                        <i class="mdi mdi-sticker-emoji fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_1" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_smile');">
                                        <i class="mdi mdi-emoticon-lol-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_2" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sad');">
                                        <i class="mdi mdi-emoticon-frown-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_3" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_angry');">
                                        <i class="mdi mdi-emoticon-confused-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_4" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cry');">
                                        <i class="mdi mdi-emoticon-cry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_5" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_feel');">
                                        <i class="mdi mdi-emoticon-sad-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_6" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_sick');">
                                        <i class="mdi mdi-emoticon-sick-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_7" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_no_eye');">
                                        <i class="mdi mdi-emoticon-dead-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_8" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_kiss');">
                                        <i class="mdi mdi-emoticon-kiss-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_9" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_one_eye');">
                                        <i class="mdi mdi-emoticon-wink-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_10" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_angry');">
                                        <i class="mdi mdi-emoticon-angry-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_11" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_devil');">
                                        <i class="mdi mdi-emoticon-devil-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_12" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_happy');">
                                        <i class="mdi mdi-emoticon-happy-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_13" style="display: block;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_all_close');">
                                        <i class="mdi mdi-emoticon-tongue-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_14" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_eye_up');">
                                        <i class="mdi mdi-emoticon-excited-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_15" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_cooler');">
                                        <i class="mdi mdi-emoticon-cool-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_16" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_very_happy');">
                                        <i class="mdi mdi-emoticon-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_17" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                    <a href="javascript:;"
                                        class="btn btn-icon btn-sm text-nowrap d-inline-block position-relative me-2"
                                        onclick="emoji_func('cir_boy');">
                                        <i class="mdi mdi-face-man-shimmer-outline fs-2"></i>
                                        <label
                                            class="badge bg-info rounded-pill position-absolute top-0 start-100 translate-middle px-0 py-0 mt-1"
                                            id="emj_18" style="display: none;">
                                            <span class="mdi mdi-check fs-6 fw-bold"></span>
                                        </label>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mt-4 py-4">
                        <button type="reset" class="btn btn-outline-danger text-primary me-3"
                            data-bs-dismiss="modal">Cancel</button>
                        <button type="button" id="create_sms_btn" class="btn btn-primary"
                            data-bs-dismiss="modal">Update
                            Orientation Staging</button>
                    </div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Edit   Orientation Staging-->

    <!--begin::Modal - Delete Orientation Staging-->
    <div class="modal fade" id="kt_modal_delete_orientation_staging" tabindex="-1" aria-hidden="true"
        data-bs-keyboard="false" data-bs-backdrop="static">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-m">
            <!--begin::Modal content-->
            <div class="modal-content rounded">
                <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
                    <!-- <div class="swal2-icon-content"><i class="mdi mdi-trash fs-2 text-danger"></i></div> -->
                    <div>
                        <i class="fa-solid fa-trash text-danger" style="font-size: 35px;"></i>
                    </div>
                </div>
                <div class="swal2-html-container mb-4" id="swal2-html-container" style="display: block;">
                    <span id="delete_message">Are you sure you want to delete <br><b class="text-danger">Company
                            Orientation
                        </b>
                        Orientation Staging ?</span>
                </div>
                <div class="d-flex justify-content-center align-items-center py-4 mb-4">
                    <button type="submit" class="btn btn-danger me-3" data-bs-dismiss="modal">Yes,
                        delete!</button>
                    <button type="reset" class="btn btn-secondary text-black"
                        data-bs-dismiss="modal">No,cancel</button>
                </div>
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - Delete Orientation Staging-->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const faviconFileInput = document.querySelector('.fav_file-in');
            const faviconResetButton = document.querySelector('.fav_file-reset');
            const faviconImage = document.getElementById('logo_create');
            const resetFaviconImage = "{{ asset('assets/eapl_images/ea_favicon.png') }}"; // default

            // Preview favicon
            faviconFileInput.addEventListener('change', function() {
                if (this.files[0]) {
                    const reader = new FileReader();
                    reader.onload = e => faviconImage.src = e.target.result;
                    reader.readAsDataURL(this.files[0]);
                }
            });

            // Reset favicon
            faviconResetButton.addEventListener('click', function() {
                faviconImage.src = resetFaviconImage;
                faviconFileInput.value = null;
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            $('.metric_checkbox').change(function() {
                if ($(this).is(':checked')) {
                    $('.metric_div').slideDown(); // show with animation
                } else {
                    $('.metric_div').slideUp(); // hide with animation
                }
            });
        });
    </script>


    <!-- Logo File Upload Start -->
    <!-- jQuery from CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Toastr CSS from CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- Toastr JavaScript from CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }
    </style>

    <script>
        function emoji_func(val) {
            if (val == "box_smile") {
                document.getElementById("emj_1").style.display = "block";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_smile") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "block";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_sad") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "block";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_angry") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "block";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_cry") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "block";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_feel") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "block";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_sick") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "block";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_no_eye") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "block";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_kiss") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "block";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_one_eye") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "block";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_very_angry") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "block";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_devil") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "block";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_happy") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "block";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_all_close") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "block";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_eye_up") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "block";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_cooler") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "block";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_very_happy") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "block";
                document.getElementById("emj_18").style.display = "none";

            } else if (val == "cir_boy") {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "block";

            } else {
                document.getElementById("emj_1").style.display = "none";
                document.getElementById("emj_2").style.display = "none";
                document.getElementById("emj_3").style.display = "none";
                document.getElementById("emj_4").style.display = "none";
                document.getElementById("emj_5").style.display = "none";
                document.getElementById("emj_6").style.display = "none";
                document.getElementById("emj_7").style.display = "none";
                document.getElementById("emj_8").style.display = "none";
                document.getElementById("emj_9").style.display = "none";
                document.getElementById("emj_10").style.display = "none";
                document.getElementById("emj_11").style.display = "none";
                document.getElementById("emj_12").style.display = "none";
                document.getElementById("emj_13").style.display = "none";
                document.getElementById("emj_14").style.display = "none";
                document.getElementById("emj_15").style.display = "none";
                document.getElementById("emj_16").style.display = "none";
                document.getElementById("emj_17").style.display = "none";
                document.getElementById("emj_18").style.display = "none";
            }
        }
    </script>

@endsection
