<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NewsBroadcastModel extends Model
{
    use HasFactory;
    public $table      = "egc_news_broadcast";
    public $primaryKey = 'sno';


    protected $fillable = [
        'branch_id',
        'role_ids',
        'start_date',
        'end_date',
        'information',
        'theme_style',
        'theme_id',
        'template_name',
        'broadcast_message',
        'created_by',
        'updated_by',
        'created_at',
        'updated_at',
        'status'
    ];
}