<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\EmailTemplateModel;
use Illuminate\Support\Facades\Validator;

class EmailTemplateAdd extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    return view('content.settings.common.email_template.email_template_list.add');
  }

}


