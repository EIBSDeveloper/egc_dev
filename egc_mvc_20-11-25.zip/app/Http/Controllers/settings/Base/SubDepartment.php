<?php

namespace App\Http\Controllers\settings\Base;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SubDepartmentModel;
use Illuminate\Support\Facades\Validator;

class SubDepartment extends Controller
{
  protected static $branch_id = 1;

  public function index()
  {
    return view('content.settings.Base.sub_department.sub_department_list');
  }

  public function Get_list()
  {
    // Retrieve the category ID from the POST request
    $dept_id = $_GET['id'] ?? '';

    $sub_department_list = SubDepartmentModel::join('eibs_department', 'eibs_department.sno', '=', 'eibs_sub_department.department_id')
      ->where('eibs_sub_department.status', 0)
      ->where('eibs_sub_department.department_id', $dept_id)
      ->orderBy('eibs_sub_department.sub_department_name', 'ASC')
      ->select('eibs_sub_department.*', 'eibs_department.department_name as department_name')
      ->get();
    // Prepare and return the response
    return response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sub_department_list
    ], 200);
  }


  public function Add(Request $request)
  {
    // return $request;

    $validator = Validator::make($request->all(), [
      'sub_department_name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $department_id = $request->department_dropdown;
      $sub_department_name = $request->sub_department_name;
      $sub_department_desc = $request->sub_department_desc;
      $user_id = 1;
      $chk = SubDepartmentModel::where('sub_department_name', ucwords($sub_department_name))->where('branch_id', self::$branch_id)->where('status', '!=', 2)->first();

      if ($chk) {

        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Already Department is exist!'
        ]);
        return redirect()->back();
      } else {
        $category_check = SubDepartmentModel::where('status', '!=', 2)->orderBy('sno', 'desc')->first();

        if (!$category_check) {

          $year = substr(date('y'), -2);
          $sub_department_id = 'SDP-0001/' . $year;
        } else {

          $data = $category_check->sub_department_id;
          $slice = explode('/', $data);
          $result = preg_replace('/[^0-9]/', '', $slice[0]);

          $next_number = (int) $result + 1;
          $request = sprintf('DP-%04d', $next_number);

          $year = substr(date('y'), -2);
          $sub_department_id = $request . '/' . $year;
        }

        $add_department = new SubDepartmentModel();
        $add_department->sub_department_id = $sub_department_id;
        $add_department->department_id = $department_id;
        $add_department->sub_department_name = Ucfirst($sub_department_name);
        $add_department->sub_department_desc = $sub_department_desc;
        $add_department->branch_id = self::$branch_id;
        $add_department->created_by = $user_id;
        $add_department->updated_by = $user_id;

        $add_department->save();

        if ($add_department) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Sub Department added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the Sub Department!'
          ]);
        }
      }
      return redirect()->back();
    }
  }

  public function Edit($id)
  {

    $edit_sub_department = SubDepartmentModel::where('sno', $id)->first();

    return view('content.settings.Base.sub_department.sub_department_list', [
      'edit_sub_department' => $edit_sub_department,
      'id' => $id,
    ]);
  }
  public function Update(Request $request)
  {
    // return $request;
    $validator = Validator::make($request->all(), [
      'edit_sub_department_name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      return response([
        'status' => 401,
        'message' => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data' => null,
      ], 200);
    } else {
      $sno = $request->sno_edit;
      $department_id = $request->edit_department_dropdown;
      $sub_department_name = $request->edit_sub_department_name;
      $sub_department_desc = $request->edit_sub_department_desc;
      $user_id = 1;




      $upd_DepartmentModel = SubDepartmentModel::where('sno', $sno)->first();

      $existingRecord = SubDepartmentModel::where('department_id', $department_id)
        ->where('sub_department_name', $sub_department_name)
        ->where('sno', '!=', $sno) // Exclude the record being updated
        ->first();

      if ($existingRecord) {
        // A record with the same department_id and sub_department_name exists
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Sub Department already exists .!'
        ]);
        return redirect()->back();
      } else {


        $upd_DepartmentModel->department_id = $department_id;
        $upd_DepartmentModel->sub_department_name = Ucfirst($sub_department_name);
        $upd_DepartmentModel->sub_department_desc = $sub_department_desc;
        $upd_DepartmentModel->branch_id = self::$branch_id;
        $upd_DepartmentModel->created_by = $user_id;
        $upd_DepartmentModel->updated_by = $user_id;
        $upd_DepartmentModel->update();

        if ($upd_DepartmentModel) {
          // If category added successfully, return success response and display Toastr message
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'Sub Department Update Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not Update the Sub Department!'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_DepartmentModel = SubDepartmentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = 2;
    $upd_DepartmentModel->Update();

    return response([
      'status' => 200,
      'message' => 'Successfully Deleted!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_DepartmentModel = SubDepartmentModel::where('sno', $id)->first();
    $upd_DepartmentModel->status = $request->input('status', 0);
    $upd_DepartmentModel->update();

    return response([
      'status' => 200,
      'message' => 'Successfully Status Updated!',
      'error_msg' => null,
      'data' => null,
    ], 200);
  }
}