@php
    $currentRouteName = Route::currentRouteName();
@endphp

<ul class="menu-sub">
  @if (isset($menu))
    @foreach ($menu as $submenu)
      @php
        $activeClass = null;
        $active = $configData["layout"] === 'vertical' ? 'active open' : 'active';
        $currentRouteName = Route::currentRouteName();

        if ($currentRouteName === $submenu->slug) {
            $activeClass = 'active';
        } elseif (isset($submenu->submenu)) {
            $slugList = is_array($submenu->slug) ? $submenu->slug : [$submenu->slug];
            foreach ($slugList as $slug) {
                if (str_starts_with($currentRouteName, $slug)) {
                    $activeClass = $active;
                }
            }
        }
      @endphp

      <li class="menu-item {{ $activeClass }}">
        <a href="{{ isset($submenu->url) ? url($submenu->url) : 'javascript:void(0)' }}" 
           class="{{ isset($submenu->submenu) ? 'menu-link menu-toggle' : 'menu-link' }}"
           @if (isset($submenu->target) && !empty($submenu->target)) target="_blank" @endif>
          @if (isset($submenu->icon))
            <i class="{{ $submenu->icon }}"></i>
          @endif
          <div>{{ __($submenu->name ?? '') }}</div>
          @isset($submenu->badge)
            <div class="badge bg-{{ $submenu->badge[0] }} rounded-pill ms-auto">
              {{ $submenu->badge[1] }}
            </div>
          @endisset
        </a>

        {{-- Only allow one more submenu level --}}
        @if (isset($submenu->submenu))
          <ul class="menu-sub">
            @foreach ($submenu->submenu as $subsubmenu)
              <li class="menu-item {{ \App\Helpers\Helpers::isActiveMenu($subsubmenu, $currentRouteName) ? 'active' : '' }}">
                <a href="{{ isset($subsubmenu->url) ? url($subsubmenu->url) : 'javascript:void(0)' }}" 
                   class="menu-link">
                  @if (isset($subsubmenu->icon))
                    <i class="{{ $subsubmenu->icon }}"></i>
                  @endif
                  <div>{{ __($subsubmenu->name ?? '') }}</div>
                </a>
              </li>
            @endforeach
          </ul>
        @endif
      </li>
    @endforeach
  @endif
</ul>
