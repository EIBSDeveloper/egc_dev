<?php

namespace App\Http\Controllers\settings\hrm;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\HrQuestionnaireModel;
use App\Models\HrQuestionDependsModel;
use Illuminate\Support\Facades\Validator;

class HRQuestionnaire extends Controller
{
    public function index()
    {
        return view(
            'content.settings.hrm.questionnaire.questionnaire_list');
    }
    public function add()
    {
        return view(
            'content.settings.hrm.questionnaire.questionnaire_add');
    }
    public function edit()
    {
        return view(
            'content.settings.hrm.questionnaire.questionnaire_edit');
    }

    public function ListDisplay($id, Request $request)
    {
        $customer_type_id = $id;

        $options = HrQuestionnaireModel::select(
            'egc_customer_type.customer_type_name',
            'egc_customer_type_option.sno as customer_type_option_id',
            'egc_customer_type.sno as customer_type_id',
            'egc_customer_type_option.cus_type_opt_id',
            'egc_customer_type_option.field_name',
            'egc_customer_type_option.field_value',
            'egc_customer_type_option.field_option',
            'egc_customer_type_option.is_depends',
            'egc_customer_type_option.depends_on',
            'egc_customer_type_option.is_mandatory',
            'egc_customer_type_option.created_by',
            'egc_customer_type_option.created_at',
            'egc_customer_type_option.updated_by',
            'egc_customer_type_option.updated_at',
            'egc_customer_type_option.status'
        )
            ->join('egc_customer_type', 'egc_customer_type_option.customer_type_id', '=', 'egc_customer_type.sno')
            ->where('egc_customer_type_option.customer_type_id', $customer_type_id)
            ->where('egc_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('egc_customer_type_option.sno', 'asc') // Order by sno ascending to maintain order
            ->get();

        $result = $options->map(function ($item) {
            // Process dependencies
            $dependsOnArray = $item->depends_on ? json_decode($item->depends_on, true) : [];

            return [
                'customer_type_id' => $item->customer_type_id,
                'cus_type_opt_id' => $item->cus_type_opt_id,
                'customer_type_name' => $item->customer_type_name,
                'customer_type_option_id' => $item->customer_type_option_id,
                'field_name' => $item->field_name,
                'field_value' => $item->field_value,
                'field_option' => $item->field_option ? json_decode($item->field_option, true) : [],
                'is_depends' => $item->is_depends,
                'depends_on' => $dependsOnArray,
                'is_mandatory' => $item->is_mandatory,
            ];
        });

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    public function List()
    {
        $option = HrQuestionnaireModel::select(
            'egc_customer_type.customer_type_name',
            'egc_customer_type_option.sno as customer_type_option_id',
            'egc_customer_type.sno as customer_type_id',
            'egc_customer_type_option.cus_type_opt_id',
            'egc_customer_type_option.field_name',
            'egc_customer_type_option.field_value',
            'egc_customer_type_option.field_option',
            'egc_customer_type_option.is_depends',
            'egc_customer_type_option.depends_on',
            'egc_customer_type_option.is_mandatory',
            'egc_customer_type_option.created_by',
            'egc_customer_type_option.created_at',
            'egc_customer_type_option.updated_by',
            'egc_customer_type_option.updated_at',
            'egc_customer_type_option.status'
        )
            ->join('egc_customer_type', 'egc_customer_type_option.customer_type_id', '=', 'egc_customer_type.sno')
            ->where('egc_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('egc_customer_type_option.sno', 'desc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            return [
                'customer_type_id' => $firstItem->customer_type_id,
                'cus_type_opt_id' => $firstItem->cus_type_opt_id,
                'customer_type_name' => $firstItem->customer_type_name,
                'customer_type_option_id' => $items->pluck('customer_type_option_id')->implode(','),
                'field_name' => $items->pluck('field_name')->implode(','),
                'field_value' => $items->pluck('field_value')->implode(','),
                'field_option' => $items->pluck('field_option')->map(function ($option) {
                    return json_decode($option);
                })->toArray(),
                'is_depends' => $items->pluck('is_depends')->implode(','),
                'depends_on' => $items->pluck('depends_on')->implode(','),
                'is_mandatory' => $items->pluck('is_mandatory')->implode(','),
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }


    public function View($id)
    {
        $cus_ids = explode(',', $id);

        // Get the first value from the array
        $cus_type_opt_id = $cus_ids[0];

        $editcategory = HrQuestionnaireModel::where('sno', $cus_type_opt_id)->first();
        $option = HrQuestionnaireModel::select(
            'egc_customer_type.customer_type_name',
            'egc_customer_type.sno as customer_type_id',
            'egc_customer_type_option.cus_type_opt_id',
            'egc_customer_type_option.field_name',
            'egc_customer_type_option.field_value',
            'egc_customer_type_option.field_option',
            'egc_customer_type_option.is_depends',
            'egc_customer_type_option.depends_on',
            'egc_customer_type_option.is_mandatory',
            'egc_customer_type_option.created_by',
            'egc_customer_type_option.created_at',
            'egc_customer_type_option.updated_by',
            'egc_customer_type_option.updated_at',
            'egc_customer_type_option.status'
        )
            ->join('egc_customer_type', 'egc_customer_type_option.customer_type_id', '=', 'egc_customer_type.sno')
            ->where('egc_customer_type_option.cus_type_opt_id', $editcategory->cus_type_opt_id)
            ->where('egc_customer_type_option.status', 0) // Assuming status check for active records
            ->orderBy('egc_customer_type_option.sno', 'asc') // Order by sno descending to get the latest rows
            ->get();

        $grouped = $option->groupBy(function ($item) {
            return $item->customer_type_id . '-' . $item->cus_type_opt_id . '-' . $item->customer_type_name;
        });

        $result = $grouped->map(function ($items) {
            $firstItem = $items->first();

            $fieldOptions = $items->pluck('field_option')->map(function ($option) {
                return json_decode($option);
            })->toArray();

            return [
                'customer_type_name' => $firstItem->customer_type_name,
                'fields' => $items->map(function ($item) {
                    return [
                        'field_name' => $item->field_name,
                        'field_value' => $item->field_value,
                        'field_option' => json_decode($item->field_option, true),
                        'is_depends' => $item->is_depends,
                        'depends_on' => $item->depends_on,
                        'is_mandatory' => $item->is_mandatory,
                    ];
                })->toArray()
            ];
        })->values();

        return response()->json([
            'status' => 200,
            'message' => null,
            'error_msg' => null,
            'data' => $result
        ], 200);
    }

    private function generateCustomerTypeOptionId()
    {
        $latestRecord = HrQuestionnaireModel::orderBy('sno', 'desc')->first();

        if (!$latestRecord) {
            $year = substr(date("y"), -2);
            $hr_question_id = "HRQ-0001/" . $year;
        } else {
            $latestId = $latestRecord->hr_question_id;
            $year = substr(date("y"), -2);

            // Extract numeric part from the latest ID
            preg_match('/HRQ-(\d{4})\/\d{2}/', $latestId, $matches);
            $nextNumber = intval($matches[1]) + 1;

            // Format the new ID
            $newId = sprintf("HRQ-%04d", $nextNumber);
            $hr_question_id = $newId . '/' . $year;
        }

        return $hr_question_id;
    }

    public function QuestionSave(Request $request)
{
    // Debugging only: remove or comment this line in production
    // return $request;

    // ✅ Validation
    $validator = Validator::make($request->all(), [
        'label_names' => 'required|array',
        'label_values' => 'required|array',
        'options' => 'required|array',
        'options.*.*.label' => 'nullable|string',
    ]);

    if ($validator->fails()) {
        session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Incorrect format input fields!',
        ]);
        return redirect()->back()->withErrors($validator)->withInput();
    }

    // ✅ Setup
    $user_id = $request->user()->user_id;
    $hr_question_id = $this->generateCustomerTypeOptionId();

    // ✅ Loop through each main question
    foreach ($request->label_names as $index => $label_name) {

        $field_name = ucfirst(trim($label_name));
        $field_value = $request->label_values[$index] ?? '';
        $field_options = [];

        // Build options array
        foreach ($request->options[$index] ?? [] as $optionIndex => $option) {
            if (!empty($option['label'])) {
                $field_options[] = [
                    'value' => $optionIndex,
                    'label' => $option['label'],
                ];
            }
        }

        $is_depends = isset($request->depends[$index]) ? 1 : 0;
        $is_mandatory = isset($request->mandatory[$index]) ? 1 : 0;
        $depend_mandatory = isset($request->depend_mandatory[$index]) ? 1 : 0;

        // ✅ Save main question
        $main = new HrQuestionnaireModel();
        $main->hr_question_id = $hr_question_id;
        $main->field_name = $field_name;
        $main->field_value = $field_value;
        $main->field_option = !empty($field_options) ? json_encode($field_options) : null;
        $main->is_depends = $is_depends;
        $main->is_mandatory = $is_mandatory;
        $main->created_by = $user_id;
        $main->updated_by = $user_id;
        $main->save();

        // ✅ If a dependent question exists
        if ($is_depends && isset($request->depends_label[$index])) {

            $dep_label_trigger = $request->depends_label[$index]; // e.g. "yes"
            $dep_label_name = ucfirst(trim($request->depends_label_name[$index] ?? ''));
            $dep_input_value = $request->depends_input_value[$index] ?? '';
            $dep_options = $request->depends_options[$index] ?? [];

            // Find the value for the triggering label in the parent options
            $depends_on = [];
            foreach ($request->options[$index] as $optionIndex => $option) {
                if (isset($option['label']) && $option['label'] == $dep_label_trigger) {
                    $depends_on[] = [
                        'value' => $optionIndex,
                        'label' => $dep_label_trigger,
                    ];
                    break;
                }
            }

            // Build dependent field options
            $dep_field_options = [];
            foreach ($dep_options as $depOptionIndex => $opt) {
                if (!empty($opt['label'])) {
                    $dep_field_options[] = [
                        'value' => $depOptionIndex,
                        'label' => $opt['label'],
                    ];
                }
            }

            // ✅ Save dependent question in HrQuestionDependsModel
            $depends = new HrQuestionDependsModel();
            $depends->question_id = $main->sno; // link back to parent
            $depends->field_name = $dep_label_name;
            $depends->field_value = $dep_input_value;
            $depends->field_option = !empty($dep_field_options) ? json_encode($dep_field_options) : null;
            $depends->is_mandatory = $depend_mandatory;
            $depends->depends_on = !empty($depends_on) ? json_encode($depends_on) : null;
            $depends->created_by = $user_id;
            $depends->updated_by = $user_id;
            $depends->save();
        }
    }

    // ✅ Success toast
    session()->flash('toastr', [
        'type' => 'success',
        'message' => 'Question added successfully!',
    ]);

    return redirect('settings/questionnaire');
}



    public function EditPage($id)
    {
        $customer_type = HrQuestionnaireModel::where('sno', $id)->first();

        return  response([
            'status'    => 200,
            'message'   => null,
            'error_msg' => null,
            'data'      => $customer_type
        ], 200);
    }

    public function Update($id, Request $request)
    {

        $validator = Validator::make($request->all(), [
            'customer_type_name' => 'required|max:255',

        ]);

        if ($validator->fails()) {

            session()->flash('toastr', [
                'type' => 'error',
                'message' => 'Incorrect format input feilds!'
            ]);
        } else {


            $customer_type_name       = $request->customer_type_name;
            $customer_type_desc       = $request->customer_type_desc;

            $upd_CourseCategoryModel =  HrQuestionnaireModel::where('sno', $id)->first();

            $chk = HrQuestionnaireModel::where('customer_type_name', ucwords($customer_type_name))->where('status', '!=', 2)->first();

            if ($chk) {
                if ($chk->sno != $id) {
                    session()->flash('toastr', [
                        'type' => 'error',
                        'message' => 'Name has been  already created!'
                    ]);
                } else {
                }
            }
            $upd_CourseCategoryModel->customer_type_name  = Ucfirst($customer_type_name);
            $upd_CourseCategoryModel->customer_type_desc  = $customer_type_desc;
            $upd_CourseCategoryModel->update();


            if ($upd_CourseCategoryModel) {
                $result = response([
                    'status'    => 200,
                    'message'   => 'Successfully Updated!',
                    'error_msg' => null,
                    'data'      => null,
                ], 200);
            } else {
                $result = response([
                    'status'    => 401,
                    'message'   => 'Incorrect format input feilds',
                    'error_msg' => 'Incorrect format input feilds',
                    'data'      => null,
                ], 401);
            }
            return $result;
        }

        // return redirect()->back();
    }
    public function Delete($id)
    {
        $upd_CourseCategoryModel =  HrQuestionnaireModel::where('sno', $id)->first();
        $upd_CourseCategoryModel->status  = 2;
        $upd_CourseCategoryModel->Update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Deleted!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

    public function Status($id, Request $request)
    {

        $upd_CourseCategoryModel =  HrQuestionnaireModel::where('sno', $id)->first();

        $upd_CourseCategoryModel->status = $request->input('status', 0);
        $upd_CourseCategoryModel->update();


        return response([
            'status'    => 200,
            'message'   => 'Successfully Status Updated!',
            'error_msg' => null,
            'data'      => null,
        ], 200);
    }

}
