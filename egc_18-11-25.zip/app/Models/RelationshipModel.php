<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RelationshipModel extends Model {
    use HasFactory;
    public $table      = 'egc_relationship_type';
    public $primaryKey = 'sno';
    //public $timestamps = false;

    protected $fillable = [
        'relationship_name',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'status',
    ];
}