<?php

namespace App\Http\Controllers\settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GeneralSettingsModel;
use Illuminate\Support\Facades\Validator;
use App\Helpers\Helpers;

class GeneralSettings extends Controller
{


  public function index()
  {
    $general = GeneralSettingsModel::first();
    $pageConfigs = ['myLayout' => 'default'];
    $helper = new Helpers();

    if ($general) {
      $logoUrl = $helper->Logo_pic($general->logo);
      $favUrl = $helper->Fav_Icon_pic($general->fav_icon);
      $title   = $general->title;
      $url   = $general->url;
      $email_id   = $general->email_id;
      $phone_number   = $general->phone_number;
      $mobile_number   = $general->mobile_number;
      $whatsapp_number   = $general->whatsapp_number;
      $date_format   = $general->date_format;
      $time_zone   = $general->time_zone;
      $currency_format   = $general->currency_format;
      $registered_name   = $general->registered_name;
      $tax_no   = $general->tax_no;
      $language   = $general->language;
      $country   = $general->country;
      $state   = $general->state;
      $city   = $general->city;
      $currency_id   = $general->currency_id;
      $address   = $general->address;
      $pincode   = $general->pincode;
      $min_deducted_amount   = $general->min_deducted_amount;
      $max_refund_percentage   = $general->max_refund_percentage;
      $max_refund_days   = $general->max_refund_days;
      $batch_refund_days   = $general->batch_refund_days;
       $payment_remainder   = $general->payment_remainder;
       $hot_lead_limit   = $general->hot_lead_limit;
      $hot_lead_days   = $general->hot_lead_days;
    
      $youtube_link   = $general->youtube_link;
      $linkedin_link   = $general->linkedin_link;
      $pinterest_link   = $general->pinterest_link;
      $twitter_link   = $general->twitter_link;
       $lead_bank_count   = $general->lead_bank_count;
      $branch_product_currency = $general->branch_product_currency;
      $maintenance_chk = $general->maintenance_chk;

      // Call the Logo_pic method using the instantiated object
    } else {
      $logoUrl = null;
      $favUrl = null;
    }

    return view('content.settings.general_settings',
     [
      'logoUrl' => $logoUrl,
      'favUrl' => $favUrl,
      'title' => $title,
      'url' => $url,
      'email_id' => $email_id,
      'phone_number' => $phone_number,
      'payment_remainder' => $payment_remainder,
      'branch_product_currency' => $branch_product_currency,
      'hot_lead_limit' => $hot_lead_limit,
      'hot_lead_days' => $hot_lead_days,
      'mobile_number' => $mobile_number,
      'whatsapp_number' => $whatsapp_number,
      'date_format' => $date_format,
      'time_zone' => $time_zone,
      'currency_format' => $currency_format,
      'registered_name' => $registered_name,
      'tax_no' => $tax_no,
      'language' => $language,
      'country' => $country,
      'state' => $state,
      'city' => $city,
      'currency_id' => $currency_id,
      'address' => $address,
      'pincode' => $pincode,
       'lead_bank_count' => $lead_bank_count,
      'max_refund_days' => $max_refund_days,
      'batch_refund_days' => $batch_refund_days,
      'max_refund_percentage' => $max_refund_percentage,
      'min_deducted_amount' => $min_deducted_amount,
      'youtube_link' => $youtube_link,
      'pinterest_link' => $pinterest_link,
      'linkedin_link' => $linkedin_link,
      'twitter_link' => $twitter_link,
      'maintenance_chk' => $maintenance_chk,
      'pageConfigs' => $pageConfigs
    ]);
  }


  public function Update(Request $request)
  {
   
    $validator = Validator::make($request->all(), [
      'phone_number' => 'required|between:10,10',
    ]);

    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

      $title             = $request->title;
      $url               = $request->url;
      $email_id          = $request->email_id;
      $phone_number      = $request->phone_number;
      $mobile_number      = $request->mobile_number;
      $whatsapp_number   = $request->whatsapp_number;
      $date_format       = $request->date_format;
      $time_zone         = $request->time_zone;
      $registered_name   = $request->registered_name;
      $tax_no            = $request->tax_no;
      $language          = $request->language;
      $country           = $request->country;
      $state             = $request->state;
      $city              = $request->city;
      $address           = $request->address;
      $currency_format   = $request->currency_format;
      $pincode           = $request->pincode;
      $address           = $request->address;
      // $logo           = $request->logo;
      // $fav_icon       = $request->fav_icon;
      $user_id           = $request->user()->user_id ?? 1;
      // $user_id           = 1;


      $generalcheck      =  GeneralSettingsModel::first();

      if ($generalcheck) {

        $general = GeneralSettingsModel::find(1);
       
        if ($request->hasFile('logo')) {
          $imageName = idate("B") . rand(1, 50) . '.' . $request->file('logo')->extension();
          $destinationPath = public_path('logos'); // Path to the logos directory
          $request->file('logo')->move($destinationPath, $imageName);
          $logo = $imageName;
        } else {
          $logo = $general->logo;
        }


        if ($request->hasFile('fav_icon')) {
          $imageName = idate("B") . rand(1, 50) . '.' . $request->fav_icon->extension();
          $destinationPath = public_path('fav_icons'); // Path to the fav_icons directory
          $request->fav_icon->move($destinationPath, $imageName);
          $fav_icon = $imageName;
        } else {
          $fav_icon = $general->fav_icon;
        }

        $general->title               = $title;
        $general->logo                = $logo;
        $general->fav_icon            = $fav_icon;
        $general->url                 = $url;
        $general->email_id            = $email_id;
        $general->phone_number        = $phone_number;
        $general->mobile_number        = $mobile_number;
        $general->whatsapp_number     = $whatsapp_number;
        $general->date_format         = $date_format;
        
        $general->time_zone           = $time_zone;
        $general->registered_name     = $registered_name;
        $general->tax_no              = $tax_no;
        $general->language            = $language;
        $general->country             = $country;
        $general->state               = $state;
        $general->city                = $city;
        $general->currency_id     = $currency_format;
        $general->address             = $address;
        $general->pincode             = $pincode;
        $general->min_deducted_amount = $request->min_deducted_amount ?? 0;
        $general->max_refund_percentage = $request->max_refund_percentage ?? 0;
         $general->hot_lead_limit     = $request->hot_lead_limit ?? 0;
        $general->hot_lead_days     = $request->hot_lead_days ?? 0;

        $general->payment_remainder     = $request->pay_rem_day ?? 0;
        $general->max_refund_days     = $request->max_refund_days ?? 0;
        $general->batch_refund_days     = $request->batch_refund_days ?? 0;
        $general->lead_bank_count     = $request->lead_bank_count ?? 0;
        $general->twitter_link          = $request->twitter ?? null ;
        $general->pinterest_link        = $request->pinterest ?? null ;
        $general->linkedin_link         = $request->linkedin ?? null;
        $general->youtube_link          = $request->youtube ?? null;
        $general->maintenance_chk          = $request->maintenance_chk ?? 0;
        $general->created_by          = $user_id;
        $general->updated_by          = $user_id;
        // return  $general;
        $general->update();

        if ($general) {

          $result =   response([
            'status'    => 200,
            'message'   => 'General Setting has been Updated successfully',
            'error_msg' => null,
            'data'      => $general,
          ], 200);
        } else {

          $result =   response([
            'status'    => 401,
            'message'   => 'General Setting can not be updated',
            'error_msg' => 'General Setting information is worng please try again',
            'data'      => null,
          ], 401);
        }
        return redirect()->route('settings-general-settings');
        // return view('content.settings.general_settings');
      } else {

        $logoPath = '';
        if ($request->hasFile('logo')) {
          $imageName = idate("B") . rand(1, 50) . '.' . $request->logo->extension();

          $destinationPath = 'logo';
          $request->logo->move(public_path($destinationPath), $imageName);
          $url = $imageName;

          $logoPath = $url;
        } else {
          $logoPath =  '';
        }
        $faviconPath  = '';
        if ($request->hasFile('fav_icon')) {

          $imageName = idate("B") . rand(1, 50) . '.' . $request->fav_icon->extension();

          $destinationPath = 'fav_icon';
          $request->fav_icon->move(public_path($destinationPath), $imageName);
          $url = $imageName;


          $fav_icon = $url;
        } else {
          $fav_icon     = '';
        }



        $add_general = new GeneralSettingsModel;

        $add_general->title               = $title;
        $add_general->logo                = $logoPath;
        $add_general->fav_icon           = $fav_icon;
        $add_general->url                 = $url;
        $add_general->email_id            = $email_id;
        $add_general->phone_number        = $phone_number;
        $add_general->mobile_number        = $mobile_number;
        $add_general->whatsapp_number     = $whatsapp_number;
        $add_general->date_format         = $date_format;
        $add_general->time_zone               = $time_zone;
        $add_general->registered_name     = $registered_name;
        $add_general->tax_no              = $tax_no;
        $add_general->language            = $language;
        $add_general->country             = $country;
        $add_general->state               = $state;
        $add_general->city                = $city;
        $add_general->currency_id     = $currency_format;
        $add_general->address            = $address;
        $add_general->pincode             = $pincode;
        $add_general->created_by              = $user_id;
        $add_general->updated_by              = $user_id;
        // return  $add_general;
        $add_general->save();

        // return response([
        //   'status'    => 200,
        //   'message'   => 'General Setting has been Updated successfully',
        //   'error_msg' => null,
        //   'data'      => null,
        // ], 200);
        return redirect()->route('settings-general-settings');
      }
    }
  }

  
}