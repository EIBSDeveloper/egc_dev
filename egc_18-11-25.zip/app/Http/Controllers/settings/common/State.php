<?php

namespace App\Http\Controllers\settings\common;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\CountryModel;
use App\Models\StateModel;


class State extends Controller
{
  protected static $branch_id = 1;
//   public function index()
// {
//     return view('content.settings.common.state.state_list');
// }

  public function index(Request $request)
  {
    $page = $request->input('page', 1);
    $perpage = (int) $request->input('sorting_filter', 25);
    $offset = ($page - 1) * $perpage;
    $search_filter = $request->search_filter ?? '';
    $state = StateModel::select('egc_states.*','egc_countries.name as country_name')->where('egc_states.status', '!=', 2)
    ->join('egc_countries','egc_countries.id','=','egc_states.country_id');
    if ($search_filter != '') {
        $state->where(function ($subquery) use ($search_filter) {
            $subquery->where('egc_states.name', 'LIKE', "%{$search_filter}%")
                ->orWhere('egc_countries.name', 'LIKE', "%{$search_filter}%");  
        });
    }
    
    $state = $state->orderBy('egc_states.id', 'desc')->paginate($perpage);

    $helper = new \App\Helpers\Helpers();

    if ($request->ajax()) {
        $data = $state->map(function ($item) use ($helper) {
            return [
                'sno' => $item->id,
                'status' => $item->status,
                'name' => $item->name,
                'country_id' => $item->country_id,
                'country_name' => $item->country_name,
                'data' => $item,
                'encrypted_id' => $helper->encrypt_decrypt($item->sno, 'encrypt'),
            ];
        });

        return response()->json([
            'data' => $data,
            'current_page' => $state->currentPage(),
            'last_page' => $state->lastPage(),
            'total' => $state->total(),
        ]);
    }
    // return view( 'content.settings.course.course_type.course_type_list' );
    return view('content.settings.common.state.state_list', [
      'perpage' => $perpage,
      'search_filter' => $search_filter
    ]);
  }
  public function List_for_edit(Request $request)
  {
    $countryId = $request->input('country_id');
    $sms_template = StateModel::where('country_id', $countryId)->orderBy('name', 'ASC')->get();

    return  response([
      'status'    => 200,
      'message'   => null,
      'error_msg' => null,
      'data'      => $sms_template
    ], 200);
  }
  
  public function List(Request $request)
  {

      $countryId = $request->input('country_id');
      $city = StateModel::where('status', 0)->where('country_id', $countryId)->get();

      return  response([
          'status'    => 200,
          'message'   => null,
          'error_msg' => null,
          'data'      => $city
      ], 200);
  }

  public function Add(Request $request)
  {

    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255'
    ]);
    if ($validator->fails()) {
      return  response([
        'status'    => 401,
        'message'   => 'Incorrect format input feilds',
        'error_msg' => $validator->messages()->get('*'),
        'data'      => null,
      ], 200);
    } else {

     
      $name                 = $request->name;
      $country_id                = $request->country_id;
      $user_id                    = $request->user()->user_id ?? 1;
      $chk = StateModel::where('name', $name)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'Name has been already created!'
        ]);
      } else {
        $category_check = StateModel::where('status', '!=', 2)->orderBy('id', 'desc')->first();

       

        $add_category = new StateModel();
        $add_category->name  = $name;
        $add_category->country_id = $country_id;
        $add_category->created_by = $user_id;
        $add_category->updated_by = $user_id;

        $add_category->save();

        if ($add_category) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'State added Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not add the State!'
          ]);
        }
      }
      // return $result;
      return redirect()->back()->with('success', 'State Created successfully!');
    }
  }

  public function Update(Request $request)
  {

    // return $request;
    $validator = Validator::make($request->all(), [
      'name' => 'required|max:255',

    ]);

    if ($validator->fails()) {
      session()->flash('toastr', [
        'type' => 'error',
        'message' => 'Incorrect format input fields'
      ]);
      return redirect()->back();
    } else {
      $id = $request->edit_id;
      $name                     = $request->name;
      $country_id                   = $request->country_id;
     
      $upd_CourseCategoryModel =  StateModel::where('id', $id)->first();

      $chk = StateModel::where('name', $name)->where('id', '!=', $id)->where('status', '!=', 2)->first();

      if ($chk) {
        session()->flash('toastr', [
          'type' => 'error',
          'message' => 'State has been  already assigned!'
        ]);
        return redirect()->back();
      } else {

        $upd_CourseCategoryModel->name  = $name;
        $upd_CourseCategoryModel->country_id  = $country_id;
        $upd_CourseCategoryModel->update();

        if ($upd_CourseCategoryModel) {
          session()->flash('toastr', [
            'type' => 'success',
            'message' => 'State updated Successfully!'
          ]);
        } else {
          session()->flash('toastr', [
            'type' => 'error',
            'message' => 'Could not update the State !'
          ]);
        }
      }
    }
    return redirect()->back();
  }

  public function Delete($id)
  {
    $upd_CourseCategoryModel =  StateModel::where('id', $id)->first();
    $upd_CourseCategoryModel->status  = 2;
    $upd_CourseCategoryModel->Update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function Status($id, Request $request)
  {

    $upd_CourseCategoryModel =  StateModel::where('id', $id)->first();

    $upd_CourseCategoryModel->status = $request->input('status', 0);
    $upd_CourseCategoryModel->update();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Status Updated!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }

  public function DeleteBatchPermanently($id)
  {
    $upd_CourseCategoryModel =  StateModel::where('id', $id)->first();
    $upd_CourseCategoryModel->Delete();

    return response([
      'status'    => 200,
      'message'   => 'Successfully Deleted!',
      'error_msg' => null,
      'data'      => null,
    ], 200);
  }
}